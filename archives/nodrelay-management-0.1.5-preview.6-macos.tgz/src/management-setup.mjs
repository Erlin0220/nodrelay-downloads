import { createHash, randomBytes } from 'node:crypto';
import { readFile, rename, rm } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { parseArgs } from 'node:util';
import { pathToFileURL } from 'node:url';
import { cloudflareApi, cloudflareRequestTimeoutMs, CloudflareRequestTimeoutError, safeCloudflareRoute } from '../cloud/cloudflare.mjs';
import { hostedInstallers, installPath, operatingSystems } from '../cloud/device-paths.mjs';
import { bootstrapInstaller } from '../cloud/install-command.mjs';
import { managementBootstrapOAuthScopes, managementIdentityOAuthScopes, managementIdentityScope, managementOAuthScopes, usableStoredGrant } from '../cloud/oauth-grant.mjs';
import { authorize, openBrowser } from './cloudflare-oauth.mjs';
import { archiveInterruptedManagementLock, ManagementLockError, takeManagementLock } from './management-lock.mjs';
import { ensureManagementAccess } from './management-onboarding.mjs';
import { portalAccessReady, validatePortalUrl } from './portal-readiness.mjs';
import { managementRelease } from './management-release.mjs';
import { proveManagementSso, removeSsoProof } from './management-sso.mjs';
import { createManagementTerminal, InstallationCancelled, terminalLabel } from './management-terminal.mjs';
import { ensurePrivateDirectory, readPrivateFile, writePrivateFile } from './private-directory.mjs';
import { applySetup, directManagementProvider, isAdministratorEmail, isDeploymentNamespace, makeSetupSpec, managementAccessConfiguration, workersSubdomainName } from './setup-core.mjs';

async function chooseListed(options, label, prompt, ui) {
  if (options.length === 1) {
    const [only] = options;
    ui.success(`${label} · ${only.label}（已自动选择）`);
    return only.value;
  }
  return ui.select(prompt, options);
}

export async function chooseManagementZone(api, ui) {
  const accounts = await api.list('/accounts', { per_page: 50 });
  if (!accounts.length) {
    throw new Error('本次授权未返回可用的 Cloudflare 账户。请重新运行安装命令，并在浏览器中授权要部署的账户。');
  }
  const accountLabels = accounts.map(value => terminalLabel(value.name) || '未命名账户');
  let account;
  while (true) {
    account ??= await chooseListed(accounts.map((value, index) => {
      const label = accountLabels[index];
      return {
        value,
        label: accountLabels.indexOf(label) === accountLabels.lastIndexOf(label)
          ? label : `[…${terminalLabel(value.id).slice(-8)}] ${label}`,
      };
    }), 'Cloudflare 账户', '选择 Cloudflare 账户', ui);
    const zones = (await api.list('/zones', { 'account.id': account.id, status: 'active', per_page: 50 }))
      .filter(zone => zone.account?.id === account.id && zone.status === 'active' &&
        !/(^|\.)(workers|pages)\.dev$/.test(zone.name));
    if (!zones.length) {
      ui.info(`Cloudflare 账户「${terminalLabel(account.name) || '未命名账户'}」下没有可用的已激活域名。请在该账户控制台添加或激活域名，再选择重新检测；无需重新授权。`);
      const action = await ui.select('下一步', [
        ...(accounts.length > 1 ? [{ value: 'back', label: '返回账户选择' }] : []),
        { value: 'retry', label: '已配置域名，重新检测' },
        { value: 'cancel', label: '取消安装' },
      ]);
      if (action === 'cancel') throw new InstallationCancelled();
      if (action === 'back') account = undefined;
      continue;
    }
    return chooseListed(zones.map(value => ({ value, label: terminalLabel(value.name) })), '部署域名', '选择部署域名', ui);
  }
}

export async function getManagementOwnerEmail(api) {
  const profile = await api.get('/user').catch(error => {
    if (error.status === 401 || error.status === 403) {
      throw new Error(`Cloudflare 没有允许读取当前登录邮箱。请重新授权用户资料只读权限（${managementIdentityScope}），并确认发行客户端已启用该权限。`);
    }
    throw new Error('暂时无法读取 Cloudflare 登录邮箱。请检查网络后重试安装。');
  });
  if (typeof profile?.email !== 'string' || !isAdministratorEmail(profile.email) ||
      profile.suspended === true || profile.email_verified === false) {
    throw new Error('Cloudflare 未返回可用的登录邮箱。请在 Cloudflare 核对账户邮箱和账户状态，再重试安装。');
  }
  return profile.email;
}

function readinessSignal(signal) {
  const timeout = AbortSignal.timeout(5000);
  return signal ? AbortSignal.any([signal, timeout]) : timeout;
}

async function managementAccessReady(management, issuer, request, signal) {
  try {
    const response = await request(management, { redirect: 'manual', headers: { Accept: 'text/html' }, signal: readinessSignal(signal) });
    await response.body?.cancel();
    if (![302, 303].includes(response.status)) return false;
    const login = new URL(response.headers.get('Location'));
    return login.origin === issuer && login.pathname === '/cdn-cgi/access/login/' + new URL(management).hostname;
  } catch { return false; }
}

export async function waitForManagementAccess(management, issuer, releases, {
  timeoutMs = 15 * 60 * 1000, intervalMs = 10000, request = fetch, signal, portal, onProgress,
} = {}) {
  if (portal !== undefined) validatePortalUrl(portal);
  const bootstraps = Object.entries(hostedInstallers(releases)).map(([platform, group]) => {
    const url = new URL(installPath(platform), management);
    url.searchParams.set('version', group.version);
    return { platform, url: url.href, expected: Buffer.from(bootstrapInstaller(url.origin, platform, group)) };
  });
  const bootstrapReady = async ({ url, expected }) => {
    try {
      const response = await request(url, { redirect: 'manual', signal: readinessSignal(signal) });
      if (response.status !== 200 || !response.body || response.headers.get('Content-Type')?.split(';')[0].trim() !== 'text/plain') {
        await response.body?.cancel();
        return false;
      }
      const reader = response.body.getReader();
      let offset = 0;
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) return offset === expected.length;
          const end = offset + value.length;
          if (end > expected.length || !expected.subarray(offset, end).equals(value)) return false;
          offset = end;
        }
      } finally {
        await reader.cancel().catch(() => {});
      }
    } catch { return false; }
  };
  const deadline = Date.now() + timeoutMs;
  do {
    signal?.throwIfAborted();
    const [login, mcp, ...installers] = await Promise.all([
      managementAccessReady(management, issuer, request, signal),
      portal ? portalAccessReady(portal, issuer, request, signal) : undefined,
      ...bootstraps.map(bootstrapReady),
    ]);
    signal?.throwIfAborted();
    onProgress?.({ login, portal: mcp,
      installers: bootstraps.map(({ platform }, index) => ({ platform, ready: installers[index] })),
    });
    if (login && mcp !== false && installers.every(Boolean)) return true;
    const remaining = deadline - Date.now();
    if (remaining <= 0) return false;
    await sleep(Math.min(intervalMs, remaining), undefined, { signal });
  } while (Date.now() < deadline);
  return false;
}

function readinessItems({ login, portal, installers } = {}) {
  const waiting = installers?.filter(({ ready }) => !ready)
    .map(({ platform }) => operatingSystems[platform].label);
  return [
    ['管理台登录入口', login],
    ...(portal === undefined ? [] : [['MCP 客户端连接入口', portal]]),
    ...(installers?.length ? [[`设备安装命令的脚本下载${waiting.length ? '（' + waiting.join('、') + '）' : ''}`, !waiting.length]] : []),
  ];
}

function readinessError(management, accessIssuer, interactive = false, portal, lastCheck) {
  const portalOption = portal ? ` --portal ${portal}` : '';
  if (interactive) {
    const pending = readinessItems(lastCheck).filter(([, ready]) => !ready).map(([label]) => label);
    return new Error(`部署已提交，但以下项目暂未通过检查：${pending.join('、')}。管理台地址：${management}。`);
  }
  return new Error(`The management Access login, MCP Portal or a signed device installer is not ready at ${management}. ` +
    `After Cloudflare propagation, run the same installation command with --check ${management} ${accessIssuer}${portalOption}.`);
}

export async function checkManagementReadiness(management, accessIssuer, releases, options) {
  const site = new URL(management);
  if (site.protocol !== 'https:' || site.href !== site.origin + '/' || site.port ||
      !/^https:\/\/[a-z0-9-]+\.cloudflareaccess\.com$/.test(accessIssuer)) {
    throw new Error('Supply a management HTTPS origin and its exact Cloudflare Access issuer.');
  }
  if (!await waitForManagementAccess(site.origin, accessIssuer, releases, { ...options, timeoutMs: 0 })) {
    throw readinessError(site.origin, accessIssuer, false, options?.portal);
  }
  return site.origin;
}

export async function openManagementWhenReady({ management, portal, accessIssuer }, releases, { ui, ...options } = {}) {
  if (ui) {
    try {
      let lastCheck;
      await ui.wait('部署已提交，正在检查登录和连接入口（最长 15 分钟，无需操作）', '登录、连接和下载检查通过', async (signal, update) => {
        const ready = await waitForManagementAccess(management, accessIssuer, releases, {
          ...options, signal, portal, onProgress(state) {
            lastCheck = state;
            const items = readinessItems(state);
            const passed = items.filter(([, ok]) => ok).length;
            update?.(`部署检查 ${passed}/${items.length} 项 · ` +
              items.map(([label, ok]) => `${label}：${ok ? '已通过' : '等待生效'}`).join(' · '));
            options.onProgress?.(state);
          },
        });
        if (!ready) throw readinessError(management, accessIssuer, true, portal, lastCheck);
      });
    } catch (error) {
      if (error instanceof InstallationCancelled) {
        ui.info(`Cloudflare 已接受部署。稍后可打开管理台：${management}。`);
      }
      throw error;
    }
    ui.note(`管理台     ${management}\nMCP Portal  ${portal}`, '安装完成');
    ui.finish('正在打开管理台。请先完成登录，再选择「添加设备」开始接入。MCP 客户端授权仍需在客户端完成。');
  } else {
    console.log('Waiting up to 15 minutes for the Cloudflare Access login, MCP Portal and hosted device installers...');
    if (!await waitForManagementAccess(management, accessIssuer, releases, { ...options, portal })) throw readinessError(management, accessIssuer, false, portal);
    console.log(`Nodrelay management console is ready at ${management}`);
  }
  openBrowser(management);
}

async function storeState(file, state) {
  const temporary = file + '.' + randomBytes(6).toString('hex');
  try {
    await writePrivateFile(temporary, JSON.stringify(state));
    await rename(temporary, file);
  } finally {
    await rm(temporary, { force: true });
  }
}

export async function verifyManagementZone(api, zone) {
  if (!/^[a-f0-9]{32}$/.test(zone.id ?? '') || !/^[a-f0-9]{32}$/.test(zone.account?.id ?? '')) {
    throw new Error('Cloudflare returned an invalid account or domain identifier.');
  }
  const current = await api.get('/zones/' + zone.id);
  if (current?.id !== zone.id || current.status !== 'active' ||
      current.name !== zone.name || current.account?.id !== zone.account.id) {
    throw new Error('所选的 Cloudflare 域名或账户已变更。请重新运行安装命令并选择要部署的账户和域名。');
  }
  return current;
}

const reconnectSecret = 'FLEET_OAUTH_RECONNECT';

export async function reconnectManagement(api, spec, clientId, grant, { userDetails = false, zeroTrustBootstrap = false } = {}) {
  if (!usableStoredGrant(grant) || grant.expiresAt <= Math.floor(Date.now() / 1000) + 45) {
    throw new Error('The new Cloudflare authorization has expired. Start authorization recovery again.');
  }
  const script = `/accounts/${spec.accountId}/workers/scripts/${spec.worker}`;
  const settings = await api.get(script + '/settings');
  const bindings = new Map((settings?.bindings ?? []).map(binding => [binding.name, binding]));
  const plain = name => bindings.get(name)?.type === 'plain_text' ? bindings.get(name).text : undefined;
  const hosted = JSON.parse(plain('FLEET_SPEC') ?? 'null');
  if (plain('FLEET_OAUTH_MODE') !== 'managed' || plain('FLEET_OAUTH_RECOVERY') !== '1' ||
      (plain('FLEET_OAUTH_USER_DETAILS') === '1') !== userDetails ||
      (plain('FLEET_OAUTH_ZERO_TRUST_BOOTSTRAP') === '1') !== zeroTrustBootstrap ||
      plain('FLEET_OAUTH_CLIENT_ID') !== clientId || plain('APP_ORIGIN') !== spec.origin ||
      plain('OWNER_EMAIL') !== spec.ownerEmail || !hosted?.accountScopedAccess ||
      !Object.entries(spec).every(([name, value]) => hosted[name] === value) ||
      bindings.get('FLEET_OAUTH_KEY')?.type !== 'secret_text' ||
      bindings.get('PROVISIONER_OAUTH')?.type !== 'durable_object_namespace') {
    throw new Error('The live management Worker and OAuth client do not match this saved installation or support reconnect.');
  }
  if (bindings.has(reconnectSecret)) throw new Error('A reconnect is already staged. Read the management status to finish it before trying again.');
  const deployment = (await api.get(script + '/deployments'))?.deployments?.[0]?.versions;
  const latest = (await api.get(script + '/versions', { per_page: 1 }))?.items?.[0]?.id;
  if (!latest || deployment?.length !== 1 || deployment[0].percentage !== 100 || deployment[0].version_id !== latest) {
    throw new Error('The Worker has a pending or split deployment. Review its versions before reconnecting.');
  }
  const generation = randomBytes(16).toString('hex');
  await api.put(script + '/secrets', { name: reconnectSecret, type: 'secret_text', text: JSON.stringify({ generation, clientId, grant }) });
  return spec.origin;
}

async function confirmManagementAction(ui, message, action, initialValue = true) {
  if (!await ui.confirm(message, action, initialValue)) throw new InstallationCancelled();
}

async function readManagementState(path) {
  const old = await readPrivateFile(path).catch(error => { if (error.code !== 'ENOENT') throw error; });
  return old === undefined ? undefined : JSON.parse(old);
}

function checkedSetupSpec(state, zone, ownerEmail, namespace) {
  const spec = makeSetupSpec({ ownerEmail, namespace }, zone, state.installationId);
  if (state.spec && JSON.stringify(state.spec) !== JSON.stringify(spec)) {
    throw new Error('回执与当前安装目标或管理员邮箱不符。请核对原账户、域名、邮箱和部署名称。');
  }
  return spec;
}

function checkRecoveryOAuth(state, release) {
  if (Boolean(state.oauthZeroTrustBootstrap) !== Boolean(release.zeroTrustBootstrap) || Boolean(state.oauthUserDetails) !== release.automaticAdministrator ||
      (state.oauthClientId && state.oauthClientId !== release.clientId)) {
    throw new Error('当前安装包的 Cloudflare 授权配置与原安装回执不符。请使用原签名安装包恢复。');
  }
}

export function automaticResumeSpec(state, release, grant, zone, profileEmail, namespace) {
  if (!state) return;
  if (state.bound) {
    checkRecoveryOAuth(state, release);
    const spec = checkedSetupSpec(state, zone, state.spec?.ownerEmail, namespace);
    throw new Error(`此目标已有完成回执：${spec.origin}。未重新部署。`);
  }
  if (state.ssoProof) throw new Error('上次临时 Access 登录验证尚未清理。未自动继续，也未改动 Cloudflare。');
  if (!state.spec) {
    throw new Error('上次 Zero Trust 初始化尚未形成完整部署回执，未自动继续。');
  }
  checkRecoveryOAuth(state, release);
  if (state.oauthClientId !== release.clientId) throw new Error('缺少原安装回执的 Cloudflare OAuth 客户端记录；未自动续跑。');
  const granted = release.zeroTrustBootstrap === true && grant.zeroTrustBootstrap === true;
  if (Boolean(state.oauthBootstrapGranted) !== granted) {
    const option = state.oauthBootstrapGranted ? '保留' : '取消';
    throw new Error(`本次授权与原回执不符。请重新授权并${option}「Access: Organizations, Identity Providers, and Groups Write」。`);
  }
  const spec = checkedSetupSpec(state, zone, state.spec.ownerEmail, namespace);
  if (typeof profileEmail !== 'string' || !isAdministratorEmail(profileEmail) ||
      (state.oauthProfileEmail !== undefined && (typeof state.oauthProfileEmail !== 'string' || state.oauthProfileEmail.toLowerCase() !== profileEmail.toLowerCase())) ||
      (!state.ssoIdentity && state.spec.ownerEmail.toLowerCase() !== profileEmail.toLowerCase())) {
    throw new Error('当前 Cloudflare 登录身份与原安装回执不符；未改动 Cloudflare。');
  }
  if (state.pendingCreates !== undefined && (!Array.isArray(state.pendingCreates) || state.pendingCreates.length)) {
    let resource = 'Cloudflare 资源';
    try {
      const [path, name] = JSON.parse(state.pendingCreates[0]);
      resource = [safeCloudflareRoute(path), terminalLabel(name)].filter(Boolean).join(' · ');
    } catch { /* Unreadable journal must also fail closed. */ }
    throw new Error(`上次创建结果尚未确认：${resource}。未重新发送创建请求。`);
  }
  if (!release.automaticAdministrator || state.trial || state.draft ||
      !/^(?:[a-f0-9]{32}|[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})$/i.test(state.databaseId ?? '') ||
      !/^[A-Za-z0-9_-]{43}$/.test(state.ticketKey ?? '') ||
      !/^[A-Za-z0-9_-]{43}$/.test(state.oauthKey ?? '')) {
    throw new Error('原回执尚未完成 Worker 上传前的资源配置，或缺少 D1 / Worker 凭据记录。未自动续跑。');
  }
  return spec;
}

function resumeWriteError(path, body) {
  const route = safeCloudflareRoute(path);
  const name = terminalLabel(body?.name ?? body?.id);
  return new Error(`无法只读确认上次配置的资源：${route}${name ? ' · ' + name : ''}。未重建该资源。`);
}

export async function verifyAutomaticResume(api, spec, options) {
  const { state } = options;
  if (state.workersSubdomainAttempt !== undefined) {
    const expected = workersSubdomainName(spec.accountId);
    if (state.workersSubdomainAttempt !== expected) throw new Error('回执中的账户 Workers 子域不符。');
    const actual = await api.get(`/accounts/${spec.accountId}/workers/subdomain`).catch(error => {
      if (error.codes?.length === 1 && error.codes[0] === 10007) return null;
      throw error;
    });
    if (actual?.subdomain !== expected) {
      throw new Error('上次账户 Workers 子域注册结果尚未确认。未重复注册；请在 Cloudflare 核对。');
    }
  }
  const blocked = async (path, body) => { throw resumeWriteError(path, body); };
  const readOnly = { get: (...args) => api.get(...args), getOptional: (...args) => api.getOptional(...args),
    list: (...args) => api.list(...args), post: blocked, put: blocked, patch: blocked, del: blocked };
  await applySetup(readOnly, spec, { ...options, verifyPartial: true, save() { throw new Error('Unexpected receipt write during verification'); } });
}

export function guardAutomaticResumeWrites(api, spec, databaseId) {
  const account = `/accounts/${spec.accountId}/workers`;
  const script = `${account}/scripts/${spec.worker}`;
  return {
    ...api,
    async post(path, body) {
      if (path === script + '/subdomain' || `/accounts/${spec.accountId}/d1/database/${databaseId}/query` === path) {
        return api.post(path, body);
      }
      throw resumeWriteError(path, body);
    },
    async put(path, body) {
      if ([account + '/subdomain', account + '/domains', script].includes(path)) return api.put(path, body);
      throw resumeWriteError(path, body);
    },
    async patch(path, body) { throw resumeWriteError(path, body); },
    async del(path) { throw resumeWriteError(path); },
  };
}

export function trackManagementCreates(api, state, save, confirmRetry) {
  return { ...api, async post(path, body) {
    // These POSTs apply an existing setting or idempotent schema. Resource
    // creation POSTs may commit even if the response never reaches the installer.
    if (path.endsWith('/query') || path.endsWith('/subdomain')) return api.post(path, body);
    const name = body.name ?? body.id;
    const creation = JSON.stringify([path, name]);
    if (state.confirmedCreates?.includes(creation)) {
      throw new Error(`Cloudflare 曾确认创建资源「${name}」，但当前查询未找到它。请核对原资源，安装器已停止，避免重复创建。`);
    }
    state.pendingCreates ??= [];
    if (state.pendingCreates.includes(creation)) {
      await confirmRetry(path, name);
    } else {
      state.pendingCreates.push(creation);
      await save(state);
    }
    const result = await api.post(path, body);
    state.pendingCreates = state.pendingCreates.filter(item => item !== creation);
    if (!state.pendingCreates.length) delete state.pendingCreates;
    state.confirmedCreates ??= [];
    state.confirmedCreates.push(creation);
    await save(state);
    return result;
  } };
}

async function runDeploymentWork(ui, grant, work, request) {
  const controller = new AbortController();
  const stop = () => {
    if (controller.signal.aborted) return;
    controller.abort(new InstallationCancelled());
    ui.info(`已收到中止请求。单次 Cloudflare 请求（含读取响应）最多等待 ${cloudflareRequestTimeoutMs / 1000} 秒，之后停止发送请求。`);
  };
  // Keep the lock while an in-flight request settles. Abort at the next
  // request boundary so its outcome can still be recorded in the receipt.
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
  try {
    const api = cloudflareApi(grant.access, { request, beforeRequest: () => controller.signal.throwIfAborted() });
    const result = await work(api);
    return { ...result, interrupted: controller.signal.aborted };
  } catch (error) {
    if (!(error instanceof CloudflareRequestTimeoutError)) throw error;
    const outcome = error.method === 'GET' ? '' : '该次写入结果未确认，请核对 Cloudflare 审计日志。';
    throw new Error(`Cloudflare ${error.method} 请求在 ${error.timeoutMs / 1000} 秒内未完成。${outcome}`, { cause: error });
  } finally {
    process.off('SIGINT', stop);
    process.off('SIGTERM', stop);
  }
}

function deploymentSummary(spec) {
  return `管理台      ${spec.origin}\nMCP Portal  https://${spec.portalHostname}/mcp\n管理员邮箱  ${spec.ownerEmail}`;
}

export async function deployManagement(ui, release, grant, zone, profileEmail, namespace, { reconnect, resume }, {
  request, home = homedir(), previewAccount = process.env.NODRELAY_PREVIEW_BOOTSTRAP_ACCOUNT,
} = {}) {
  const bootstrapGranted = release.zeroTrustBootstrap === true && grant.zeroTrustBootstrap === true;
  const top = join(home, '.nodrelay');
  const directory = join(top, 'management');
  await ensurePrivateDirectory(top);
  await ensurePrivateDirectory(directory);
  const target = createHash('sha256').update(JSON.stringify([zone.account.id, zone.id, namespace])).digest('hex').slice(0, 24);
  const path = join(directory, target + '.json');
  const lockPath = path + '.lock';
  let releaseLock;
  let archived = false;
  try { releaseLock = await takeManagementLock(lockPath); }
  catch (error) {
    if (!resume || !(error instanceof ManagementLockError) || error.kind !== 'interrupted') throw error;
    const saved = await readManagementState(path);
    if (saved?.spec || saved?.ssoProof || saved?.zeroTrustBootstrap) checkRecoveryOAuth(saved, release);
    if (saved?.spec) checkedSetupSpec(saved, zone, saved.spec.ownerEmail, namespace);
    ui.note(`上次安装进程 PID ${error.owner.pid} 已退出。旧锁会归档，安装回执会保留。\n锁文件  ${error.path}`, '发现中断的安装');
    await confirmManagementAction(ui, '确认归档这把中断的锁？', '归档旧锁', false);
    await archiveInterruptedManagementLock(lockPath, error.owner);
    releaseLock = await takeManagementLock(lockPath);
    archived = true;
  }
  try {
    const saved = await readManagementState(path);
    const state = saved ?? {
      installationId: randomBytes(6).toString('hex'), ticketKey: randomBytes(32).toString('base64url'),
    };
    const save = next => storeState(path, next);
    const api = cloudflareApi(grant.access, { request });
    if (state.ssoProof) {
      if (!resume || state.spec || state.bound) throw new Error('找到未清理的临时登录应用。未自动继续。');
      checkRecoveryOAuth(state, release);
      ui.note(`临时应用  ${terminalLabel(state.ssoProof.name)}`, '上一次 SSO 登录验证未清理');
      const removed = await ui.wait('正在核对并清理临时登录应用', '已核对临时登录应用', () =>
        removeSsoProof(api, zone.account.id, state.ssoProof));
      if (!removed) {
        ui.note('Cloudflare 当前未列出该应用。请查看审计日志，确认它未被创建，或已被删除，再清除本地回执。', '核对上一次创建结果');
        await confirmManagementAction(ui, '已核对审计日志，确认临时应用不存在？', '清除回执', false);
      }
      delete state.ssoProof;
      await save(state);
      return { recoveryOnly: '临时登录验证已清理。请重新运行原安装命令开始安装。' };
    }
    if (state.spec || state.zeroTrustBootstrap) checkRecoveryOAuth(state, release);
    // Once deployment has a target receipt, do not silently change the
    // permissions expected by an uploaded or partly deployed Worker.
    if (state.spec && Boolean(state.oauthBootstrapGranted) !== bootstrapGranted) {
      const option = state.oauthBootstrapGranted ? '保留' : '取消';
      throw new Error(`本次授权与原管理台的实际权限不符。请重新授权并${option}「Access: Organizations, Identity Providers, and Groups Write」。`);
    }
    if (resume && (state.bound || (!state.spec && !state.zeroTrustBootstrap))) {
      if (!archived) throw new Error('此目标没有未完成的安装回执。请核对账户、域名和部署名称。');
      if (state.spec) checkedSetupSpec(state, zone, state.spec.ownerEmail, namespace);
      const next = state.bound
        ? '此目标已有完成回执。可打开原管理台查看。若中断时正在恢复授权，请先在管理台查看授权恢复状态。'
        : '未找到安装回执。请在 Cloudflare 中核对该目标的资源和审计日志，确认没有上次遗留的部署后，再运行原安装命令。';
      return { recoveryOnly: next };
    }
    if (reconnect && (!state.bound || state.managedOAuth !== true || !state.spec)) {
      throw new Error('恢复授权需要原管理台的已完成安装回执。');
    }
    if (reconnect) {
      const spec = checkedSetupSpec(state, zone, state.spec.ownerEmail, namespace);
      ui.note(deploymentSummary(spec), '现有诺联管理台');
      await confirmManagementAction(ui, '更新此管理台保存的 Cloudflare 授权？', '恢复授权', false);
      ui.info('正在核对现有部署并提交新授权…');
      return await runDeploymentWork(ui, grant, async api => ({
        management: await reconnectManagement(api, spec, release.clientId, grant, { userDetails: release.automaticAdministrator, zeroTrustBootstrap: bootstrapGranted }),
      }), request).catch(error => {
        ui.info('请先在管理台查看是否已有待生效的授权，再重试授权恢复。');
        throw error;
      });
    }
    const automatic = Boolean(automaticResumeSpec(saved, release, grant, zone, profileEmail, namespace));
    let ownerEmail = state.spec?.ownerEmail ?? profileEmail;
    let ssoIdentity = state.ssoIdentity;
    let loginSummary = '';
    if (release.automaticAdministrator) {
      const access = automatic
        ? await managementAccessConfiguration(api, zone.account.id)
        : await runDeploymentWork(ui, grant, requestApi => ensureManagementAccess(requestApi, zone.account.id, {
          ui, state, browse: openBrowser, allowCreate: bootstrapGranted,
          // Explicit preview opt-in is scoped to the selected test account.
          allowNotEnabledMarkerBootstrap:
            previewAccount === zone.account.id,
          async save(next) {
            next.oauthUserDetails = true;
            next.oauthZeroTrustBootstrap = release.zeroTrustBootstrap === true;
            next.oauthClientId = release.clientId;
            await save(next);
          },
        }), request);
      if (access.interrupted) throw new InstallationCancelled();
      const { issuer, providers } = access;
      const direct = providers.filter(directManagementProvider);
      if (ssoIdentity) {
        const provider = providers.find(({ id }) => id === ssoIdentity.providerId);
        if (ssoIdentity.issuer !== issuer || !provider) throw new Error('原回执的 SSO 登录方式已变更。请让账户管理员核对后再恢复。');
        loginSummary = `\n原 SSO 登录  ${terminalLabel(provider.name) || terminalLabel(provider.type)}`;
      } else if (direct.length) {
        // Login methods are shown by Cloudflare when the management console opens.
      } else if (resume || automatic) {
        throw new Error('原部署没有经过验证的 SSO 登录方式。请让账户管理员恢复原登录方式后继续，安装器会保留原管理员。');
      } else {
        const provider = await chooseListed(providers.map(value => ({ value, label: terminalLabel(value.name) || terminalLabel(value.type) })),
          'SSO 登录方式', '选择用于管理台的现有 SSO 登录方式', ui);
        ui.note('诺联将创建一个仅用于核验身份的临时 Access 应用，验证结束后清理。请在浏览器中用准备管理诺联的身份登录。', '验证 SSO 身份');
        await confirmManagementAction(ui, '允许创建临时登录应用并打开浏览器？', '验证身份');
        try {
          const { email, ...identity } = await ui.wait('等待浏览器完成 SSO 验证（最长 5 分钟）', 'SSO 邮箱已验证', signal =>
            proveManagementSso(api, { accountId: zone.account.id, issuer, providerId: provider.id, redirectUri: release.redirectUri, signal,
              async save(proof) {
                if (proof) {
                  state.ssoProof = proof;
                  state.oauthUserDetails = true;
                  state.oauthZeroTrustBootstrap = release.zeroTrustBootstrap === true;
                  state.oauthClientId = release.clientId;
                } else {
                  delete state.ssoProof;
                }
                await save(state);
              },
            }));
          ownerEmail = email;
          ssoIdentity = identity;
        } finally {
          if (state.ssoProof) ui.info('临时登录验证尚未清理，已保留回执。');
        }
        loginSummary = `\n已验证登录  ${terminalLabel(provider.name) || terminalLabel(provider.type)}`;
        if (ownerEmail !== profileEmail) loginSummary += `\nCloudflare 授权邮箱  ${profileEmail}\n管理台使用上面已验证的 SSO 邮箱。`;
      }
    }
    const spec = checkedSetupSpec(state, zone, ownerEmail, namespace);
    if (automatic) {
      ui.note(deploymentSummary(spec) + loginSummary, '发现同一部署的未完成回执');
    } else {
      ui.note(deploymentSummary(spec) + loginSummary, resume ? '继续同一部署' : '即将部署');
    }
    if (!automatic) {
      await confirmManagementAction(ui, '邮箱和部署地址正确，并同意在 Worker 中保存可续期的 Cloudflare 授权？', '确认部署');
    }
    ui.info('正在部署 Cloudflare 资源…');
    return await runDeploymentWork(ui, grant, async api => {
      const managedOAuth = { clientId: release.clientId, grant, userDetails: release.automaticAdministrator };
      if (automatic) {
        await verifyAutomaticResume(api, spec, { state, managedOAuth, releases: release.releases });
        ui.info('已核实同一部署的现有资源，继续上传 Worker。');
      }
      state.spec = spec;
      if (profileEmail) state.oauthProfileEmail = profileEmail;
      state.oauthBootstrapGranted = bootstrapGranted;
      state.oauthClientId = release.clientId;
      if (release.automaticAdministrator) state.oauthUserDetails = true;
      state.oauthZeroTrustBootstrap = release.zeroTrustBootstrap === true;
      if (ssoIdentity) state.ssoIdentity = ssoIdentity;
      await save(state);
      const migrations = (await Promise.all(['0001_tickets.sql', '0002_devices.sql', '0003_portal_callback_labels.sql']
        .map(file => readFile(new URL('../cloud/' + file, import.meta.url), 'utf8'))))
        .flatMap(sql => sql.split(';').map(statement => statement.trim()).filter(Boolean));
      const tracked = trackManagementCreates(api, state, save, async (endpoint, name) => {
        throw resumeWriteError(endpoint, { name });
      });
      const result = await applySetup(automatic ? guardAutomaticResumeWrites(api, spec, state.databaseId) : tracked, spec, {
        state, save, bundle: release.bundle, migrations, releases: release.releases,
        managedOAuth, safeResume: automatic,
        async confirmWorkersSubdomain(name) {
          ui.note(`Cloudflare 需要为此账户注册 Workers 子域 ${name}.workers.dev。诺联仍使用所选自定义域名，不开启公开 Workers 地址或预览地址。`, '首次启用 Workers');
          await confirmManagementAction(ui, '为这个账户注册 Workers 子域并继续安装？', '确定');
        },
      });
      if (state.pendingCreates || state.confirmedCreates) {
        delete state.pendingCreates;
        delete state.confirmedCreates;
        await save(state);
      }
      return result;
    }, request).catch(error => {
      ui.info('已保留本地回执。不会自动重复提交结果不明的创建请求。');
      throw error;
    });
  } finally {
    await releaseLock();
  }
}

async function main() {
  const { positionals, values } = parseArgs({
    allowPositionals: true,
    options: {
      plan: { type: 'boolean' }, check: { type: 'boolean' }, reconnect: { type: 'boolean' }, resume: { type: 'boolean' },
      namespace: { type: 'string' }, portal: { type: 'string' },
    },
  });
  if (positionals.length !== (values.check ? 4 : 2) ||
      [values.plan, values.check, values.reconnect, values.resume].filter(Boolean).length > 1 ||
      ((values.plan || values.check) && values.namespace !== undefined) || (values.portal !== undefined && !values.check)) {
    throw new Error('Usage: setup-macos.sh SIGNED_MANIFEST TRUSTED_PUBLISHER_KEY [--plan | --check MANAGEMENT_ORIGIN ACCESS_ISSUER [--portal PORTAL_URL] | [--reconnect | --resume] [--namespace NAME]]');
  }
  const namespace = values.namespace ?? 'nodrelay';
  if (!isDeploymentNamespace(namespace)) {
    throw new Error('部署名称应为 3–16 个字符，以小写字母开头，只能包含小写字母、数字和连字符。');
  }
  const [manifest, publisherKey, origin, issuer] = positionals;
  const release = await managementRelease(resolve(manifest), resolve(publisherKey));
  const scopes = release.zeroTrustBootstrap ? managementBootstrapOAuthScopes : release.automaticAdministrator ? managementIdentityOAuthScopes : managementOAuthScopes;
  if (values.check) {
    const ready = await checkManagementReadiness(origin, issuer, release.releases, { portal: values.portal });
    console.log(`Nodrelay management console is ready at ${ready}`);
    return;
  }
  if (values.plan) {
    console.log(JSON.stringify({ permissionScopes: scopes, platforms: Object.keys(hostedInstallers(release.releases)),
      deviceTargets: Object.entries(release.releases).map(([platform, { version, browser }]) => ({ platform, version, browser })),
      deviceAssets: 'versioned HTTPS downloads', automaticAccountDiscovery: true,
      automaticDomainDiscovery: true, automaticAdministratorDiscovery: release.automaticAdministrator,
      oauthTokenProvisioning: false }, null, 2));
    return;
  }
  if (!process.stdin.isTTY || !process.stdout.isTTY || process.env.TERM === 'dumb') {
    throw new Error('请在 Mac 的交互式终端运行安装命令。');
  }
  const recovery = values.reconnect || values.resume;
  if (!recovery && !release.automaticAdministrator) {
    throw new Error(`这个签名安装包尚未验证 Cloudflare 用户资料只读权限（${managementIdentityScope}）。请使用支持自动识别管理员的新安装包。`);
  }
  const ui = createManagementTerminal();
  ui.intro(values.reconnect ? '诺联 Nodrelay · 恢复管理台授权'
    : values.resume ? '诺联 Nodrelay · 继续管理台部署' : '诺联 Nodrelay · 管理台安装');
  try {
    ui.step(1, '授权 Cloudflare');
    ui.note([
      '读取账户与域名，配置 DNS、Worker、D1、Access、Tunnel 和 MCP Portal。',
      ...(release.automaticAdministrator ? ['请保留「User Details Read」，用于识别新部署的管理员邮箱。'] : []),
      ...(release.zeroTrustBootstrap ? ['可选账户级写权限：允许时可初始化 Zero Trust 组织和邮箱验证码登录，且此权限会保留在 Worker 授权中。取消后仍可部署已配置 Zero Trust 的账户。不选择套餐或付款。'] : []),
      'Worker 保存可续期授权，用于持续管理设备。设备各自使用独立凭据。',
      '请只授权要部署的账户。Worker 的授权覆盖你在浏览器中批准的所有账户。',
      '', scopes.join(' · '),
    ].join('\n'), 'Cloudflare 权限');
    const grant = await ui.wait('请在浏览器登录并授权，完成后回到终端（Ctrl+C 取消）', 'Cloudflare 授权完成', signal =>
      authorize({ clientId: release.clientId, redirectUri: release.redirectUri, scopes,
        startThroughLoopback: true, refreshable: true, timeoutMs: 600000, signal }));
    const api = cloudflareApi(grant.access);
    ui.step(2, '选择账户与部署域名');
    const zone = await verifyManagementZone(api, await chooseManagementZone(api, ui));
    ui.step(3, recovery ? '使用原回执中的管理员' : '识别管理员');
    const ownerEmail = values.reconnect || !release.automaticAdministrator ? undefined : await getManagementOwnerEmail(api);
    ui.step(4, values.reconnect ? '确认并恢复授权' : values.resume ? '核对并继续部署' : '确认并部署');
    const result = await deployManagement(ui, release, grant, zone, ownerEmail, namespace, values);
    if (result.recoveryOnly) {
      ui.finish(result.recoveryOnly);
      return;
    }
    if (result.interrupted) {
      const next = values.reconnect
        ? '新授权已提交。请登录管理台，在「客户端回调设置」中完成恢复。'
        : `Cloudflare 已接受部署。稍后可打开管理台：${result.management}。`;
      ui.info(next);
      throw new InstallationCancelled();
    }
    if (values.reconnect) {
      ui.success(`新授权已提交至 ${result.management}`);
      ui.finish('正在打开管理台。登录后进入「客户端回调设置」完成授权恢复。');
      openBrowser(result.management);
      return;
    }
    ui.success('Cloudflare 已接受部署');
    await openManagementWhenReady(result, release.releases, { ui });
  } catch (error) {
    if (error instanceof InstallationCancelled) {
      ui.cancel();
      process.exitCode = 1;
    } else {
      ui.error(error.name === 'SyntaxError' ? '诺联发行文件或 Cloudflare 响应格式无效。' : error.message);
      process.exitCode = 1;
    }
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { await main(); }
  catch (error) {
    console.error(error.name === 'SyntaxError' ? 'Invalid Nodrelay release or Cloudflare response' : error.message);
    process.exitCode = 1;
  }
}
