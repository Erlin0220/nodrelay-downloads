# Shared Node download for the Cloudflare management installers.

fleet_node_platform() {
  node_version=24.22.0
  case "$(uname -s):$(uname -m)" in
    Darwin:arm64) platform=darwin-arm64; node_hash=6a9724d9b50a5f22b4816cded441b5a8d9ddae546191a5e5b7efa5a5e2ee26d5 ;;
    Darwin:x86_64) platform=darwin-x64; node_hash=495e3f273c645f3c4677d438304cdfc701729ea5dec5728f5c8e76a2dece4b91 ;;
    Linux:aarch64|Linux:arm64) platform=linux-arm64; node_hash=b7e7991d5407815adfa74a2a9cd4db683552c8ce32ff4a295c22e972849c3f5d ;;
    Linux:x86_64) platform=linux-x64; node_hash=28ea0a438de9a13bd7891fd758eee6c7819ee8af5442dfd8d45bd65e56d4228c ;;
    *) echo 'Node setup supports macOS and Linux on arm64 or x64.' >&2; return 2 ;;
  esac
}

fleet_download() {
  curl --disable --fail --show-error --silent --location --max-redirs 5 --connect-timeout 15 --max-time 300 \
    --proto '=https' --proto-redir '=https' --output "$2" "$1"
}

fleet_prepare_node() {
  node_archive="node-v$node_version-$platform"
  fleet_download "https://nodejs.org/dist/v$node_version/$node_archive.tar.gz" "$1/node.tgz" || return
  if command -v sha256sum >/dev/null 2>&1; then
    node_digest=$(sha256sum "$1/node.tgz")
  else
    node_digest=$(shasum -a 256 "$1/node.tgz")
  fi
  [ "$node_hash" = "${node_digest%% *}" ] || { echo 'Node archive checksum mismatch.' >&2; return 1; }
  tar -xzf "$1/node.tgz" -C "$1" "$node_archive/bin/node" || return
  node="$1/$node_archive/bin/node"
}
