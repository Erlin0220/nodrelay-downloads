import { createHash, createPublicKey, verify } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { loopbackCallback } from './cloudflare-oauth.mjs';
import { validateReleaseCatalog } from './setup-core.mjs';

export async function managementRelease(manifestFile, publisherKey) {
  const manifest = await readFile(manifestFile);
  const signature = await readFile(manifestFile + '.sig');
  const key = createPublicKey(await readFile(publisherKey));
  if (key.asymmetricKeyType !== 'ed25519' || !verify(null, manifest, key, signature)) {
    throw new Error('Nodrelay installation manifest signature is invalid. Use the original release and trusted publisher key.');
  }
  const data = JSON.parse(manifest);
  if ((data.zeroTrustBootstrap !== undefined && (data.schema !== 2 || data.zeroTrustBootstrap !== true)) || ![1, 2].includes(data.schema) || !/^[A-Za-z0-9_-]{8,128}$/.test(data.oauthClientId ?? '') ||
      data.workerBundle !== './worker.js' || !/^[a-f0-9]{64}$/.test(data.workerSha256 ?? '')) {
    throw new Error('The signed release does not describe a valid Nodrelay management installer.');
  }
  const redirectUri = loopbackCallback(data.oauthRedirect).href;
  const releases = validateReleaseCatalog(data.releases);
  if (Object.values(releases).some(asset => !asset.url || /(^|\.)invalid$/.test(new URL(asset.url).hostname))) {
    throw new Error('The management installer requires hosted HTTPS device releases.');
  }
  const bundle = await readFile(join(dirname(resolve(manifestFile)), 'worker.js'));
  if (createHash('sha256').update(bundle).digest('hex') !== data.workerSha256) {
    throw new Error('The Worker bundle does not match the signed release.');
  }
  return { clientId: data.oauthClientId, redirectUri, releases, bundle, automaticAdministrator: data.schema === 2, zeroTrustBootstrap: data.zeroTrustBootstrap === true };
}
