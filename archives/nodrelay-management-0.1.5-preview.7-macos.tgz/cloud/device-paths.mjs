export const enrollPath = '/device/enroll';
export const activatePath = '/device/activate';

export const installPath = platform => '/device/install/' + platform;
export const operatingSystems = {
  macos: { label: 'macOS', architectures: ['arm64', 'x64'] },
  windows: { label: 'Windows', architectures: ['x64'] },
  linux: { label: 'Linux', architectures: ['x64', 'arm64'] },
};

export function hostedInstallers(releases) {
  const groups = {};
  for (const [platform, { architectures }] of Object.entries(operatingSystems)) {
    const assets = Object.fromEntries(architectures.flatMap(architecture => {
      const asset = releases[`${platform}-${architecture}`];
      return asset?.url ? [[architecture, asset]] : [];
    }));
    const available = Object.values(assets);
    if (!available.length) continue;
    const { version, browser } = available[0];
    if (available.some(asset => asset.version !== version || asset.browser !== browser)) {
      throw new Error(`Hosted ${operatingSystems[platform].label} installers must share the same version and capabilities`);
    }
    groups[platform] = { version, browser, assets };
  }
  return groups;
}
