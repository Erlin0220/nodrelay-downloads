import { installPath, operatingSystems } from './device-paths.mjs';

const sh = value => "'" + value.replaceAll("'", "'\\''") + "'";
const curlOptions = "--disable --fail --silent --show-error --location --max-redirs 5 --proto '=https' --proto-redir '=https'";
const ps = value => "'" + value.replaceAll("'", "''") + "'";

const shellHash = "if command -v sha256sum >/dev/null; then digest=$(sha256sum \"$d/fleet.tgz\"); else digest=$(shasum -a 256 \"$d/fleet.tgz\"); fi";
const requireShellHash = expected => `[ "\${digest%% *}" = ${expected} ] || { printf '%s\\n' 'Installer hash mismatch' >&2; exit 1; }`;
const unpackShell = 'mkdir "$d/bundle"; tar -xzf "$d/fleet.tgz" -C "$d/bundle"';
const temporaryDirectory = 'umask 077; d=$(mktemp -d); trap \'rm -rf "$d"\' EXIT';
const runWindows = "& (Join-Path $bundle 'bin/node.exe') (Join-Path $bundle 'fleet/src/install-device.mjs') $bundle";
const requireWindowsSuccess = "if ($LASTEXITCODE -ne 0) { throw 'Device installation failed' }";

export function shortInstallCommand(origin, platform, version, ticket, deviceId) {
  const url = new URL(installPath(platform), origin);
  if (url.protocol !== 'https:') throw new Error('Device bootstrap requires HTTPS');
  url.searchParams.set('version', version);
  if (platform === 'windows') {
    return `& { $ErrorActionPreference='Stop'; $r=Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 30 -Uri ${ps(url.href)}; if ($r.StatusCode -ne 200 -or $r.Content -notmatch '^param\\(') { throw 'Installer unavailable' }; & ([ScriptBlock]::Create([string]$r.Content)) -Device ${ps(deviceId)} -Ticket ${ps(ticket)} }`;
  }
  return `(s=$(curl --disable -fsSL --max-redirs 0 --proto '=https' --max-time 30 -w '%{http_code}' ${sh(url.href)}) && case "$s" in '#!/bin/sh'*200) DEVSPACE_FLEET_DEVICE=${sh(deviceId)} DEVSPACE_FLEET_TICKET=${sh(ticket)} sh -c "\${s%???}";; *) echo 'Installer unavailable' >&2; exit 1;; esac)`;
}

export function bootstrapInstaller(origin, platform, { assets }) {
  if (platform === 'windows') {
    const asset = assets.x64;
    return `param([Parameter(Mandatory)][ValidatePattern('^[a-z][a-z0-9-]{0,23}$')][string]$Device, [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9_-]{43}$')][string]$Ticket)
$ErrorActionPreference = 'Stop'
if ($env:PROCESSOR_ARCHITEW6432 -eq 'ARM64' -or ($env:PROCESSOR_ARCHITEW6432 -ne 'AMD64' -and $env:PROCESSOR_ARCHITECTURE -ne 'AMD64')) { throw 'This release supports x64 Windows' }
$d = Join-Path ([IO.Path]::GetTempPath()) ('nodrelay-' + [Guid]::NewGuid())
New-Item -ItemType Directory $d | Out-Null
try {
  $f = Join-Path $d 'fleet.zip'
  $curlPath = if ($env:PROCESSOR_ARCHITEW6432 -eq 'AMD64') { 'Sysnative/curl.exe' } else { 'System32/curl.exe' }
  $curl = Join-Path $env:SystemRoot $curlPath
  if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) { throw 'Windows system curl.exe is required' }
  & $curl ${curlOptions} --output $f --url ${ps(asset.url)}
  if ($LASTEXITCODE -ne 0) { throw 'Installer download failed' }
  if ((Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLowerInvariant() -ne ${ps(asset.sha256)}) { throw 'Installer hash mismatch' }
  $bundle = Join-Path $d 'bundle'
  Expand-Archive -LiteralPath $f -DestinationPath $bundle
  $env:DEVSPACE_FLEET_MANAGER = ${ps(origin)}
  $env:DEVSPACE_FLEET_TICKET = $Ticket
  $env:DEVSPACE_FLEET_DEVICE = $Device
  ${runWindows}
  ${requireWindowsSuccess}
} finally {
  Remove-Item Env:DEVSPACE_FLEET_TICKET, Env:DEVSPACE_FLEET_MANAGER, Env:DEVSPACE_FLEET_DEVICE -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $d -Recurse -Force
}
`;
  }
  const architectures = { x64: 'x86_64|amd64', arm64: 'arm64|aarch64' };
  const cases = Object.entries(assets).map(([arch, asset]) =>
    `  ${architectures[arch]}) url=${sh(asset.url)}; expected=${sh(asset.sha256)} ;;`).join('\n');
  return `#!/bin/sh
set -eu
[ "$(uname -s)" = ${sh(platform === 'macos' ? 'Darwin' : 'Linux')} ] || { echo ${sh(`Use the ${operatingSystems[platform].label} command on its target OS`)} >&2; exit 1; }
case "$(uname -m)" in
${cases}
  *) echo 'No verified installer is available for this CPU' >&2; exit 1 ;;
esac
: "\${DEVSPACE_FLEET_DEVICE:?Missing device id}" "\${DEVSPACE_FLEET_TICKET:?Missing device ticket}"
${temporaryDirectory}
curl ${curlOptions} --url "$url" --output "$d/fleet.tgz"
${shellHash}
${requireShellHash('"$expected"')}
${unpackShell}
DEVSPACE_FLEET_MANAGER=${sh(origin)} sh "$d/bundle/install.sh"
`;
}

export function installCommand(origin, platform, asset, ticket, deviceId) {
  if (platform.startsWith('windows-')) {
    const acquire = asset.localFile
      ? [`Copy-Item -LiteralPath (Join-Path (Get-Location) ${ps(asset.localFile)}) -Destination $f`]
      : [
        "$curl=Join-Path $env:SystemRoot 'System32/curl.exe'",
        "if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) { throw 'Windows system curl.exe is required' }",
        `& $curl ${curlOptions} --output $f --url ${ps(asset.url)}`,
        "if ($LASTEXITCODE -ne 0) { throw 'Installer download failed' }",
      ];
    const install = [
      "$f=Join-Path $d 'fleet.zip'",
      ...acquire,
      `if ((Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLowerInvariant() -ne ${ps(asset.sha256)}) { throw 'Installer hash mismatch' }`,
      "$bundle=Join-Path $d 'bundle'",
      "Expand-Archive -LiteralPath $f -DestinationPath $bundle",
      `$env:DEVSPACE_FLEET_MANAGER=${ps(origin)}; $env:DEVSPACE_FLEET_TICKET=${ps(ticket)}; $env:DEVSPACE_FLEET_DEVICE=${ps(deviceId)}`,
      runWindows,
      requireWindowsSuccess,
    ];
    return [
      "$ErrorActionPreference='Stop'",
      "$d=Join-Path ([IO.Path]::GetTempPath()) ('devspace-fleet-'+[Guid]::NewGuid())",
      'New-Item -ItemType Directory $d | Out-Null',
      `try { ${install.join('; ')} } finally { Remove-Item Env:DEVSPACE_FLEET_TICKET -ErrorAction SilentlyContinue; Remove-Item Env:DEVSPACE_FLEET_MANAGER -ErrorAction SilentlyContinue; Remove-Item Env:DEVSPACE_FLEET_DEVICE -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $d -Recurse -Force }`,
    ].join('; ');
  }
  return [
    "(set -eu; " + temporaryDirectory,
    asset.localFile
      ? `cp ${sh('./' + asset.localFile)} "$d/fleet.tgz"`
      : `curl ${curlOptions} --url ${sh(asset.url)} --output "$d/fleet.tgz"`,
    shellHash,
    requireShellHash(sh(asset.sha256)),
    unpackShell,
    `DEVSPACE_FLEET_MANAGER=${sh(origin)} DEVSPACE_FLEET_TICKET=${sh(ticket)} DEVSPACE_FLEET_DEVICE=${sh(deviceId)} sh "$d/bundle/install.sh")`,
  ].join('; ');
}

export function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => `&#${c.charCodeAt(0)};`);
}
