var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));

// ../cloud/device-paths.mjs
var enrollPath = "/device/enroll";
var activatePath = "/device/activate";
var installPath = /* @__PURE__ */ __name((platform) => "/device/install/" + platform, "installPath");
var operatingSystems = {
  macos: { label: "macOS", architectures: ["arm64", "x64"] },
  windows: { label: "Windows", architectures: ["x64"] },
  linux: { label: "Linux", architectures: ["x64", "arm64"] }
};
function hostedInstallers(releases) {
  const groups = {};
  for (const [platform, { architectures }] of Object.entries(operatingSystems)) {
    const assets2 = Object.fromEntries(architectures.flatMap((architecture) => {
      const asset = releases[`${platform}-${architecture}`];
      return asset?.url ? [[architecture, asset]] : [];
    }));
    const available = Object.values(assets2);
    if (!available.length) continue;
    const { version, browser } = available[0];
    if (available.some((asset) => asset.version !== version || asset.browser !== browser)) {
      throw new Error(`Hosted ${operatingSystems[platform].label} installers must share the same version and capabilities`);
    }
    groups[platform] = { version, browser, assets: assets2 };
  }
  return groups;
}
__name(hostedInstallers, "hostedInstallers");

// ../cloud/install-command.mjs
var sh = /* @__PURE__ */ __name((value) => "'" + value.replaceAll("'", "'\\''") + "'", "sh");
var curlOptions = "--disable --fail --silent --show-error --location --max-redirs 5 --proto '=https' --proto-redir '=https'";
var ps = /* @__PURE__ */ __name((value) => "'" + value.replaceAll("'", "''") + "'", "ps");
var shellHash = 'if command -v sha256sum >/dev/null; then digest=$(sha256sum "$d/fleet.tgz"); else digest=$(shasum -a 256 "$d/fleet.tgz"); fi';
var requireShellHash = /* @__PURE__ */ __name((expected) => `[ "\${digest%% *}" = ${expected} ] || { printf '%s\\n' 'Installer hash mismatch' >&2; exit 1; }`, "requireShellHash");
var unpackShell = 'mkdir "$d/bundle"; tar -xzf "$d/fleet.tgz" -C "$d/bundle"';
var temporaryDirectory = `umask 077; d=$(mktemp -d); trap 'rm -rf "$d"' EXIT`;
var runWindows = "& (Join-Path $bundle 'bin/node.exe') (Join-Path $bundle 'fleet/src/install-device.mjs') $bundle";
var requireWindowsSuccess = "if ($LASTEXITCODE -ne 0) { throw 'Device installation failed' }";
function shortInstallCommand(origin, platform, version, ticket, deviceId) {
  const url = new URL(installPath(platform), origin);
  if (url.protocol !== "https:") throw new Error("Device bootstrap requires HTTPS");
  url.searchParams.set("version", version);
  if (platform === "windows") {
    return `& { $ErrorActionPreference='Stop'; $r=Invoke-WebRequest -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 30 -Uri ${ps(url.href)}; if ($r.StatusCode -ne 200 -or $r.Content -notmatch '^param\\(') { throw 'Installer unavailable' }; & ([ScriptBlock]::Create([string]$r.Content)) -Device ${ps(deviceId)} -Ticket ${ps(ticket)} }`;
  }
  return `(s=$(curl --disable -fsSL --max-redirs 0 --proto '=https' --max-time 30 -w '%{http_code}' ${sh(url.href)}) && case "$s" in '#!/bin/sh'*200) DEVSPACE_FLEET_DEVICE=${sh(deviceId)} DEVSPACE_FLEET_TICKET=${sh(ticket)} sh -c "\${s%???}";; *) echo 'Installer unavailable' >&2; exit 1;; esac)`;
}
__name(shortInstallCommand, "shortInstallCommand");
function bootstrapInstaller(origin, platform, { assets: assets2 }) {
  if (platform === "windows") {
    const asset = assets2.x64;
    return `param([Parameter(Mandatory)][ValidatePattern('^[a-z][a-z0-9-]{0,23}$')][string]$Device, [Parameter(Mandatory)][ValidatePattern('^[A-Za-z0-9_-]{43}$')][string]$Ticket)
$ErrorActionPreference = 'Stop'
if ($env:PROCESSOR_ARCHITEW6432 -eq 'ARM64' -or ($env:PROCESSOR_ARCHITEW6432 -ne 'AMD64' -and $env:PROCESSOR_ARCHITECTURE -ne 'AMD64')) { throw 'This release supports x64 Windows' }
$d = Join-Path ([IO.Path]::GetTempPath()) ('nodrelay-' + [Guid]::NewGuid())
New-Item -ItemType Directory $d | Out-Null
try {
  $f = Join-Path $d 'fleet.zip'
  $curlPath = if ($env:PROCESSOR_ARCHITEW6432 -eq 'AMD64') { 'Sysnative/curl.exe' } else { 'System32/curl.exe' }
  $curl = Join-Path $env:SystemRoot $curlPath
  if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) { throw 'Windows system curl.exe is required' }
  & $curl ${curlOptions} --output $f --url ${ps(asset.url)}
  if ($LASTEXITCODE -ne 0) { throw 'Installer download failed' }
  if ((Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLowerInvariant() -ne ${ps(asset.sha256)}) { throw 'Installer hash mismatch' }
  $bundle = Join-Path $d 'bundle'
  Expand-Archive -LiteralPath $f -DestinationPath $bundle
  $env:DEVSPACE_FLEET_MANAGER = ${ps(origin)}
  $env:DEVSPACE_FLEET_TICKET = $Ticket
  $env:DEVSPACE_FLEET_DEVICE = $Device
  ${runWindows}
  ${requireWindowsSuccess}
} finally {
  Remove-Item Env:DEVSPACE_FLEET_TICKET, Env:DEVSPACE_FLEET_MANAGER, Env:DEVSPACE_FLEET_DEVICE -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $d -Recurse -Force
}
`;
  }
  const architectures = { x64: "x86_64|amd64", arm64: "arm64|aarch64" };
  const cases = Object.entries(assets2).map(([arch, asset]) => `  ${architectures[arch]}) url=${sh(asset.url)}; expected=${sh(asset.sha256)} ;;`).join("\n");
  return `#!/bin/sh
set -eu
[ "$(uname -s)" = ${sh(platform === "macos" ? "Darwin" : "Linux")} ] || { echo ${sh(`Use the ${operatingSystems[platform].label} command on its target OS`)} >&2; exit 1; }
case "$(uname -m)" in
${cases}
  *) echo 'No verified installer is available for this CPU' >&2; exit 1 ;;
esac
: "\${DEVSPACE_FLEET_DEVICE:?Missing device id}" "\${DEVSPACE_FLEET_TICKET:?Missing device ticket}"
${temporaryDirectory}
curl ${curlOptions} --url "$url" --output "$d/fleet.tgz"
${shellHash}
${requireShellHash('"$expected"')}
${unpackShell}
DEVSPACE_FLEET_MANAGER=${sh(origin)} sh "$d/bundle/install.sh"
`;
}
__name(bootstrapInstaller, "bootstrapInstaller");
function installCommand(origin, platform, asset, ticket, deviceId) {
  if (platform.startsWith("windows-")) {
    const acquire = asset.localFile ? [`Copy-Item -LiteralPath (Join-Path (Get-Location) ${ps(asset.localFile)}) -Destination $f`] : [
      "$curl=Join-Path $env:SystemRoot 'System32/curl.exe'",
      "if (-not (Test-Path -LiteralPath $curl -PathType Leaf)) { throw 'Windows system curl.exe is required' }",
      `& $curl ${curlOptions} --output $f --url ${ps(asset.url)}`,
      "if ($LASTEXITCODE -ne 0) { throw 'Installer download failed' }"
    ];
    const install = [
      "$f=Join-Path $d 'fleet.zip'",
      ...acquire,
      `if ((Get-FileHash -Algorithm SHA256 -LiteralPath $f).Hash.ToLowerInvariant() -ne ${ps(asset.sha256)}) { throw 'Installer hash mismatch' }`,
      "$bundle=Join-Path $d 'bundle'",
      "Expand-Archive -LiteralPath $f -DestinationPath $bundle",
      `$env:DEVSPACE_FLEET_MANAGER=${ps(origin)}; $env:DEVSPACE_FLEET_TICKET=${ps(ticket)}; $env:DEVSPACE_FLEET_DEVICE=${ps(deviceId)}`,
      runWindows,
      requireWindowsSuccess
    ];
    return [
      "$ErrorActionPreference='Stop'",
      "$d=Join-Path ([IO.Path]::GetTempPath()) ('devspace-fleet-'+[Guid]::NewGuid())",
      "New-Item -ItemType Directory $d | Out-Null",
      `try { ${install.join("; ")} } finally { Remove-Item Env:DEVSPACE_FLEET_TICKET -ErrorAction SilentlyContinue; Remove-Item Env:DEVSPACE_FLEET_MANAGER -ErrorAction SilentlyContinue; Remove-Item Env:DEVSPACE_FLEET_DEVICE -ErrorAction SilentlyContinue; Remove-Item -LiteralPath $d -Recurse -Force }`
    ].join("; ");
  }
  return [
    "(set -eu; " + temporaryDirectory,
    asset.localFile ? `cp ${sh("./" + asset.localFile)} "$d/fleet.tgz"` : `curl ${curlOptions} --url ${sh(asset.url)} --output "$d/fleet.tgz"`,
    shellHash,
    requireShellHash(sh(asset.sha256)),
    unpackShell,
    `DEVSPACE_FLEET_MANAGER=${sh(origin)} DEVSPACE_FLEET_TICKET=${sh(ticket)} DEVSPACE_FLEET_DEVICE=${sh(deviceId)} sh "$d/bundle/install.sh")`
  ].join("; ");
}
__name(installCommand, "installCommand");
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
}
__name(escapeHtml, "escapeHtml");

// ../node_modules/jose/dist/webapi/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var strictDecoder = new TextDecoder("utf-8", { fatal: true });
var UINT32_RANGE = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0), buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers)
    buf.set(buffer, i), i += buffer.length;
  return buf;
}
__name(concat, "concat");
var NON_ASCII = /[^\x00-\x7f]/;
function encode(string) {
  if (typeof string == "string" && string.length >= 128) {
    if (NON_ASCII.test(string))
      throw new TypeError("non-ASCII string encountered in encode()");
    return encoder.encode(string);
  }
  const bytes = new Uint8Array(string.length);
  for (let i = 0; i < string.length; i++) {
    const code = string.charCodeAt(i);
    if (code > 127)
      throw new TypeError("non-ASCII string encountered in encode()");
    bytes[i] = code;
  }
  return bytes;
}
__name(encode, "encode");
function encodeBase64(input, url = false) {
  if (Uint8Array.prototype.toBase64)
    return input.toBase64({ alphabet: url ? "base64url" : "base64", omitPadding: url });
  const CHUNK_SIZE = 32768, arr = [];
  for (let i = 0; i < input.length; i += CHUNK_SIZE)
    arr.push(String.fromCharCode.apply(null, input.subarray(i, i + CHUNK_SIZE)));
  const encoded = btoa(arr.join(""));
  return url ? encoded.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_") : encoded;
}
__name(encodeBase64, "encodeBase64");
function decodeBase64(encoded, url = false) {
  if (Uint8Array.fromBase64)
    return Uint8Array.fromBase64(encoded, { alphabet: url ? "base64url" : "base64" });
  if (url) {
    if (encoded.includes("+") || encoded.includes("/"))
      throw new TypeError("Invalid base64url");
    encoded = encoded.replace(/-/g, "+").replace(/_/g, "/");
  }
  const binary = atob(encoded), bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++)
    bytes[i] = binary.charCodeAt(i);
  return bytes;
}
__name(decodeBase64, "decodeBase64");

// ../node_modules/jose/dist/webapi/util/errors.js
var JOSEError = class extends Error {
  static {
    __name(this, "JOSEError");
  }
  static code = "ERR_JOSE_GENERIC";
  code = "ERR_JOSE_GENERIC";
  constructor(message2, options) {
    super(message2, options), this.name = this.constructor.name, Error.captureStackTrace?.(this, this.constructor);
  }
};
var JWTClaimValidationFailed = class extends JOSEError {
  static {
    __name(this, "JWTClaimValidationFailed");
  }
  static code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } }), this.claim = claim, this.reason = reason, this.payload = payload;
  }
};
var JWTExpired = class extends JOSEError {
  static {
    __name(this, "JWTExpired");
  }
  static code = "ERR_JWT_EXPIRED";
  code = "ERR_JWT_EXPIRED";
  claim;
  reason;
  payload;
  constructor(message2, payload, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload } }), this.claim = claim, this.reason = reason, this.payload = payload;
  }
};
var JOSEAlgNotAllowed = class extends JOSEError {
  static {
    __name(this, "JOSEAlgNotAllowed");
  }
  static code = "ERR_JOSE_ALG_NOT_ALLOWED";
  code = "ERR_JOSE_ALG_NOT_ALLOWED";
};
var JOSENotSupported = class extends JOSEError {
  static {
    __name(this, "JOSENotSupported");
  }
  static code = "ERR_JOSE_NOT_SUPPORTED";
  code = "ERR_JOSE_NOT_SUPPORTED";
};
var JWSInvalid = class extends JOSEError {
  static {
    __name(this, "JWSInvalid");
  }
  static code = "ERR_JWS_INVALID";
  code = "ERR_JWS_INVALID";
};
var JWTInvalid = class extends JOSEError {
  static {
    __name(this, "JWTInvalid");
  }
  static code = "ERR_JWT_INVALID";
  code = "ERR_JWT_INVALID";
};
var JWKSInvalid = class extends JOSEError {
  static {
    __name(this, "JWKSInvalid");
  }
  static code = "ERR_JWKS_INVALID";
  code = "ERR_JWKS_INVALID";
};
var JWKSNoMatchingKey = class extends JOSEError {
  static {
    __name(this, "JWKSNoMatchingKey");
  }
  static code = "ERR_JWKS_NO_MATCHING_KEY";
  code = "ERR_JWKS_NO_MATCHING_KEY";
  constructor(message2 = "no applicable key found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWKSMultipleMatchingKeys = class extends JOSEError {
  static {
    __name(this, "JWKSMultipleMatchingKeys");
  }
  [Symbol.asyncIterator] = async function* () {
  };
  static code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  constructor(message2 = "multiple matching keys found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWKSTimeout = class extends JOSEError {
  static {
    __name(this, "JWKSTimeout");
  }
  static code = "ERR_JWKS_TIMEOUT";
  code = "ERR_JWKS_TIMEOUT";
  constructor(message2 = "request timed out", options) {
    super(message2, options);
  }
};
var JWSSignatureVerificationFailed = class extends JOSEError {
  static {
    __name(this, "JWSSignatureVerificationFailed");
  }
  static code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  constructor(message2 = "signature verification failed", options) {
    super(message2, options);
  }
};

// ../node_modules/jose/dist/webapi/util/base64url.js
var base64url_exports = {};
__export(base64url_exports, {
  decode: () => decode,
  encode: () => encode2
});
var invalid = "The input to be decoded is not correctly encoded.";
function decode(input) {
  try {
    return decodeBase64(typeof input == "string" ? input : decoder.decode(input), true);
  } catch (cause) {
    throw new TypeError(invalid, { cause });
  }
}
__name(decode, "decode");
function encode2(input) {
  return encodeBase64(typeof input == "string" ? encoder.encode(input) : input, true);
}
__name(encode2, "encode");

// ../node_modules/jose/dist/webapi/lib/validate.js
function isObject(input) {
  if (typeof input != "object" || input === null || Object.prototype.toString.call(input) !== "[object Object]")
    return false;
  const prototype = Object.getPrototypeOf(input);
  return prototype === null || Object.getPrototypeOf(prototype) === null;
}
__name(isObject, "isObject");
function isJwkSet(input) {
  return isObject(input) && Array.isArray(input.keys) && Array.from(input.keys).every(isObject);
}
__name(isJwkSet, "isJwkSet");
function isDisjoint(...headers) {
  const parameters = /* @__PURE__ */ new Set();
  for (const header of headers)
    if (header)
      for (const parameter of Object.keys(header)) {
        if (parameters.has(parameter))
          return false;
        parameters.add(parameter);
      }
  return true;
}
__name(isDisjoint, "isDisjoint");
function decodeBase64url(value, label2, ErrorClass) {
  try {
    return decode(value);
  } catch (cause) {
    throw new ErrorClass(`Failed to base64url decode the ${label2}`, { cause });
  }
}
__name(decodeBase64url, "decodeBase64url");
function encodeAsciiMember(value, label2, ErrorClass) {
  try {
    return encode(value);
  } catch (cause) {
    throw new ErrorClass(`The ${label2} is not a valid base64url string`, { cause });
  }
}
__name(encodeAsciiMember, "encodeAsciiMember");
function parseJoseHeader(encodedProtectedHeader, ErrorClass, message2) {
  let parsed;
  try {
    parsed = JSON.parse(strictDecoder.decode(decode(encodedProtectedHeader)));
  } catch (cause) {
    throw new ErrorClass(message2, { cause });
  }
  if (!isObject(parsed))
    throw new ErrorClass(message2);
  return parsed;
}
__name(parseJoseHeader, "parseJoseHeader");
var JWS_RECOGNIZED = { __proto__: null, b64: true };
function validateAlgorithms(option, algorithms) {
  if (algorithms !== void 0 && (!Array.isArray(algorithms) || algorithms.some((s) => typeof s != "string")))
    throw new TypeError(`"${option}" option must be an array of strings`);
  return algorithms === void 0 ? void 0 : new Set(algorithms);
}
__name(validateAlgorithms, "validateAlgorithms");
function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0)
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  if (!protectedHeader || protectedHeader.crit === void 0)
    return [];
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input != "string" || input.length === 0))
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  const recognized = recognizedOption === void 0 ? recognizedDefault : { __proto__: null, ...recognizedOption, ...recognizedDefault };
  for (const parameter of protectedHeader.crit) {
    if (!(parameter in recognized))
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    if (!Object.hasOwn(joseHeader, parameter) || joseHeader[parameter] === void 0)
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    if (recognized[parameter] && (!Object.hasOwn(protectedHeader, parameter) || protectedHeader[parameter] === void 0))
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
  }
  return protectedHeader.crit;
}
__name(validateCrit, "validateCrit");
function validateB64(protectedHeader, extensions) {
  if (extensions.includes("b64")) {
    const b64 = protectedHeader.b64;
    if (typeof b64 != "boolean")
      throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    return b64;
  }
  return true;
}
__name(validateB64, "validateB64");

// ../node_modules/jose/dist/webapi/lib/key.js
var tag = /* @__PURE__ */ __name((key3) => key3[Symbol.toStringTag], "tag");
var jwkMatchesOp = /* @__PURE__ */ __name((entry, key3, usage) => {
  const { alg } = entry;
  if (key3.use !== void 0) {
    const expected = usage === "sign" || usage === "verify" ? "sig" : "enc";
    if (key3.use !== expected)
      throw new TypeError(`Invalid key for this operation, its "use" must be "${expected}" when present`);
  }
  if (key3.alg !== void 0 && key3.alg !== alg)
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${alg}" when present`);
  if (Array.isArray(key3.key_ops)) {
    const expectedKeyOp = usage === "encrypt" || usage === "decrypt" ? entry.ops?.[usage === "encrypt" ? 0 : 1] : usage;
    if (expectedKeyOp && !key3.key_ops.includes(expectedKeyOp))
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${expectedKeyOp}" when present`);
  }
}, "jwkMatchesOp");
async function prepareKey(entry, key3, usage) {
  const { alg, secret } = entry, requiresPrivateKey = usage === "decrypt" || usage === "sign";
  if (secret && key3 instanceof Uint8Array)
    return key3;
  let normalized, keyObject;
  if (isObject(key3)) {
    if (normalized = normalizeJwk(key3), typeof normalized.kty != "string")
      throw invalidKeyType(alg, key3, secret);
    if (!(secret ? normalized.kty === "oct" && typeof normalized.k == "string" : normalized.kty !== "oct" && (requiresPrivateKey ? normalized.kty === "AKP" && typeof normalized.priv == "string" || typeof normalized.d == "string" : normalized.d === void 0 && normalized.priv === void 0)))
      throw new TypeError(secret ? 'JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present' : `JSON Web Key for this operation must be a ${requiresPrivateKey ? "private" : "public"} JWK`);
    if (jwkMatchesOp(entry, normalized, usage), normalized.kty === "oct")
      return decode(normalized.k);
    if (!Object.isFrozen(key3)) {
      const { key_ops } = key3;
      Array.isArray(key_ops) && Object.freeze(key_ops), Object.freeze(key3);
    }
  } else {
    if (!isKeyLike(key3))
      throw invalidKeyType(alg, key3, secret);
    const expectedType = secret ? "secret" : requiresPrivateKey ? "private" : "public";
    if (key3.type !== expectedType && (secret || ["secret", "public", "private"].includes(key3.type)))
      throw new TypeError(`${tag(key3)} instances must be of type "${expectedType}" for the ${alg} algorithm`);
    if (isCryptoKey(key3))
      return key3;
    if (keyObject = key3, keyObject.type === "secret")
      return keyObject.export();
  }
  cache ||= /* @__PURE__ */ new WeakMap();
  const cacheKey = key3;
  let cached = cache.get(cacheKey);
  if (cached?.[alg])
    return cached[alg];
  if (cached || cache.set(cacheKey, cached = {}), keyObject && typeof keyObject.toCryptoKey == "function") {
    const isPublic = keyObject.type === "public", crv = nist[keyObject.asymmetricKeyDetails?.namedCurve], params = entry.resolve?.({ crv, asymmetricKeyType: keyObject.asymmetricKeyType }) ?? entry.subtle;
    return cached[alg] = keyObject.toCryptoKey(params, isPublic, entry.usages[isPublic ? 0 : 1]);
  }
  return normalized ??= keyObject.export({ format: "jwk" }), normalized.alg = alg, cached[alg] = await jwkToKey(entry, normalized);
}
__name(prepareKey, "prepareKey");
var cache;
var nist = {
  __proto__: null,
  prime256v1: "P-256",
  secp384r1: "P-384",
  secp521r1: "P-521"
};
var isCryptoKey = /* @__PURE__ */ __name((key3) => {
  if (key3?.[Symbol.toStringTag] === "CryptoKey")
    return true;
  try {
    return key3 instanceof CryptoKey;
  } catch {
    return false;
  }
}, "isCryptoKey");
var isKeyObject = /* @__PURE__ */ __name((key3) => key3?.[Symbol.toStringTag] === "KeyObject", "isKeyObject");
var isKeyLike = /* @__PURE__ */ __name((key3) => isCryptoKey(key3) || isKeyObject(key3), "isKeyLike");
function message(msg, actual, ...types) {
  if (types.length > 2) {
    const last = types.pop();
    msg += `one of type ${types.join(", ")}, or ${last}.`;
  } else types.length === 2 ? msg += `one of type ${types[0]} or ${types[1]}.` : msg += `of type ${types[0]}.`;
  return actual == null ? msg += ` Received ${actual}` : typeof actual == "function" && actual.name ? msg += ` Received function ${actual.name}` : typeof actual == "object" && actual != null && actual.constructor?.name && (msg += ` Received an instance of ${actual.constructor.name}`), msg;
}
__name(message, "message");
function invalidKeyType(alg, actual, secret) {
  const types = ["CryptoKey", "KeyObject", "JSON Web Key"];
  return secret && types.push("Uint8Array"), new TypeError(message(`Key for the ${alg} algorithm must be `, actual, ...types));
}
__name(invalidKeyType, "invalidKeyType");
var unusable = /* @__PURE__ */ __name((name, prop = "algorithm.name") => new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`), "unusable");
function checkUsage(key3, usage) {
  if (usage && !key3.usages.includes(usage))
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${usage}.`);
}
__name(checkUsage, "checkUsage");
function checkModulusLength(alg, key3) {
  const { modulusLength } = key3.algorithm;
  if (typeof modulusLength != "number" || modulusLength < 2048)
    throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
}
__name(checkModulusLength, "checkModulusLength");
function checkCryptoKey(key3, expected, usage) {
  const algorithm = key3.algorithm;
  if (algorithm.name !== expected.name)
    throw unusable(expected.name);
  if (expected.hash && algorithm.hash?.name !== expected.hash)
    throw unusable(expected.hash, "algorithm.hash");
  if (expected.namedCurve && algorithm.namedCurve !== expected.namedCurve)
    throw unusable(expected.namedCurve, "algorithm.namedCurve");
  if (expected.length !== void 0 && algorithm.length !== expected.length)
    throw unusable(expected.length, "algorithm.length");
  checkUsage(key3, usage);
}
__name(checkCryptoKey, "checkCryptoKey");
function snapshotJwk(jwk) {
  return { __proto__: null, ...jwk };
}
__name(snapshotJwk, "snapshotJwk");
function normalizeJwk(jwk) {
  const normalized = snapshotJwk(jwk);
  if (normalized.ext !== void 0 && typeof normalized.ext != "boolean")
    throw new TypeError('"ext" (Extractable) Parameter must be a boolean');
  if (normalized.key_ops !== void 0) {
    const value = normalized.key_ops, keyOps = Array.isArray(value) ? [...value] : void 0;
    if (!keyOps || keyOps.some((operation) => typeof operation != "string") || new Set(keyOps).size !== keyOps.length)
      throw new TypeError('"key_ops" (Key Operations) Parameter must be an array of unique strings');
    normalized.key_ops = keyOps;
  }
  return normalized;
}
__name(normalizeJwk, "normalizeJwk");
async function jwkToKey(entry, jwk, extractable) {
  if (!entry.kty.includes(jwk.kty))
    throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
  const algorithm = entry.resolve?.({ kty: jwk.kty, crv: jwk.crv }) ?? entry.subtle, isPrivate = !!(jwk.d || jwk.priv), keyData = { ...jwk, ext: extractable ?? jwk.ext };
  return keyData.kty !== "AKP" && delete keyData.alg, delete keyData.use, crypto.subtle.importKey("jwk", keyData, algorithm, keyData.ext ?? !isPrivate, jwk.key_ops ?? entry.usages[isPrivate ? 1 : 0]);
}
__name(jwkToKey, "jwkToKey");
async function rawKey(key3, expected, usage, extractable = false) {
  return key3 instanceof Uint8Array && (key3 = await crypto.subtle.importKey("raw", key3, expected, extractable, [usage])), checkCryptoKey(key3, expected, usage), key3;
}
__name(rawKey, "rawKey");

// ../node_modules/jose/dist/webapi/lib/key_descriptor.js
function table(entries) {
  const out = { __proto__: null };
  for (const alg in entries)
    out[alg] = { ...entries[alg], alg };
  return out;
}
__name(table, "table");

// ../node_modules/jose/dist/webapi/lib/jws_algorithms.js
var sig = [["verify"], ["sign"]];
function hmac(bits) {
  const subtle = { name: "HMAC", hash: `SHA-${bits}` };
  return { kty: ["oct"], secret: true, subtle, signing: subtle, usages: sig };
}
__name(hmac, "hmac");
function rsa(bits, saltLength) {
  const subtle = { name: saltLength ? "RSA-PSS" : "RSASSA-PKCS1-v1_5", hash: `SHA-${bits}` };
  return {
    kty: ["RSA"],
    subtle,
    signing: saltLength ? { ...subtle, saltLength } : subtle,
    usages: sig,
    minRsaBits: 2048
  };
}
__name(rsa, "rsa");
function ecdsa(crv, bits) {
  return {
    kty: ["EC"],
    crv,
    subtle: { name: "ECDSA", namedCurve: crv },
    signing: { name: "ECDSA", hash: `SHA-${bits}` },
    usages: sig
  };
}
__name(ecdsa, "ecdsa");
function eddsa() {
  const subtle = { name: "Ed25519" };
  return {
    kty: ["OKP"],
    crv: "Ed25519",
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(eddsa, "eddsa");
function mldsa(parameterSet) {
  const subtle = { name: `ML-DSA-${parameterSet}` };
  return {
    kty: ["AKP"],
    subtle,
    signing: subtle,
    usages: sig
  };
}
__name(mldsa, "mldsa");
var JWS = table({
  HS256: hmac(256),
  HS384: hmac(384),
  HS512: hmac(512),
  RS256: rsa(256),
  RS384: rsa(384),
  RS512: rsa(512),
  PS256: rsa(256, 32),
  PS384: rsa(384, 48),
  PS512: rsa(512, 64),
  ES256: ecdsa("P-256", 256),
  ES384: ecdsa("P-384", 384),
  ES512: ecdsa("P-521", 512),
  EdDSA: eddsa(),
  Ed25519: eddsa(),
  "ML-DSA-44": mldsa(44),
  "ML-DSA-65": mldsa(65),
  "ML-DSA-87": mldsa(87)
});
function jwsAlgorithm(alg) {
  const entry = typeof alg == "string" ? JWS[alg] : void 0;
  if (!entry)
    throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  return entry;
}
__name(jwsAlgorithm, "jwsAlgorithm");

// ../node_modules/jose/dist/webapi/lib/jws_verify.js
function prepareVerify(options) {
  return [options && validateAlgorithms("algorithms", options.algorithms), options?.crit];
}
__name(prepareVerify, "prepareVerify");
function parseProtectedHeader(encodedProtectedHeader) {
  return encodedProtectedHeader === void 0 ? {} : parseJoseHeader(encodedProtectedHeader, JWSInvalid, "JWS Protected Header is invalid");
}
__name(parseProtectedHeader, "parseProtectedHeader");
function encodeCompactUnencodedPayload(payload) {
  try {
    return encode(payload);
  } catch (cause) {
    throw new JWSInvalid("JWS Compact Serialization payload must use only ASCII characters", {
      cause
    });
  }
}
__name(encodeCompactUnencodedPayload, "encodeCompactUnencodedPayload");
async function verifySignature(jws, shared, key3, encodeUnencodedPayload, parsedProtected) {
  const { protected: encodedProtectedHeader, header, payload: inputPayload } = jws, protectedHeader = parsedProtected ?? parseProtectedHeader(encodedProtectedHeader);
  if (!isDisjoint(protectedHeader, header))
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  const joseHeader = { ...protectedHeader, ...header }, b64 = validateB64(protectedHeader, validateCrit(JWSInvalid, JWS_RECOGNIZED, shared[1], protectedHeader, joseHeader)), { alg } = joseHeader;
  if (typeof alg != "string" || !alg)
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  if (shared[0] && !shared[0].has(alg))
    throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter value not allowed');
  if (b64) {
    if (typeof inputPayload != "string")
      throw new JWSInvalid("JWS Payload must be a string");
  } else if (typeof inputPayload != "string" && !(inputPayload instanceof Uint8Array))
    throw new JWSInvalid("JWS Payload must be a string or an Uint8Array instance");
  const signingPayload = b64 || typeof inputPayload != "string" ? inputPayload : encodeUnencodedPayload(inputPayload);
  let resolvedKey = false;
  typeof key3 == "function" && (key3 = await key3(protectedHeader, jws), resolvedKey = true);
  const entry = jwsAlgorithm(alg), signingInput = concat(encodedProtectedHeader !== void 0 ? encode(encodedProtectedHeader) : new Uint8Array(), encode("."), typeof signingPayload == "string" ? shared[2] ??= encodeAsciiMember(signingPayload, "payload", JWSInvalid) : signingPayload), signature = decodeBase64url(jws.signature, "signature", JWSInvalid), verificationKey = await prepareKey(entry, key3, "verify"), cryptoKey = await rawKey(verificationKey, entry.subtle, "verify");
  entry.minRsaBits && checkModulusLength(entry.alg, cryptoKey);
  let verified = false;
  try {
    verified = await crypto.subtle.verify(entry.signing, cryptoKey, signature, signingInput);
  } catch (cause) {
    throw new JWSSignatureVerificationFailed(void 0, { cause });
  }
  if (!verified)
    throw new JWSSignatureVerificationFailed();
  const result = { payload: typeof signingPayload == "string" ? decodeBase64url(signingPayload, "payload", JWSInvalid) : signingPayload };
  return encodedProtectedHeader !== void 0 && (result.protectedHeader = protectedHeader), header !== void 0 && (result.unprotectedHeader = header), resolvedKey ? [{ ...result, key: verificationKey }, b64] : [result, b64];
}
__name(verifySignature, "verifySignature");
async function verifyCompact(jws, shared, key3) {
  if (jws instanceof Uint8Array && (jws = decoder.decode(jws)), typeof jws != "string")
    throw new JWSInvalid("Compact JWS must be a string or Uint8Array");
  const { 0: protectedHeader, 1: payload, 2: signature, length } = jws.split(".");
  if (length !== 3)
    throw new JWSInvalid("Invalid Compact JWS");
  return verifySignature({ payload, protected: protectedHeader, signature }, shared, key3, encodeCompactUnencodedPayload);
}
__name(verifyCompact, "verifyCompact");

// ../node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var epoch = /* @__PURE__ */ __name((date) => Math.floor(date.getTime() / 1e3), "epoch");
var multipliers = {
  s: 1,
  m: 60,
  h: 3600,
  d: 86400,
  w: 604800,
  y: 31557600
};
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var checkFailed = "check_failed";
function invalidDuration() {
  throw new TypeError("Invalid time period format");
}
__name(invalidDuration, "invalidDuration");
function secs(str) {
  typeof str != "string" && invalidDuration();
  const matched = REGEX.exec(str);
  (!matched || matched[4] && matched[1]) && invalidDuration();
  const value = parseFloat(matched[2]), durationSeconds = Math.round(value * multipliers[matched[3][0].toLowerCase()]);
  return Number.isFinite(durationSeconds) || invalidDuration(), matched[1] === "-" || matched[4] === "ago" ? -durationSeconds : durationSeconds;
}
__name(secs, "secs");
function validateInput(label2, input) {
  if (!Number.isFinite(input))
    throw new TypeError(`Invalid ${label2} input`);
  return input;
}
__name(validateInput, "validateInput");
var normalizeTyp = /* @__PURE__ */ __name((value) => {
  const normalized = value.toLowerCase();
  return value.includes("/") ? normalized : `application/${normalized}`;
}, "normalizeTyp");
var checkAudiencePresence = /* @__PURE__ */ __name((audPayload, audOption) => typeof audPayload == "string" ? audOption.includes(audPayload) : Array.isArray(audPayload) ? audOption.some((aud) => audPayload.includes(aud)) : false, "checkAudiencePresence");
function validateNumericDate(claimsSet, claim, required = false) {
  const value = claimsSet[claim];
  if (!(value === void 0 && !required)) {
    if (typeof value != "number")
      throw new JWTClaimValidationFailed(`"${claim}" claim must be a number`, claimsSet, claim, "invalid");
    return value;
  }
}
__name(validateNumericDate, "validateNumericDate");
function unexpectedClaim(claimsSet, claim) {
  throw new JWTClaimValidationFailed(`unexpected "${claim}" claim value`, claimsSet, claim, checkFailed);
}
__name(unexpectedClaim, "unexpectedClaim");
function validateClaimsSet(protectedHeader, claimsSetBytes, options = {}) {
  let claimsSet;
  try {
    claimsSet = JSON.parse(strictDecoder.decode(claimsSetBytes));
  } catch (cause) {
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object", { cause });
  }
  if (!isObject(claimsSet))
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object");
  const { typ } = options;
  if (typ !== void 0 && (typeof protectedHeader.typ != "string" || normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ)))
    throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', claimsSet, "typ", checkFailed);
  const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options, presenceCheck = [...requiredClaims];
  maxTokenAge !== void 0 && presenceCheck.push("iat"), audience !== void 0 && presenceCheck.push("aud"), subject !== void 0 && presenceCheck.push("sub"), issuer !== void 0 && presenceCheck.push("iss");
  for (const claim of new Set(presenceCheck.reverse()))
    if (!Object.hasOwn(claimsSet, claim))
      throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, claimsSet, claim, "missing");
  issuer !== void 0 && !(Array.isArray(issuer) ? issuer : [issuer]).includes(claimsSet.iss) && unexpectedClaim(claimsSet, "iss"), subject !== void 0 && claimsSet.sub !== subject && unexpectedClaim(claimsSet, "sub"), audience !== void 0 && !checkAudiencePresence(claimsSet.aud, typeof audience == "string" ? [audience] : audience) && unexpectedClaim(claimsSet, "aud");
  const { clockTolerance } = options;
  let tolerance = 0;
  if (typeof clockTolerance == "string")
    tolerance = secs(clockTolerance);
  else if (clockTolerance !== void 0) {
    if (typeof clockTolerance != "number")
      throw new TypeError("Invalid clockTolerance option type");
    tolerance = clockTolerance;
  }
  validateInput("clockTolerance option", tolerance);
  const { currentDate } = options, now3 = validateInput("currentDate option", epoch(currentDate === void 0 ? /* @__PURE__ */ new Date() : currentDate)), iat = validateNumericDate(claimsSet, "iat", maxTokenAge !== void 0), nbf = validateNumericDate(claimsSet, "nbf");
  if (nbf !== void 0 && nbf > now3 + tolerance)
    throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', claimsSet, "nbf", checkFailed);
  const exp = validateNumericDate(claimsSet, "exp");
  if (exp !== void 0 && exp <= now3 - tolerance)
    throw new JWTExpired('"exp" claim timestamp check failed', claimsSet, "exp", checkFailed);
  if (maxTokenAge !== void 0) {
    const age = now3 - iat, max = validateInput("maxTokenAge option", typeof maxTokenAge == "number" ? maxTokenAge : secs(maxTokenAge));
    if (age - tolerance > max)
      throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', claimsSet, "iat", checkFailed);
    if (age < -tolerance)
      throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', claimsSet, "iat", checkFailed);
  }
  return claimsSet;
}
__name(validateClaimsSet, "validateClaimsSet");

// ../node_modules/jose/dist/webapi/jwt/verify.js
async function jwtVerify(jwt, key3, options) {
  const [verified, b64] = await verifyCompact(jwt, prepareVerify(options), key3);
  if (!b64)
    throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
  const payload = validateClaimsSet(verified.protectedHeader, verified.payload, options);
  return { ...verified, payload };
}
__name(jwtVerify, "jwtVerify");

// ../node_modules/jose/dist/webapi/jwks/local.js
function isUsableJWK(jwk, entry, alg, kid) {
  const { kty, key_ops: keyOps, ext, kid: jwkKid, alg: jwkAlg, use, crv } = jwk;
  return (ext === void 0 || typeof ext == "boolean") && (keyOps === void 0 || Array.isArray(keyOps) && keyOps.every((operation, index) => typeof operation == "string" && keyOps.indexOf(operation) === index) && keyOps.includes("verify")) && entry.kty.includes(kty) && (kid === void 0 || typeof kid == "string" && kid === jwkKid) && (jwkAlg === void 0 ? kty !== "AKP" : alg === jwkAlg) && (use === void 0 || use === "sig") && (!entry.crv || crv === entry.crv);
}
__name(isUsableJWK, "isUsableJWK");
async function importWithAlgCache(cache2, jwk, entry) {
  const cached = cache2.get(jwk) || cache2.set(jwk, {}).get(jwk), { alg } = entry;
  if (cached[alg] === void 0) {
    const pending = jwkToKey(entry, jwk, true).then((key3) => {
      if (key3.type !== "public")
        throw new JWKSInvalid("JSON Web Key Set members must be public keys");
      return cached[alg] = key3, key3;
    }).catch((error) => {
      throw cached[alg] === pending && delete cached[alg], error;
    });
    cached[alg] = pending;
  }
  return cached[alg];
}
__name(importWithAlgCache, "importWithAlgCache");
function createLocalJWKSet(jwks) {
  let snapshot;
  try {
    snapshot = structuredClone(jwks);
  } catch (cause) {
    throw new JWKSInvalid("JSON Web Key Set malformed", { cause });
  }
  if (!isJwkSet(snapshot))
    throw new JWKSInvalid("JSON Web Key Set malformed");
  const metadata = snapshot.keys.map((jwk) => {
    const normalized = snapshotJwk(jwk);
    return Array.isArray(normalized.key_ops) && (normalized.key_ops = [...normalized.key_ops]), normalized;
  }), cached = /* @__PURE__ */ new WeakMap();
  return Object.defineProperty(async (protectedHeader, token) => {
    const { alg, kid } = { ...protectedHeader, ...token?.header }, entry = typeof alg == "string" ? JWS[alg] : void 0;
    if (!entry || entry.secret)
      throw new JOSENotSupported('Unsupported "alg" value for a JSON Web Key Set');
    const candidates = snapshot.keys.filter((_, index) => isUsableJWK(metadata[index], entry, alg, kid)), { 0: jwk, length } = candidates;
    if (!length)
      throw new JWKSNoMatchingKey();
    if (length !== 1) {
      const error = new JWKSMultipleMatchingKeys();
      throw error[Symbol.asyncIterator] = async function* () {
        for (const jwk2 of candidates)
          try {
            yield await importWithAlgCache(cached, jwk2, entry);
          } catch {
          }
      }, error;
    }
    return importWithAlgCache(cached, jwk, entry);
  }, "jwks", {
    value: /* @__PURE__ */ __name(() => structuredClone(snapshot), "value")
  });
}
__name(createLocalJWKSet, "createLocalJWKSet");

// ../node_modules/jose/dist/webapi/jwks/remote.js
function isCloudflareWorkers() {
  return typeof WebSocketPair < "u" || typeof navigator < "u" && true || typeof EdgeRuntime < "u" && EdgeRuntime === "vercel";
}
__name(isCloudflareWorkers, "isCloudflareWorkers");
var USER_AGENT;
(typeof navigator > "u" || !"Cloudflare-Workers"?.startsWith?.("Mozilla/5.0 ")) && (USER_AGENT = "jose/v6.2.13");
var customFetch = /* @__PURE__ */ Symbol();
async function fetchJwks(url, headers, signal, fetchImpl = fetch) {
  const response = await fetchImpl(url, {
    method: "GET",
    signal,
    redirect: "manual",
    headers
  }).catch((err) => {
    throw err.name === "TimeoutError" ? new JWKSTimeout(void 0, { cause: err }) : err;
  });
  if (response.status !== 200)
    throw new JOSEError("Expected 200 OK from the JSON Web Key Set HTTP response");
  try {
    return await response.json();
  } catch (cause) {
    throw new JOSEError("Failed to parse the JSON Web Key Set HTTP response as JSON", { cause });
  }
}
__name(fetchJwks, "fetchJwks");
var jwksCache = /* @__PURE__ */ Symbol();
function isFreshFor(timestamp, duration) {
  return Number.isFinite(timestamp) && Date.now() < timestamp + duration;
}
__name(isFreshFor, "isFreshFor");
function validateDuration(value, fallback, option) {
  if (Number.isNaN(value))
    throw new TypeError(`"${option}" option must not be NaN`);
  return typeof value == "number" ? value : fallback;
}
__name(validateDuration, "validateDuration");
function createRemoteJWKSet(url, options) {
  if (!(url instanceof URL))
    throw new TypeError("url must be an instance of URL");
  const href = new URL(url.href).href, opts = options ?? {}, timeoutOption = opts.timeoutDuration;
  if (typeof timeoutOption == "number" && (!Number.isInteger(timeoutOption) || timeoutOption < 0))
    throw new TypeError('"timeoutDuration" option must be a non-negative integer');
  const timeoutDuration = typeof timeoutOption == "number" ? timeoutOption : 5e3, cooldownDuration = validateDuration(opts.cooldownDuration, 3e4, "cooldownDuration"), cacheMaxAge = validateDuration(opts.cacheMaxAge, 6e5, "cacheMaxAge"), headers = new Headers(opts.headers);
  USER_AGENT && !headers.has("User-Agent") && headers.set("User-Agent", USER_AGENT), headers.has("accept") || headers.set("accept", "application/json, application/jwk-set+json");
  const fetchImpl = opts[customFetch], cache2 = opts[jwksCache];
  let jwksTimestamp, pendingFetch, reloadSequence = 0, appliedSequence = 0, local;
  if (cache2 && typeof cache2 == "object") {
    const { uat, jwks } = cache2;
    isFreshFor(uat, cacheMaxAge) && isJwkSet(jwks) && (jwksTimestamp = uat, local = createLocalJWKSet(jwks));
  }
  const reload = /* @__PURE__ */ __name(async () => {
    if (pendingFetch && isCloudflareWorkers() && (pendingFetch = void 0), !pendingFetch) {
      const sequence = ++reloadSequence, current = pendingFetch = fetchJwks(href, headers, AbortSignal.timeout(timeoutDuration), fetchImpl).then((json2) => {
        const next = createLocalJWKSet(json2);
        if (sequence <= appliedSequence)
          return;
        local = next;
        const updatedAt = Date.now();
        cache2 && (cache2.uat = updatedAt, cache2.jwks = json2), jwksTimestamp = updatedAt, appliedSequence = sequence;
      }).finally(() => {
        pendingFetch === current && (pendingFetch = void 0);
      });
    }
    await pendingFetch;
  }, "reload");
  return Object.defineProperties(async (protectedHeader, token) => {
    (!local || !isFreshFor(jwksTimestamp, cacheMaxAge)) && await reload();
    try {
      return await local(protectedHeader, token);
    } catch (err) {
      if (err instanceof JWKSNoMatchingKey && !isFreshFor(jwksTimestamp, cooldownDuration))
        return await reload(), local(protectedHeader, token);
      throw err;
    }
  }, {
    coolingDown: {
      get: /* @__PURE__ */ __name(() => isFreshFor(jwksTimestamp, cooldownDuration), "get"),
      enumerable: true
    },
    fresh: {
      get: /* @__PURE__ */ __name(() => isFreshFor(jwksTimestamp, cacheMaxAge), "get"),
      enumerable: true
    },
    reload: {
      value: reload,
      enumerable: true
    },
    reloading: {
      get: /* @__PURE__ */ __name(() => !!pendingFetch, "get"),
      enumerable: true
    },
    jwks: {
      value: /* @__PURE__ */ __name(() => local?.jwks(), "value"),
      enumerable: true
    }
  });
}
__name(createRemoteJWKSet, "createRemoteJWKSet");

// ../cloud/tickets.mjs
var text = new TextEncoder();
var parse = new TextDecoder();
var tokenPattern = /^[A-Za-z0-9_-]{43}$/;
var devicePattern = /^[a-z][a-z0-9-]{0,23}$/;
function validateCredentials(credentials) {
  if (typeof credentials?.deviceId !== "string" || !devicePattern.test(credentials.deviceId) || typeof credentials.portalToken !== "string" || !tokenPattern.test(credentials.portalToken) || typeof credentials.tunnelToken !== "string" || !/^[A-Za-z0-9+/=_-]{32,4096}$/.test(credentials.tunnelToken)) {
    throw new Error("Invalid device identity or credentials");
  }
  const { deviceId, portalToken, tunnelToken } = credentials;
  if (credentials.activationToken === void 0) return { deviceId, portalToken, tunnelToken };
  if (typeof credentials.activationToken !== "string" || !tokenPattern.test(credentials.activationToken) || credentials.browserToken !== void 0 && (typeof credentials.browserToken !== "string" || !tokenPattern.test(credentials.browserToken))) {
    throw new Error("Invalid device activation credential");
  }
  return {
    deviceId,
    portalToken,
    tunnelToken,
    activationToken: credentials.activationToken,
    ...credentials.browserToken && { browserToken: credentials.browserToken }
  };
}
__name(validateCredentials, "validateCredentials");
async function key(secret) {
  if (typeof secret !== "string" || !tokenPattern.test(secret)) throw new Error("Enrollment key is missing");
  return crypto.subtle.importKey("raw", base64url_exports.decode(secret), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
__name(key, "key");
var digestOf = /* @__PURE__ */ __name(async (ticket) => base64url_exports.encode(new Uint8Array(await crypto.subtle.digest("SHA-256", text.encode(ticket)))), "digestOf");
var time = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "time");
async function issueTicket(db, secret, input) {
  const credentials = validateCredentials(input);
  const ticket = base64url_exports.encode(crypto.getRandomValues(new Uint8Array(32)));
  const digest = await digestOf(ticket);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const now3 = time();
  const expiresAt = now3 + 600;
  const payload = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: text.encode(digest) },
    await key(secret),
    text.encode(JSON.stringify(credentials))
  );
  const [, inserted] = await db.batch([
    db.prepare("DELETE FROM enrollment_tickets WHERE expires_at <= ?").bind(now3),
    db.prepare(`INSERT INTO enrollment_tickets (digest, device_id, expires_at, iv, payload)
      VALUES (?, ?, ?, ?, ?) ON CONFLICT(device_id) DO NOTHING`).bind(digest, credentials.deviceId, expiresAt, base64url_exports.encode(iv), base64url_exports.encode(new Uint8Array(payload)))
  ]);
  return inserted.meta.changes === 1 ? { ticket, expiresAt } : void 0;
}
__name(issueTicket, "issueTicket");
async function redeemTicket(db, secret, ticket) {
  if (typeof ticket !== "string" || !tokenPattern.test(ticket)) return;
  const decryptKey = await key(secret);
  const digest = await digestOf(ticket);
  const row = await db.prepare(`DELETE FROM enrollment_tickets WHERE digest = ? AND expires_at > ?
    RETURNING iv, payload`).bind(digest, time()).first();
  if (!row) return;
  const plaintext = await crypto.subtle.decrypt({
    name: "AES-GCM",
    iv: base64url_exports.decode(row.iv),
    additionalData: text.encode(digest)
  }, decryptKey, base64url_exports.decode(row.payload));
  return validateCredentials(JSON.parse(parse.decode(plaintext)));
}
__name(redeemTicket, "redeemTicket");
function ticketCancellation(db, deviceId) {
  if (typeof deviceId !== "string" || !devicePattern.test(deviceId)) throw new Error("Invalid device id");
  return db.prepare("DELETE FROM enrollment_tickets WHERE device_id = ?").bind(deviceId);
}
__name(ticketCancellation, "ticketCancellation");
async function cancelTicket(db, deviceId) {
  await ticketCancellation(db, deviceId).run();
}
__name(cancelTicket, "cancelTicket");
async function protect(secret, label2, value) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: text.encode(label2) },
    await key(secret),
    text.encode(JSON.stringify(value))
  );
  return base64url_exports.encode(iv) + "." + base64url_exports.encode(new Uint8Array(encrypted));
}
__name(protect, "protect");
async function unprotect(secret, label2, value) {
  const [iv, cipher] = value.split(".");
  const clear = await crypto.subtle.decrypt({
    name: "AES-GCM",
    iv: base64url_exports.decode(iv),
    additionalData: text.encode(label2)
  }, await key(secret), base64url_exports.decode(cipher));
  return JSON.parse(parse.decode(clear));
}
__name(unprotect, "unprotect");

// ../cloud/device-revocation.mjs
var encoder2 = new TextEncoder();
var revocationMessage = /* @__PURE__ */ __name((origin, deviceId) => encoder2.encode(JSON.stringify(["devspace-fleet/revoke/v1", origin, deviceId])), "revocationMessage");
var key2 = /* @__PURE__ */ __name((token, usage) => crypto.subtle.importKey(
  "raw",
  base64url_exports.decode(token),
  { name: "HMAC", hash: "SHA-256" },
  false,
  [usage]
), "key");
async function activationDigest(token) {
  return base64url_exports.encode(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder2.encode(token))));
}
__name(activationDigest, "activationDigest");
async function revokeResponse(origin, deviceId, token) {
  const proof = await crypto.subtle.sign("HMAC", await key2(token, "sign"), revocationMessage(origin, deviceId));
  return { status: "revoked", deviceId, proof: base64url_exports.encode(new Uint8Array(proof)) };
}
__name(revokeResponse, "revokeResponse");

// ../cloud/cloudflare.mjs
var endpoint = "https://api.cloudflare.com/client/v4";
var cloudflareRequestTimeoutMs = 15e3;
var routeWords = /* @__PURE__ */ new Set([
  "accounts",
  "zones",
  "user",
  "access",
  "organizations",
  "identity_providers",
  "apps",
  "policies",
  "dns_records",
  "workers",
  "scripts",
  "d1",
  "database",
  "query",
  "mcp",
  "portals",
  "cfd_tunnel",
  "token",
  "tokens",
  "subdomain",
  "domains",
  "permission_groups",
  "versions"
]);
function safeCloudflareRoute(path) {
  if (typeof path !== "string" || !path.startsWith("/")) return "/{resource}";
  return path.split("?")[0].split("/").map((part, index) => index === 0 ? "" : routeWords.has(part) ? part : "{id}").join("/");
}
__name(safeCloudflareRoute, "safeCloudflareRoute");
var accessNotEnabled = "access_not_enabled";
function accountAccessOrganizationError(method, url, status, payload) {
  if (method !== "GET" || status !== 403 || url.search || !/^\/client\/v4\/accounts\/[a-f0-9]{32}\/access\/organizations$/.test(url.pathname) || payload?.success !== false || payload.result !== null || !Array.isArray(payload.errors) || payload.errors.length !== 1) return;
  const error = payload.errors[0];
  if (error?.code === 9999 && typeof error.message === "string" && error.message.startsWith("access.api.error.not_enabled:")) return accessNotEnabled;
}
__name(accountAccessOrganizationError, "accountAccessOrganizationError");
var CloudflareError = class extends Error {
  static {
    __name(this, "CloudflareError");
  }
  constructor(method, status, codes, { path, rayId, reason } = {}) {
    const route = path ? ` ${safeCloudflareRoute(path)}` : "";
    const ray = typeof rayId === "string" && /^[a-zA-Z0-9-]{6,80}$/.test(rayId) ? rayId : void 0;
    super(`Cloudflare ${method}${route} failed (HTTP ${status}${codes.length ? ", codes " + codes.join(", ") : ""}${ray ? ", Ray ID " + ray : ""})`);
    this.status = status;
    this.codes = codes;
    if (reason === accessNotEnabled) this.reason = accessNotEnabled;
    if (ray) this.rayId = ray;
  }
};
var CloudflareRequestTimeoutError = class extends Error {
  static {
    __name(this, "CloudflareRequestTimeoutError");
  }
  constructor(method, timeoutMs) {
    super(`Cloudflare ${method} request did not complete within ${timeoutMs / 1e3} seconds`);
    this.method = method;
    this.timeoutMs = timeoutMs;
  }
};
function cloudflareApi(token, { request = fetch, beforeRequest, requestTimeoutMs = cloudflareRequestTimeoutMs } = {}) {
  async function send(method, path, body, query) {
    const access = typeof token === "function" ? await token() : token;
    await beforeRequest?.();
    const url = new URL(endpoint + path);
    for (const [name, value] of Object.entries(query ?? {})) url.searchParams.set(name, String(value));
    const headers = { Authorization: `Bearer ${access}` };
    const form = body instanceof FormData;
    if (body && !form) headers["Content-Type"] = "application/json";
    const controller = new AbortController();
    const { signal } = controller;
    const exchange = /* @__PURE__ */ __name(async () => {
      const response = await request(url, {
        method,
        headers,
        redirect: "manual",
        signal,
        ...body && { body: form ? body : JSON.stringify(body) }
      });
      signal.throwIfAborted();
      if (method === "DELETE" && response.status === 204) return { result: void 0 };
      const payload = await response.json().catch(() => {
        signal.throwIfAborted();
        return void 0;
      });
      if (!response.ok || payload?.success !== true) {
        const codes = Array.isArray(payload?.errors) ? payload.errors.map((error) => error?.code).filter(Number.isInteger) : [];
        throw new CloudflareError(method, response.status, codes, {
          path,
          rayId: response.headers.get("cf-ray"),
          reason: accountAccessOrganizationError(method, url, response.status, payload)
        });
      }
      return payload;
    }, "exchange");
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        const error = new CloudflareRequestTimeoutError(method, requestTimeoutMs);
        reject(error);
        controller.abort(error);
      }, requestTimeoutMs);
    });
    try {
      return await Promise.race([exchange(), deadline]);
    } finally {
      clearTimeout(timer);
    }
  }
  __name(send, "send");
  return {
    async get(path, query) {
      return (await send("GET", path, void 0, query)).result;
    },
    async getOptional(path) {
      try {
        return (await send("GET", path)).result;
      } catch (error) {
        if (error.status !== 404) throw error;
      }
    },
    async list(path, { per_page: pageSize = 100, ...query } = {}) {
      const items = [];
      for (let page2 = 1; page2 <= 20; page2++) {
        const response = await send("GET", path, void 0, { ...query, page: page2, per_page: pageSize });
        if (!Array.isArray(response.result)) throw new Error("Unexpected Cloudflare list response");
        items.push(...response.result);
        if (response.result_info?.total_pages <= page2 || response.result.length < pageSize) return items;
      }
      throw new Error("Cloudflare list exceeded the reconciliation limit");
    },
    async post(path, body) {
      return (await send("POST", path, body)).result;
    },
    async put(path, body) {
      return (await send("PUT", path, body)).result;
    },
    async patch(path, body) {
      return (await send("PATCH", path, body)).result;
    },
    async del(path) {
      return (await send("DELETE", path)).result;
    }
  };
}
__name(cloudflareApi, "cloudflareApi");
function single(items, predicate, label2) {
  const matches = items.filter(predicate);
  if (matches.length > 1) throw new Error(`Duplicate ${label2}; stop and inspect Cloudflare`);
  return matches[0];
}
__name(single, "single");
async function ensureDns(api, zoneId, name, target, owner) {
  const path = `/zones/${zoneId}/dns_records`;
  const existing = single(await api.list(path, { name }), (item) => item.name === name, "DNS record");
  if (!existing) return api.post(path, { name, type: "CNAME", content: target, proxied: true, ttl: 1, comment: owner });
  if (existing.type !== "CNAME" || existing.content.replace(/\.$/, "") !== target || !existing.proxied || existing.comment !== owner) {
    throw new Error("DNS hostname already belongs to a different configuration");
  }
  return existing;
}
__name(ensureDns, "ensureDns");
async function ensureAccessApp(api, account, app, policyId, { attachNewManagedApp = false } = {}) {
  const path = account + "/access/apps";
  const applications = await api.list(path);
  const predicate = /* @__PURE__ */ __name((row) => app.domain ? row.domain === app.domain || row.destinations?.some((dest) => dest.uri === app.domain) : row.destinations?.some((dest) => dest.mcp_server_id === app.destinations[0].mcp_server_id), "predicate");
  const existing = single(applications, (row) => row.name === app.name || predicate(row), "Access application");
  if (!existing) return api.post(path, { ...app, policies: [{ id: policyId, precedence: 1 }] });
  const policies = existing.policies ?? [];
  const appIsExact = predicate(existing) && existing.type === app.type && existing.name === app.name && policies.length === 1 && (policies[0]?.id ?? policies[0]) === policyId && (!app.oauth_configuration?.enabled || existing.oauth_configuration?.enabled === true);
  if (appIsExact) return existing;
  if (attachNewManagedApp && !policies.length && existing.id && predicate(existing) && existing.name === app.name && existing.type === app.type) {
    return api.put(path + "/" + existing.id, { ...app, policies: [{ id: policyId, precedence: 1 }] });
  }
  throw new Error("Access application drifted or already belongs to another service");
}
__name(ensureAccessApp, "ensureAccessApp");

// ../cloud/zone-access.mjs
function matchesDestination(row, app) {
  return app.domain ? row.domain === app.domain || row.destinations?.some((item) => item.uri === app.domain) : row.destinations?.some((item) => item.mcp_server_id === app.destinations[0].mcp_server_id);
}
__name(matchesDestination, "matchesDestination");
async function ensureScopedAccessApp(api, spec, app, {
  bootstrap = false,
  managed = false,
  accountScoped = false,
  exactLoginProviders = false
} = {}) {
  const accountPath = `/accounts/${spec.accountId}/access/apps`;
  const path = accountScoped ? accountPath : `/zones/${spec.zoneId}/access/apps`;
  const matches = /* @__PURE__ */ __name((row) => row.name === app.name || matchesDestination(row, app), "matches");
  const exact = /* @__PURE__ */ __name((row) => row && row.name === app.name && row.type === app.type && matchesDestination(row, app), "exact");
  const scoped = single(await api.list(path), matches, "Access application");
  if (!accountScoped) {
    const account = single(await api.list(accountPath), matches, "account Access application");
    if (account && account.id !== scoped?.id) {
      throw new Error("Cloudflare Access application is outside the zone API; account Access write is required");
    }
  }
  if (scoped && !exact(scoped)) throw new Error("Zone Access application ownership does not match");
  const rule = {
    name: bootstrap ? `${spec.label}-device-bootstrap` : `${spec.label}-owner`,
    decision: bootstrap ? "bypass" : "allow",
    include: bootstrap ? [{ everyone: {} }] : [{ email: { email: spec.ownerEmail } }],
    exclude: [],
    require: !bootstrap && exactLoginProviders ? [{ login_method: { id: app.allowed_idps[0] } }] : [],
    precedence: 1
  };
  const created = scoped ?? await api.post(path, managed ? app : { ...app, policies: [rule] }).catch((error) => {
    if (!accountScoped && app.type === "mcp" && error.status === 400 && error.codes?.includes(12130)) {
      throw new Error("Cloudflare rejected the zone-scoped MCP Access application (12130). Configure it at account scope.", { cause: error });
    }
    throw error;
  });
  if (!/^[a-f0-9-]{32,36}$/.test(created?.id ?? "")) throw new Error("Zone Access application ID unavailable");
  const appPath = `${path}/${created.id}`;
  const current = await api.get(appPath);
  if (!exact(current) || app.oauth_configuration?.enabled && current.oauth_configuration?.enabled !== true) {
    throw new Error("Cloudflare zone Access application failed destination or OAuth verification");
  }
  if (app.allowed_idps) {
    const allowed = current.allowed_idps;
    const selected = Array.isArray(allowed) && allowed.length > 0;
    const hasCompatibleProvider = selected && allowed.some((id) => app.allowed_idps.includes(id));
    const usesAccountDefaults = allowed === void 0 || Array.isArray(allowed) && !allowed.length;
    const compatible = current.auto_redirect_to_identity === true ? hasCompatibleProvider && allowed.length === 1 : hasCompatibleProvider || scoped && usesAccountDefaults;
    const matchesAllowed = selected && new Set(allowed).size === app.allowed_idps.length && allowed.every((id) => app.allowed_idps.includes(id));
    if (!compatible || (!scoped || exactLoginProviders) && !matchesAllowed || exactLoginProviders && current.allow_authenticate_via_warp !== false) {
      const method = exactLoginProviders ? "\u5DF2\u9A8C\u8BC1\u7684 SSO \u767B\u5F55\u65B9\u5F0F" : "Cloudflare \u6216 One-time PIN";
      throw new Error(`\u5F53\u524D Access \u5E94\u7528\u672A\u63D0\u4F9B\u6240\u9700\u7684\u7BA1\u7406\u5458\u767B\u5F55\u65B9\u5F0F\u3002\u8BF7\u5728 Zero Trust \u2192 Access controls \u2192 Applications \u4E2D\u6838\u5BF9\u8BE5\u5E94\u7528\u7684${method}\uFF0C\u518D\u7528\u539F\u547D\u4EE4\u52A0 --resume\u3002`);
    }
  }
  const policies = `${appPath}/policies`;
  let rules = await api.list(policies);
  if (!rules.length && (managed || !scoped)) {
    await api.post(policies, rule);
    rules = await api.list(policies);
  }
  const [existing] = rules;
  if (rules.length !== 1 || existing.name !== rule.name || existing.decision !== rule.decision || JSON.stringify(existing.include) !== JSON.stringify(rule.include) || existing.exclude?.length || JSON.stringify(existing.require ?? []) !== JSON.stringify(rule.require)) {
    throw new Error("Cloudflare zone Access application policy does not match the requested restriction");
  }
  return current;
}
__name(ensureScopedAccessApp, "ensureScopedAccessApp");

// ../cloud/oauth-grant.mjs
var runtimeOAuthScopes = ["mcp-portals.write", "zone-access.write", "teams-connector-cloudflared.write", "dns.write"];
var managementOAuthScopes = [
  "mcp-portals.write",
  "access.write",
  "teams-connector-cloudflared.write",
  "dns.write",
  "workers-scripts.write",
  "d1.write",
  "zone.read",
  "access-acct.read",
  "offline_access"
];
var managementIdentityScope = "user-details.read";
var managementIdentityOAuthScopes = [...managementOAuthScopes, managementIdentityScope];
var managementBootstrapScope = "access-acct.write";
var managementBootstrapOAuthScopes = [...managementIdentityOAuthScopes, managementBootstrapScope];
var oauthTokenValue = /^[!-~]{20,8192}$/;
function runtimeGrant(token, previous, expected = runtimeOAuthScopes, optional = []) {
  const { access_token: access, refresh_token: refresh, expires_in: duration, scope, token_type: type } = token ?? {};
  const scopes = typeof scope === "string" ? scope.trim().split(/\s+/) : void 0;
  if (scope !== void 0 || !previous) {
    if (!scopes || !expected.every((value) => scopes.includes(value)) || scopes.some((value) => value !== "offline_access" && !expected.includes(value) && !optional.includes(value))) {
      throw new Error("Cloudflare issued a different grant than the Fleet runtime permissions.");
    }
  }
  if (typeof type !== "string" || type.toLowerCase() !== "bearer" || !Number.isSafeInteger(duration) || duration < 60 || duration > 86400 || typeof access !== "string" || !oauthTokenValue.test(access) || typeof refresh !== "string" || !oauthTokenValue.test(refresh) || refresh === previous?.refresh) {
    throw new Error("Cloudflare did not issue a usable bearer and rotating refresh credential.");
  }
  return { access, refresh, expiresAt: Math.floor(Date.now() / 1e3) + duration };
}
__name(runtimeGrant, "runtimeGrant");
function usableStoredGrant(grant) {
  return Number.isSafeInteger(grant?.expiresAt) && typeof grant.access === "string" && oauthTokenValue.test(grant.access) && typeof grant.refresh === "string" && oauthTokenValue.test(grant.refresh);
}
__name(usableStoredGrant, "usableStoredGrant");

// ../cloud/oauth-provisioning.mjs
var tokenEndpoint = "https://dash.cloudflare.com/oauth2/token";
var credentialRoute = "https://fleet-oauth.internal/access-token";
var recordKey = "credential";
var credentialLabel = "fleet-runtime-oauth";
var reconnectBinding = "FLEET_OAUTH_RECONNECT";
var now = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "now");
var OAuthProvisioner = class {
  static {
    __name(this, "OAuthProvisioner");
  }
  constructor(state2, env, request = fetch) {
    this.storage = state2.storage;
    this.env = env;
    this.request = request;
  }
  async fetch(request) {
    if (request.url !== credentialRoute || request.method !== "POST") return new Response(null, { status: 404 });
    try {
      this.inFlight ??= this.access().finally(() => {
        this.inFlight = void 0;
      });
      const access = await this.inFlight;
      return Response.json({ access }, { headers: { "Cache-Control": "no-store" } });
    } catch {
      return Response.json({ error: "runtime_authorization_unavailable" }, { status: 503 });
    }
  }
  async access() {
    const { FLEET_OAUTH_KEY: key3, FLEET_OAUTH_SEED: seed, FLEET_OAUTH_CLIENT_ID: clientId } = this.env;
    if (!tokenPattern.test(key3 ?? "") || !/^[A-Za-z0-9_-]{8,128}$/.test(clientId ?? "")) {
      throw new Error("The Fleet OAuth binding is incomplete.");
    }
    let record = await this.storage.get(recordKey);
    const combined = this.env.FLEET_OAUTH_MODE === "managed";
    let generation = record?.generation;
    let applied = record?.applied ?? (generation ? [generation] : []);
    let consumedReconnect = false;
    const reconnect = combined && this.env[reconnectBinding];
    if (reconnect) {
      const next2 = JSON.parse(reconnect);
      if (!/^[a-f0-9]{32}$/.test(next2?.generation ?? "") || next2.clientId !== clientId || !usableStoredGrant(next2.grant)) throw new Error("The Fleet OAuth reconnect grant is invalid.");
      if (!applied.includes(next2.generation)) {
        if (next2.grant.expiresAt <= now() + 45) throw new Error("The Fleet OAuth reconnect grant expired.");
        generation = next2.generation;
        applied = [...applied, generation];
        record = { generation, applied, sealed: await protect(key3, credentialLabel, next2.grant) };
        await this.storage.put(recordKey, record);
      }
      consumedReconnect = next2.generation === generation;
    }
    if (!record && seed) {
      const initial = JSON.parse(seed);
      if (!usableStoredGrant(initial)) throw new Error("The Fleet OAuth seed is invalid.");
      record = await protect(key3, credentialLabel, initial);
      await this.storage.put(recordKey, record);
    }
    const sealed = typeof record === "string" ? record : record?.sealed;
    if (typeof sealed !== "string") throw new Error("The Fleet OAuth grant must be reconnected.");
    const credential = await unprotect(key3, credentialLabel, sealed);
    if (credential.expiresAt > now() + 45) {
      await this.clearSeed(credential.access, "FLEET_OAUTH_SEED");
      if (consumedReconnect) await this.clearSeed(credential.access, reconnectBinding);
      return credential.access;
    }
    await this.storage.put(recordKey, generation ? { state: "refresh_started", generation, applied } : { state: "refresh_started" });
    const { request } = this;
    const response = await request(tokenEndpoint, {
      method: "POST",
      redirect: "manual",
      signal: AbortSignal.timeout(1e4),
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ grant_type: "refresh_token", client_id: clientId, refresh_token: credential.refresh })
    });
    if (!response.ok) throw new Error("Cloudflare did not renew the Fleet grant.");
    const managementScopes = this.env.FLEET_OAUTH_ZERO_TRUST_BOOTSTRAP === "1" ? managementBootstrapOAuthScopes : this.env.FLEET_OAUTH_USER_DETAILS === "1" ? managementIdentityOAuthScopes : managementOAuthScopes;
    const renewed = runtimeGrant(await response.json(), credential, combined ? managementScopes : void 0);
    const next = await protect(key3, credentialLabel, renewed);
    await this.storage.put(recordKey, generation ? { generation, applied, sealed: next } : next);
    await this.clearSeed(renewed.access, "FLEET_OAUTH_SEED");
    if (consumedReconnect) await this.clearSeed(renewed.access, reconnectBinding);
    return renewed.access;
  }
  async clearSeed(access, binding) {
    this.clearedSeeds ??= /* @__PURE__ */ new Set();
    if (!this.env[binding] || this.env.FLEET_OAUTH_MODE !== "managed" || this.clearedSeeds.has(binding)) return;
    const { accountId, worker, label: label2 } = JSON.parse(this.env.FLEET_SPEC);
    if (!/^[a-f0-9]{32}$/.test(accountId ?? "") || worker !== label2 || !/^fleet-[a-z0-9]+-[a-f0-9]{12}$/.test(worker ?? "")) {
      throw new Error("The OAuth seed does not belong to this management Worker.");
    }
    const path = `/accounts/${accountId}/workers/scripts/${worker}/secrets/${binding}`;
    try {
      await cloudflareApi(access, { request: this.request }).del(path);
    } catch (error) {
      if (error.status !== 404) throw error;
    }
    this.clearedSeeds.add(binding);
  }
};
async function workerOAuthAccess(namespace) {
  const broker = namespace.get(namespace.idFromName("fleet-provisioner"));
  const response = await broker.fetch(credentialRoute, { method: "POST" });
  if (!response.ok) return;
  const { access } = await response.json();
  return typeof access === "string" && oauthTokenValue.test(access) ? access : void 0;
}
__name(workerOAuthAccess, "workerOAuthAccess");

// ../cloud/portal-client-callbacks.mjs
var portalCallbackPresets = [
  { client: "ChatGPT", uris: [
    "https://chatgpt.com/connector_platform_oauth_redirect",
    "https://chatgpt.com/connector/oauth/*"
  ] },
  { client: "Claude", uris: ["https://claude.ai/api/mcp/auth_callback"] },
  { client: "Cursor", uris: [
    "https://www.cursor.com/agents/mcp/oauth/callback",
    "http://localhost:8787/callback",
    "cursor://anysphere.cursor-mcp/oauth/callback"
  ] },
  { client: "VS Code", uris: ["https://vscode.dev/redirect", "http://127.0.0.1:33418/"] }
];
var defaultUris = portalCallbackPresets.flatMap((preset) => preset.uris);
var PortalCallbackError = class extends Error {
  static {
    __name(this, "PortalCallbackError");
  }
  constructor(message2, status) {
    super(message2);
    this.status = status;
  }
};
function applicationPath(spec) {
  return (spec.zoneScopedAccess ? "/zones/" + spec.zoneId : "/accounts/" + spec.accountId) + "/access/apps";
}
__name(applicationPath, "applicationPath");
function ownsPortal(app, spec) {
  return app?.name === spec.label && app.type === "mcp_portal" && (app.domain === spec.portalHostname || !app.domain && app.destinations?.length === 1 && app.destinations[0].uri === spec.portalHostname) && (!app.destinations?.length || app.destinations.length === 1 && app.destinations[0].uri === spec.portalHostname);
}
__name(ownsPortal, "ownsPortal");
async function loadPortal(api, spec, id) {
  const path = applicationPath(spec);
  const appId = id ?? single(
    await api.list(path, { domain: spec.portalHostname }),
    (app2) => ownsPortal(app2, spec),
    "managed Portal Access application"
  )?.id;
  if (!appId) throw new PortalCallbackError("\u627E\u4E0D\u5230\u8BE5\u90E8\u7F72\u7684 Portal Access \u5E94\u7528\u3002", 409);
  const resource = path + "/" + appId;
  const app = await api.get(resource);
  if (!ownsPortal(app, spec)) throw new PortalCallbackError("Portal Access \u5E94\u7528\u5F52\u5C5E\u5DF2\u53D8\u5316\u3002", 409);
  return { resource, app };
}
__name(loadPortal, "loadPortal");
function registrationOf(app) {
  return app.oauth_configuration?.dynamic_client_registration ?? {};
}
__name(registrationOf, "registrationOf");
function callbackState(app) {
  const registration = registrationOf(app);
  return {
    enabled: app.oauth_configuration?.enabled === true && registration.enabled === true,
    allowedUris: registration.allowed_uris ?? [],
    allowLocalhost: registration.allow_any_on_localhost === true,
    allowLoopback: registration.allow_any_on_loopback === true,
    presets: portalCallbackPresets
  };
}
__name(callbackState, "callbackState");
function exactRedirect(value) {
  if (typeof value !== "string" || !/^[a-z][a-z0-9+.-]*:\/[^#*{}\s\\]+$/i.test(value) || value.length > 2048) {
    throw new PortalCallbackError("\u8BF7\u8F93\u5165\u5BA2\u6237\u7AEF\u7684\u5B8C\u6574\u56DE\u8C03\u5730\u5740\u3002\u5B83\u4E0D\u80FD\u5305\u542B\u901A\u914D\u7B26\u6216\u7247\u6BB5\u3002", 400);
  }
  const url = URL.parse(value);
  const allowedScheme = url?.protocol === "https:" || url?.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) || url?.protocol === "cursor:" || /^[a-z][a-z0-9-]*(?:\.[a-z0-9-]+)+:$/i.test(url?.protocol ?? "");
  if (!url || !allowedScheme || url.username || url.password || /^https?:$/.test(url.protocol) && !/^https?:\/\/[^/]/i.test(value)) {
    throw new PortalCallbackError("\u56DE\u8C03\u5730\u5740\u5FC5\u987B\u4F7F\u7528 HTTPS\u3001\u73AF\u56DE HTTP \u6216\u5BA2\u6237\u7AEF\u7684\u539F\u751F\u56DE\u8C03\u534F\u8BAE\u3002", 400);
  }
  if ([...url.searchParams.keys()].some((key3) => /^(?:code|state|client_secret|access_token|refresh_token|id_token|token)$/i.test(key3))) {
    throw new PortalCallbackError("\u8BF7\u4F7F\u7528\u5BA2\u6237\u7AEF\u7684\u56DE\u8C03\u5730\u5740\uFF0C\u53BB\u6389\u6388\u6743\u7801\u6216\u51ED\u636E\u3002", 400);
  }
  return value;
}
__name(exactRedirect, "exactRedirect");
function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map((key3) => [key3, canonical(value[key3])]));
}
__name(canonical, "canonical");
function policySnapshot(policies) {
  return policies.map(({ updated_at, ...policy }) => JSON.stringify(canonical(policy))).sort().join("\n");
}
__name(policySnapshot, "policySnapshot");
function applicationSnapshot(app) {
  const { updated_at, policies, oauth_configuration, ...settings } = app;
  const { dynamic_client_registration, ...oauth } = oauth_configuration ?? {};
  const { enabled, allowed_uris, ...registration } = dynamic_client_registration ?? {};
  return JSON.stringify(canonical({ settings, oauth, registration, policies: policySnapshot(policies ?? []) }));
}
__name(applicationSnapshot, "applicationSnapshot");
async function updateCallbacks(api, spec, resource, original, uris, initialize = false) {
  const policies = policySnapshot(await api.list(resource + "/policies"));
  const current = await api.get(resource);
  if (!ownsPortal(current, spec) || JSON.stringify(canonical(current)) !== JSON.stringify(canonical(original))) {
    throw new PortalCallbackError("Portal \u914D\u7F6E\u521A\u521A\u66F4\u65B0\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002", 409);
  }
  const existing = registrationOf(current);
  await api.put(resource, {
    ...current,
    oauth_configuration: {
      ...current.oauth_configuration,
      dynamic_client_registration: {
        ...existing,
        ...initialize && { enabled: true },
        allowed_uris: uris
      }
    }
  });
  const app = await api.get(resource);
  const state2 = callbackState(app);
  if (!ownsPortal(app, spec) || !state2.enabled || applicationSnapshot(app) !== applicationSnapshot(current) || state2.allowedUris.length !== uris.length || !uris.every((uri) => state2.allowedUris.includes(uri)) || policySnapshot(await api.list(resource + "/policies")) !== policies) {
    throw new PortalCallbackError("Cloudflare \u56DE\u8BFB\u4E0E\u9884\u671F\u4E0D\u7B26\uFF0C\u8BF7\u68C0\u67E5 Portal \u914D\u7F6E\u540E\u518D\u8BD5\u3002", 409);
  }
  return state2;
}
__name(updateCallbacks, "updateCallbacks");
async function readPortalCallbacks(api, spec) {
  return callbackState((await loadPortal(api, spec)).app);
}
__name(readPortalCallbacks, "readPortalCallbacks");
async function addPortalCallback(api, spec, input) {
  const uri = exactRedirect(input);
  const { resource, app } = await loadPortal(api, spec);
  const state2 = callbackState(app);
  if (!state2.enabled) throw new PortalCallbackError("\u8BE5 Portal \u5C1A\u672A\u542F\u7528\u52A8\u6001\u5BA2\u6237\u7AEF\u6CE8\u518C\u3002", 409);
  if (state2.allowedUris.includes(uri)) return state2;
  return updateCallbacks(api, spec, resource, app, [...state2.allowedUris, uri]);
}
__name(addPortalCallback, "addPortalCallback");

// ../cloud/profiles.mjs
var profiles = {
  probe: { path: "/probe/mcp", tools: ["open_workspace", "read"] },
  development: {
    path: "/devspace/mcp",
    port: 7829,
    tools: ["open_workspace", "read", "apply_patch", "exec_command", "write_stdin"]
  },
  browser: {
    path: "/browser/mcp",
    port: 7831,
    tools: ["browser_profiles", "browser_navigate", "browser_snapshot", "browser_tabs", "browser_click"],
    optional: [
      "browser_navigate_back",
      "browser_hover",
      "browser_press_key",
      "browser_type",
      "browser_fill_form",
      "browser_select_option",
      "browser_wait_for",
      "browser_take_screenshot"
    ]
  }
};

// ../cloud/devices.mjs
var now2 = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "now");
var randomToken = /* @__PURE__ */ __name(() => base64url_exports.encode(crypto.getRandomValues(new Uint8Array(32))), "randomToken");
var tunnelIdPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
var DeviceError = class extends Error {
  static {
    __name(this, "DeviceError");
  }
  constructor(message2, status = 400) {
    super(message2);
    this.status = status;
  }
};
function validId(id) {
  if (typeof id !== "string" || !devicePattern.test(id)) throw new DeviceError("Invalid device ID");
}
__name(validId, "validId");
async function deviceLease(db, action, request = fetch) {
  const owner = randomToken();
  const row = await db.prepare(`INSERT INTO fleet_leases (id, owner, expires_at) VALUES (1, ?, ?)
    ON CONFLICT(id) DO UPDATE SET owner = excluded.owner, expires_at = excluded.expires_at
    WHERE fleet_leases.expires_at <= ? RETURNING owner`).bind(owner, now2() + 90, now2()).first();
  if (!row) throw new DeviceError("Another device operation is still running. Retry shortly.", 409);
  const guard = /* @__PURE__ */ __name(async () => {
    const result = await db.prepare("UPDATE fleet_leases SET expires_at = ? WHERE owner = ? AND expires_at > ? RETURNING owner").bind(now2() + 90, owner, now2()).first();
    if (!result) throw new DeviceError("Device operation lease expired. Retry from the management page.", 409);
  }, "guard");
  try {
    return await action({ request, beforeRequest: guard }, guard);
  } finally {
    await db.prepare("DELETE FROM fleet_leases WHERE owner = ?").bind(owner).run().catch(() => {
    });
  }
}
__name(deviceLease, "deviceLease");
async function readDevice(db, id) {
  validId(id);
  return db.prepare("SELECT * FROM fleet_devices WHERE id = ?").bind(id).first();
}
__name(readDevice, "readDevice");
function identity(spec, row) {
  const hostname = row.id + spec.deviceSuffix;
  const profile = /* @__PURE__ */ __name((kind, token) => ({
    ...profiles[kind],
    kind,
    token,
    id: row.unique_name + (kind === "development" ? "-d" : "-b"),
    url: "https://" + hostname + profiles[kind].path
  }), "profile");
  return { hostname, profile };
}
__name(identity, "identity");
function tunnelRules(hostname, profiles2) {
  return [...profiles2.map((r) => ({
    hostname,
    path: "^" + r.path + "$",
    service: `http://127.0.0.1:${r.port}`,
    originRequest: { httpHostHeader: `127.0.0.1:${r.port}` }
  })), { service: "http_status:404" }];
}
__name(tunnelRules, "tunnelRules");
async function ensureTunnel(api, account, spec, db, row, profiles2) {
  const path = account + "/cfd_tunnel";
  const name = `${spec.label}-${row.unique_name}`;
  const { hostname } = identity(spec, row);
  const found = row.tunnel_id ? await api.get(path + "/" + row.tunnel_id) : single(await api.list(path, { name, is_deleted: false }), (tunnel2) => tunnel2.name === name, "device Tunnel");
  if (found && (found.name !== name || found.config_src !== "cloudflare")) throw new DeviceError("Tunnel ownership could not be verified", 409);
  const tunnel = found ?? await api.post(path, { name, config_src: "cloudflare" });
  if (!tunnelIdPattern.test(tunnel?.id ?? "")) throw new Error("Tunnel ID unavailable");
  if (!row.tunnel_id) await db.prepare("UPDATE fleet_devices SET tunnel_id = ? WHERE id = ?").bind(tunnel.id, row.id).run();
  await ensureDns(api, spec.zoneId, hostname, tunnel.id + ".cfargotunnel.com", spec.label);
  const config = { ingress: tunnelRules(hostname, profiles2) };
  await api.put(`${path}/${tunnel.id}/configurations`, { config });
  return tunnel.id;
}
__name(ensureTunnel, "ensureTunnel");
async function ensureMcpServer(api, account, spec, route) {
  const path = account + "/access/ai-controls/mcp/servers";
  const existing = await api.getOptional(path + "/" + route.id);
  if (existing && (existing.name !== route.id || existing.hostname !== route.url || existing.auth_type !== "bearer")) {
    throw new DeviceError("MCP server ownership changed", 409);
  }
  if (!existing) {
    await api.post(path, { id: route.id, name: route.id, hostname: route.url, auth_type: "bearer", auth_credentials: route.token });
  }
  const app = {
    name: route.id,
    type: "mcp",
    destinations: [{ type: "via_mcp_server_portal", mcp_server_id: route.id }]
  };
  if (spec.zoneScopedAccess || spec.accountScopedAccess) {
    await ensureScopedAccessApp(api, spec, app, { managed: true, accountScoped: spec.accountScopedAccess });
  } else await ensureAccessApp(api, account, app, spec.policyId, { attachNewManagedApp: true });
  const synced = await api.post(path + "/" + route.id + "/sync");
  if (synced?.status !== "ready") throw new DeviceError("Cloudflare has not synced the MCP tool catalog yet. Retry device activation.", 409);
}
__name(ensureMcpServer, "ensureMcpServer");
function overrides(items) {
  return items?.flatMap((item) => item.portal_alias !== void 0 || item.portal_description !== void 0 || item.portal_enabled !== void 0 ? [{ name: item.name, alias: item.portal_alias, description: item.portal_description, enabled: item.portal_enabled }] : []);
}
__name(overrides, "overrides");
async function updatePortal(api, account, spec, { add = [], remove = [] }) {
  const path = account + "/access/ai-controls/mcp/portals/" + spec.portalId;
  const portal = await api.get(path);
  if (portal.hostname !== spec.portalHostname || portal.name !== spec.label) throw new DeviceError("Portal ownership changed", 409);
  const previous = (portal.servers ?? []).map((row) => ({
    server_id: row.server_id ?? row.id,
    on_behalf: row.on_behalf,
    default_disabled: row.default_disabled,
    updated_tools: overrides(row.updated_tools),
    updated_prompts: overrides(row.updated_prompts)
  }));
  const ids = new Set(previous.map((row) => row.server_id));
  const next = previous.filter((row) => !remove.includes(row.server_id));
  for (const server_id of add) if (!ids.has(server_id)) next.push({ server_id, on_behalf: false });
  if (JSON.stringify(next) !== JSON.stringify(previous)) await api.put(path, { servers: next });
}
__name(updatePortal, "updatePortal");
function constantTimeEqual(actual, expected) {
  if (actual.length !== expected.length) return false;
  let different = 0;
  for (let index = 0; index < actual.length; index++) different |= actual.charCodeAt(index) ^ expected.charCodeAt(index);
  return different === 0;
}
__name(constantTimeEqual, "constantTimeEqual");
async function sameToken(actual, expected) {
  if (typeof actual !== "string" || !tokenPattern.test(actual)) return false;
  return constantTimeEqual(await activationDigest(actual), await activationDigest(expected));
}
__name(sameToken, "sameToken");
async function verifyRoute(route, request) {
  const headers = {
    Authorization: `Bearer ${route.token}`,
    "Content-Type": "application/json",
    Accept: "application/json, text/event-stream"
  };
  const dispatch = /* @__PURE__ */ __name(async (method, params, id) => {
    const response = await request(route.url, {
      method: "POST",
      headers,
      redirect: "manual",
      signal: AbortSignal.timeout(7e3),
      body: JSON.stringify({ jsonrpc: "2.0", method, params, id })
    });
    if (!response.ok) throw new DeviceError("The device authenticated MCP route is still unavailable. Retry activation.", 409);
    return response;
  }, "dispatch");
  const initialized = await dispatch("initialize", {
    protocolVersion: "2025-11-25",
    capabilities: {},
    clientInfo: { name: "devspace-fleet-manager", version: "1.0.0" }
  }, 1);
  const result = (await initialized.json()).result;
  if (result?.protocolVersion !== "2025-11-25") throw new DeviceError("The device did not negotiate the expected MCP protocol", 409);
  headers["MCP-Protocol-Version"] = result.protocolVersion;
  await dispatch("notifications/initialized");
  const listing = await dispatch("tools/list", {}, 2);
  const catalog = (await listing.json()).result;
  const names = Array.isArray(catalog?.tools) ? catalog.tools.map((tool) => tool?.name) : [];
  if (!route.tools.every((name) => names.includes(name))) {
    throw new DeviceError("The device did not expose its expected tool catalog", 409);
  }
  if (route.kind === "browser") {
    const allowed = [...route.tools, ...route.optional];
    if (catalog.nextCursor !== void 0 || new Set(names).size !== names.length || names.some((name) => !allowed.includes(name))) {
      throw new DeviceError("The browser endpoint did not expose a single browser-only tool catalog", 409);
    }
  }
}
__name(verifyRoute, "verifyRoute");
function createDevices(env, request = fetch) {
  const spec = JSON.parse(env.FLEET_SPEC);
  const releases = JSON.parse(env.RELEASE_CATALOG);
  const installers = { ...releases, ...hostedInstallers(releases) };
  const account = "/accounts/" + spec.accountId;
  const db = env.TICKETS;
  const token = env.PROVISIONER_OAUTH ? async () => {
    const access = await workerOAuthAccess(env.PROVISIONER_OAUTH);
    if (!access) throw new DeviceError("Fleet Cloudflare authorization is unavailable. Reconnect it before retrying.", 503);
    return access;
  } : env.PROVISIONER_TOKEN;
  const wrap = /* @__PURE__ */ __name((row, action) => protect(env.TICKET_KEY, row.unique_name, action), "wrap");
  const unwrap = /* @__PURE__ */ __name((row) => unprotect(env.TICKET_KEY, row.unique_name, row.credentials), "unwrap");
  const authorized = /* @__PURE__ */ __name(async (row, token2) => {
    if (!row || !row.credentials || typeof token2 !== "string" || !tokenPattern.test(token2)) return;
    const stored = await unwrap(row);
    if (row.status === "disabled") {
      if (stored.revocation) {
        return constantTimeEqual(await activationDigest(token2), stored.activationHash) ? stored : void 0;
      }
      if (await sameToken(token2, stored.activationToken)) {
        return { revocation: await revokeResponse(spec.origin, row.id, token2) };
      }
      return;
    }
    if (await sameToken(token2, stored.activationToken)) return stored;
  }, "authorized");
  const deviceRoutes = /* @__PURE__ */ __name((row, tokens) => {
    const { profile } = identity(spec, row);
    return [profile("development", tokens.portalToken), ...tokens.browserToken ? [profile("browser", tokens.browserToken)] : []];
  }, "deviceRoutes");
  const run = /* @__PURE__ */ __name((action) => deviceLease(db, (options, guard) => action(cloudflareApi(token, options), guard), request), "run");
  const callbackLabels = /* @__PURE__ */ __name(async (state2) => {
    const { results } = await db.prepare("SELECT redirect_uri, client_name FROM portal_callback_labels ORDER BY client_name, redirect_uri").all();
    return {
      ...state2,
      clients: results.filter((row) => state2.allowedUris.includes(row.redirect_uri)).map((row) => ({ redirectUri: row.redirect_uri, clientName: row.client_name }))
    };
  }, "callbackLabels");
  return {
    releases,
    async clientCallbacks() {
      return callbackLabels(await readPortalCallbacks(cloudflareApi(token, { request }), spec));
    },
    async registerClientCallback(name, uri) {
      const clientName = typeof name === "string" ? name.trim() : "";
      if (!clientName || clientName.length > 64 || /[\x00-\x1f\x7f]/.test(clientName)) {
        throw new PortalCallbackError("\u5BA2\u6237\u7AEF\u540D\u79F0\u5E94\u4E3A 1 \u81F3 64 \u4E2A\u53EF\u89C1\u5B57\u7B26\u3002", 400);
      }
      return run(async (api) => {
        const state2 = await addPortalCallback(api, spec, uri);
        await db.prepare(`INSERT INTO portal_callback_labels (redirect_uri, client_name)
          VALUES (?, ?) ON CONFLICT (redirect_uri) DO NOTHING`).bind(uri, clientName).run();
        return callbackLabels(state2);
      });
    },
    async list() {
      return (await db.prepare("SELECT id, platform, status, updated_at FROM fleet_devices ORDER BY id").all()).results;
    },
    async launch(id, platform, { confirmBrowser = false } = {}) {
      validId(id);
      if (!Object.hasOwn(installers, platform)) throw new DeviceError("No verified installer is configured for this platform");
      return run(async (api) => {
        let row = await readDevice(db, id);
        if (row && (row.platform !== platform || row.status !== "pending")) {
          throw new DeviceError("This device already exists or is disabled. Choose a new device ID.", 409);
        }
        let credentials = row && await unwrap(row);
        const asset = credentials?.asset ?? installers[platform];
        if (asset.assets && JSON.stringify(asset) !== JSON.stringify(installers[platform])) {
          throw new DeviceError("The device is pinned to a previous hosted release. Choose a new device ID.", 409);
        }
        if (Boolean(asset.browser) !== confirmBrowser) {
          throw new DeviceError(asset.browser ? "\u8BF7\u786E\u8BA4\u5728\u6B64\u8BBE\u5907\u4E0A\u542F\u7528\u6D4F\u89C8\u5668\u5DE5\u5177\u3002" : "\u6B64\u5B89\u88C5\u5305\u672A\u63D0\u4F9B\u6D4F\u89C8\u5668\u5DE5\u5177\u3002", 400);
        }
        if (!row) {
          const unique = id + "-" + crypto.randomUUID().slice(0, 5);
          row = { id, unique_name: unique };
          credentials = {
            asset,
            portalToken: randomToken(),
            activationToken: randomToken(),
            ...asset.browser && { browserToken: randomToken() }
          };
          await db.prepare(`INSERT INTO fleet_devices (id, platform, status, unique_name, credentials, updated_at)
            VALUES (?, ?, 'pending', ?, ?, ?)`).bind(id, platform, unique, await wrap(row, credentials), now2()).run();
          row = await readDevice(db, id);
        }
        if (Boolean(asset.browser) !== Boolean(credentials.browserToken)) {
          throw new DeviceError("The pending device browser capability differs from its original release. Cancel it or use a new device ID.", 409);
        }
        const tunnel = await ensureTunnel(api, account, spec, db, row, deviceRoutes(row, credentials));
        const tunnelToken = await api.get(`${account}/cfd_tunnel/${tunnel}/token`);
        const issued = await issueTicket(db, env.TICKET_KEY, { deviceId: id, tunnelToken, ...credentials });
        if (!issued) throw new DeviceError("This device already has an unclaimed ticket. Cancel it or wait for expiration.", 409);
        return { ...issued, asset };
      });
    },
    async activate(id, token2) {
      validId(id);
      const existing = await readDevice(db, id);
      const authorization = await authorized(existing, token2);
      if (!authorization) throw new DeviceError("Device activation rejected", 401);
      if (authorization.revocation) return authorization.revocation;
      if (existing.status === "active") return { status: "active" };
      return run(async (api, guard) => {
        const row = await readDevice(db, id);
        const tokens = await authorized(row, token2);
        if (!tokens) throw new DeviceError("Device activation rejected", 401);
        if (tokens.revocation) return tokens.revocation;
        if (row.status === "active") return { status: "active" };
        if (!row.tunnel_id) throw new DeviceError("Device has no registered Tunnel", 409);
        const profiles2 = deviceRoutes(row, tokens);
        await guard();
        const proofs = await Promise.allSettled(profiles2.map((route) => verifyRoute(route, request)));
        const failed = proofs.find((result) => result.status === "rejected");
        if (failed) throw failed.reason;
        for (const route of profiles2) await ensureMcpServer(api, account, spec, route);
        await updatePortal(api, account, spec, { add: profiles2.map((route) => route.id) });
        await db.prepare("UPDATE fleet_devices SET status = 'active', updated_at = ? WHERE id = ?").bind(now2(), id).run();
        return { status: "active" };
      });
    },
    async status(id) {
      const row = await readDevice(db, id);
      if (!row) throw new DeviceError("Unknown device", 404);
      const api = cloudflareApi(token, { request });
      const tunnel = row.tunnel_id && await api.get(`${account}/cfd_tunnel/${row.tunnel_id}`);
      const stored = row.credentials ? await unwrap(row) : null;
      const { profile } = identity(spec, row);
      const serverIds = [profile("development").id, ...stored?.browserToken ? [profile("browser").id] : []];
      const mcpProfiles = { development: "unverified", browser: stored?.browserToken ? "unverified" : "not_enabled" };
      if (row.status === "disabled") mcpProfiles.browser = "disabled";
      if (row.status === "active" && stored) {
        const profiles2 = deviceRoutes(row, stored);
        const proofs = await Promise.allSettled(profiles2.map((route) => verifyRoute(route, request)));
        for (const [index, route] of profiles2.entries()) {
          mcpProfiles[route.kind] = proofs[index].status === "fulfilled" ? "catalog_verified" : "unavailable";
        }
      }
      const mcp = mcpProfiles.browser === "unavailable" ? "unavailable" : mcpProfiles.development;
      return {
        deviceId: id,
        registration: row.status,
        tunnel: tunnel?.status ?? "unregistered",
        mcp,
        mcpProfiles,
        ...row.status === "disabled" ? { revocation: !stored || stored.revocation ? "complete" : "pending" } : { serverIds, release: stored?.asset?.version }
      };
    },
    async disable(id) {
      validId(id);
      return run(async (api) => {
        const row = await readDevice(db, id);
        if (!row) throw new DeviceError("Unknown device", 404);
        const stored = row.credentials ? await unwrap(row) : null;
        if (row.status === "disabled" && (!stored || stored.revocation)) return { status: "disabled" };
        await db.batch([
          db.prepare("UPDATE fleet_devices SET status = 'disabled', updated_at = ? WHERE id = ?").bind(now2(), id),
          ticketCancellation(db, id)
        ]);
        if (row.tunnel_id) {
          const path = `${account}/cfd_tunnel/${row.tunnel_id}`;
          const tunnel = await api.get(path);
          if (tunnel.name !== `${spec.label}-${row.unique_name}`) throw new DeviceError("Tunnel ownership changed", 409);
          await api.put(path + "/configurations", { config: { ingress: tunnelRules("", []) } });
          if (row.credentials) {
            const secret = base64url_exports.encode(crypto.getRandomValues(new Uint8Array(32))).replaceAll("-", "+").replaceAll("_", "/") + "=";
            await api.patch(path, { tunnel_secret: secret });
            await api.del(path + "/connections");
          }
        }
        await updatePortal(api, account, spec, { remove: [row.unique_name + "-d", row.unique_name + "-b"] });
        const revoked = stored && await wrap(row, {
          activationHash: await activationDigest(stored.activationToken),
          revocation: await revokeResponse(spec.origin, id, stored.activationToken)
        });
        await db.prepare("UPDATE fleet_devices SET credentials = ? WHERE id = ?").bind(revoked, id).run();
        return { status: "disabled" };
      });
    }
  };
}
__name(createDevices, "createDevices");

// ../cloud/management-client.mjs
var consoleScript = String.raw`
  const theme = document.querySelector('#theme');
  const systemTheme = matchMedia('(prefers-color-scheme: dark)');
  const applyTheme = () => {
    document.documentElement.dataset.theme = theme.value === 'system' ? (systemTheme.matches ? 'dark' : 'light') : theme.value;
    theme.dataset.preference = theme.value;
    document.querySelector('#theme-icon').setAttribute('href', {dark: '#moon', light: '#sun', system: '#monitor'}[theme.value]);
  };
  theme.addEventListener('change', applyTheme);
  systemTheme.addEventListener('change', applyTheme);
  applyTheme();

  const search = document.querySelector('#device-search');
  const filters = [...document.querySelectorAll('[data-filter]')];
  const rows = [...document.querySelectorAll('tbody tr')];
  const empty = document.querySelector('#empty');
  let status = 'all';
  function updateRows() {
    const query = search.value.trim().toLowerCase();
    for (const row of rows) {
      row.hidden = (status !== 'all' && row.dataset.state !== status) ||
        !row.querySelector('.device-name').textContent.toLowerCase().includes(query);
    }
    empty.hidden = rows.some(row => !row.hidden);
    document.querySelector('table').hidden = !empty.hidden;
  }
  search.addEventListener('input', updateRows);
  for (const filter of filters) {
    filter.addEventListener('click', () => {
      status = filter.dataset.filter;
      for (const item of filters) item.setAttribute('aria-pressed', item === filter);
      updateRows();
    });
  }
  document.querySelector('#clear-filters').addEventListener('click', () => {
    search.value = '';
    filters[0].click();
    search.focus();
  });

  const copy = document.querySelector('#copy-address');
  const address = document.querySelector('#address');
  const copyFeedback = document.querySelector('#copy-feedback');

  async function copyNodeContents(node) {
    try {
      await navigator.clipboard.writeText(node.textContent);
      return true;
    } catch {
      const range = document.createRange();
      range.selectNodeContents(node);
      node.focus();
      const selection = getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      return false;
    }
  }

  copy.addEventListener('click', async () => {
    const copied = await copyNodeContents(address);
    const result = copied ? '已复制' : '按快捷键复制';
    copy.querySelector('span').textContent = result;
    copyFeedback.textContent = copied ? 'Portal 地址已复制' : '已选中 Portal 地址，可用系统复制快捷键。';
  });


  updateRows();
  copy.disabled = !address.textContent.startsWith('https://');

  async function requestJson(path, options = {}) {
    const response = await fetch(path, {
      ...options,
      headers: { Accept: 'application/json' },
      redirect: 'error',
      cache: 'no-store',
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || !data) throw new Error(data?.error || '请求失败，请检查管理台连接后重试。');
    return data;
  }

  function post(path, fields) {
    return requestJson(path, { method: 'POST', body: new URLSearchParams(fields) });
  }

  const callbackPath = '/admin/client-callbacks';
  const callbackDialog = document.querySelector('#callback-dialog');
  const callbackTitle = document.querySelector('#callback-title');
  const callbackOverview = document.querySelector('#callback-overview');
  const callbackStatus = document.querySelector('#callback-state');
  const callbackSummary = document.querySelector('#callback-summary');
  const callbackFeedback = document.querySelector('#callback-feedback');
  const callbackList = document.querySelector('#callback-configured-list');
  const callbackForm = document.querySelector('#callback-form');
  const callbackName = document.querySelector('#callback-name');
  const callbackAddress = document.querySelector('#callback-url');
  const callbackSaveError = document.querySelector('#callback-save-error');
  const callbackClose = callbackDialog.querySelector('.dialog-close');
  const saveCallback = document.querySelector('#save-callback');
  const cancelCallback = document.querySelector('#cancel-callback');
  const addClient = document.querySelector('#add-client');
  const addWorkBuddy = document.querySelector('#add-workbuddy');
  const presetRows = callbackDialog.querySelectorAll('[data-preset-name]');
  let callbackFormTrigger;
  let allowedCallbacks = new Set();
  let callbackSubmitting = false;
  let callbackLoad;

  function callbackText(element, message) {
    element.textContent = message;
    element.hidden = !message;
  }

  function callbackError(input, message) {
    callbackText(document.getElementById(input.id + '-error'), message);
    if (message) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }

  function resetCallbackForm() {
    callbackTitle.textContent = '客户端回调配置';
    callbackForm.reset();
    callbackError(callbackName, '');
    callbackError(callbackAddress, '');
    callbackText(callbackSaveError, '');
    callbackForm.hidden = true;
    callbackOverview.hidden = false;
  }

  function callbackRow(uri, name, enabled) {
    const row = document.createElement('li');
    row.className = 'callback-client';
    const identity = document.createElement('div');
    identity.className = 'callback-identity';
    const label = document.createElement('strong');
    label.textContent = name;
    const tag = document.createElement('span');
    tag.className = 'callback-tag';
    tag.textContent = enabled ? '已配置' : '已保存';
    identity.append(label, tag);
    const field = document.createElement('div');
    field.className = 'callback-uri';
    const address = document.createElement('code');
    address.textContent = uri;
    field.append(address);
    row.append(identity, field);
    return row;
  }

  function renderCallbacks(state) {
    const { allowedUris = [], clients = [], presets = [] } = state;
    const enabled = state.enabled === true;
    allowedCallbacks = new Set(allowedUris);
    const labels = new Map(presets.flatMap(({ client, uris }) => uris.map(uri => [uri, client])));
    for (const { redirectUri, clientName } of clients) labels.set(redirectUri, clientName);
    callbackStatus.textContent = enabled ? '已启用' : '未启用';
    callbackSummary.textContent = enabled
      ? 'Portal 已设 ' + allowedCallbacks.size + ' 条回调规则。' +
        (state.allowLocalhost ? ' 允许 localhost。' : '') + (state.allowLoopback ? ' 允许环回地址。' : '')
      : 'Portal 的动态客户端注册未启用。';
    addClient.disabled = addWorkBuddy.disabled = !enabled;
    callbackList.replaceChildren(...[...allowedCallbacks].map(uri =>
      callbackRow(uri, labels.get(uri) || URL.parse(uri)?.hostname || '现有回调', enabled)));
    document.querySelector('#callback-configured').hidden = !allowedCallbacks.size;
    for (const row of presetRows) {
      for (const address of row.querySelectorAll('[data-callback-address]')) {
        const uri = address.dataset.callbackAddress || address.textContent;
        const configured = allowedCallbacks.has(uri);
        const status = address.parentElement.querySelector('span');
        status.dataset.label ??= status.textContent;
        status.textContent = status.dataset.label + ' · ' +
          (configured ? (enabled ? '已配置' : '已保存') : '未配置');
      }
    }
    const workBuddyStatus = document.querySelector('#workbuddy-state');
    const configured = clients.some(({ clientName }) => clientName.toLowerCase() === 'workbuddy');
    workBuddyStatus.textContent = configured ? (enabled ? '已配置' : '已保存') : '待配置';
    workBuddyStatus.dataset.tone = configured ? '' : 'pending';
  }

  document.querySelector('#open-callbacks').addEventListener('click', async () => {
    resetCallbackForm();
    callbackText(callbackFeedback, '');
    addClient.disabled = addWorkBuddy.disabled = true;
    document.querySelector('#callback-configured').hidden = true;
    document.querySelector('#callback-presets').hidden = true;
    callbackStatus.textContent = '读取中';
    callbackSummary.textContent = '正在读取 Portal 中的配置…';
    callbackDialog.showModal();
    const loading = requestJson(callbackPath);
    callbackLoad = loading;
    try {
      const state = await loading;
      if (callbackLoad !== loading || !callbackDialog.open) return;
      renderCallbacks(state);
      document.querySelector('#callback-presets').hidden = false;
    } catch (error) {
      if (callbackLoad !== loading || !callbackDialog.open) return;
      callbackStatus.textContent = '读取失败';
      callbackSummary.textContent = '关闭面板后可重新读取配置。';
      callbackText(callbackFeedback, error.message);
    }
  });

  for (const trigger of [addClient, addWorkBuddy]) {
    trigger.addEventListener('click', () => {
      callbackFormTrigger = trigger;
      callbackText(callbackFeedback, '');
      callbackOverview.hidden = true;
      callbackForm.hidden = false;
      const client = trigger.dataset.client;
      callbackTitle.textContent = client ? '填写 WorkBuddy 回调' : '添加其他客户端';
      callbackName.value = client || '';
      (client ? callbackAddress : callbackName).focus();
    });
  }

  function cancelCallbackForm() {
    resetCallbackForm();
    callbackFormTrigger.focus();
  }

  cancelCallback.addEventListener('click', cancelCallbackForm);
  callbackDialog.addEventListener('cancel', event => {
    if (callbackForm.hidden) return;
    event.preventDefault();
    if (!callbackSubmitting) cancelCallbackForm();
  });
  for (const input of [callbackName, callbackAddress]) {
    input.addEventListener('input', () => {
      callbackError(input, '');
      callbackText(callbackSaveError, '');
    });
  }
  callbackForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (callbackSubmitting) return;
    const clientName = callbackName.value.trim();
    const redirectUri = callbackAddress.value.trim();
    const nameError = clientName ? '' : '请填写客户端名称。';
    const uriError = !redirectUri ? '请填写回调地址。'
      : allowedCallbacks.has(redirectUri) ? '该回调地址已配置。' : '';
    callbackError(callbackName, nameError);
    callbackError(callbackAddress, uriError);
    if (nameError || uriError) {
      (nameError ? callbackName : callbackAddress).focus();
      return;
    }
    callbackSubmitting = true;
    saveCallback.disabled = cancelCallback.disabled = callbackClose.disabled = true;
    saveCallback.textContent = '正在保存…';
    callbackText(callbackSaveError, '');
    try {
      renderCallbacks(await post(callbackPath, { clientName, redirectUri }));
      resetCallbackForm();
      callbackText(callbackFeedback, '回调地址已保存到 Portal。');
      callbackFeedback.focus();
    } catch (error) {
      callbackText(callbackSaveError, error.message);
    } finally {
      callbackSubmitting = false;
      saveCallback.disabled = cancelCallback.disabled = callbackClose.disabled = false;
      saveCallback.textContent = '保存';
    }
  });

  const addDialog = document.querySelector('#add-dialog');
  const addTitle = document.querySelector('#add-title');
  const addForm = document.querySelector('#add-device-form');
  const addFeedback = document.querySelector('#add-feedback');
  const issue = document.querySelector('#issue-command');
  const browserConsent = document.querySelector('#browser-consent');
  const browserConsentOption = document.querySelector('#confirm-browser');
  const addClose = [...addDialog.querySelectorAll('[form="close-add"]')];
  const commandResult = document.querySelector('#device-command-result');
  const command = document.querySelector('#device-command');
  const copyCommand = document.querySelector('#copy-device-command');
  const commandFeedback = document.querySelector('#device-command-feedback');
  let issuing = false;
  let issued = false;
  function configureBrowserConsent() {
    const bundled = addForm.querySelector('input[name="platform"]:checked')?.dataset.browser === 'true';
    browserConsent.hidden = !bundled;
    browserConsentOption.disabled = !bundled;
    browserConsentOption.required = bundled;
    browserConsentOption.checked = false;
  }
  addForm.addEventListener('change', event => { if (event.target.name === 'platform') configureBrowserConsent(); });
  document.querySelector('#add').addEventListener('click', () => {
    configureBrowserConsent();
    addFeedback.hidden = true;
    addDialog.showModal();
  });
  addDialog.addEventListener('cancel', event => { if (issuing) event.preventDefault(); });
  addDialog.addEventListener('close', () => {
    command.textContent = '';
    if (issued) location.reload();
  });
  addForm.addEventListener('submit', async event => {
    event.preventDefault();
    if (issuing || issued) return;
    issuing = true;
    issue.disabled = true;
    for (const button of addClose) button.disabled = true;
    addFeedback.hidden = false;
    addFeedback.textContent = '正在生成命令…';
    try {
      const result = await post(addForm.action, new FormData(addForm));
      issued = true;
      command.textContent = result.command;
      document.querySelector('#device-command-target').textContent = result.deviceId + ' · ' + result.platform;
      document.querySelector('#command-instructions').textContent = result.instructions;
      addFeedback.hidden = true;
      addForm.hidden = true;
      commandResult.hidden = false;
      addTitle.textContent = '设备连接指令';
      command.focus();
    } catch (error) {
      addFeedback.textContent = error.message;
    } finally {
      issuing = false;
      issue.disabled = false;
      for (const button of addClose) button.disabled = false;
    }
  });
  copyCommand.addEventListener('click', async () => {
    const copied = await copyNodeContents(command);
    copyCommand.querySelector('span').textContent = copied ? '已复制' : '按快捷键复制';
    commandFeedback.textContent = copied ? '已复制完整指令。' : '已选中完整指令，请使用系统复制快捷键。';
    commandFeedback.hidden = false;
  });

  const detail = document.querySelector('#device-dialog');
  const detailTitle = document.querySelector('#device-dialog-title');
  const summary = document.querySelector('#device-summary');
  const details = document.querySelector('#device-details');
  const detailFeedback = document.querySelector('#device-feedback');
  const riskMark = document.querySelector('#risk-mark');
  const detailDismiss = document.querySelector('#detail-dismiss');
  const detailConfirm = document.querySelector('#detail-confirm');
  const detailClose = [...detail.querySelectorAll('[form="close-detail"], #detail-dismiss')];
  const stateLabels = { pending: '等待设备接入', active: '已注册到 Portal', disabled: '已停用' };
  const mcpLabels = { catalog_verified: '目录已验证', unavailable: '目录无法访问', unverified: '等待验证',
    not_enabled: '未启用', disabled: '已停用' };
  let selected;
  let saving = false;
  let refreshOnClose = false;

  function showField(field, value) {
    const label = document.querySelector('#' + field + '-label');
    const output = document.querySelector('#' + field + '-detail');
    if (label) label.hidden = !value;
    output.hidden = Boolean(label) && !value;
    output.textContent = value || '未查询';
  }

  for (const button of document.querySelectorAll('[data-action]')) {
    button.addEventListener('click', async () => {
      const row = button.closest('tr');
      const action = button.dataset.action;
      const current = { deviceId: row.dataset.device, action };
      selected = current;
      const isRisk = action === 'disable' || action === 'cancel';
      detail.dataset.risk = isRisk;
      detailTitle.textContent = action === 'status' ? '设备状态' : button.textContent;
      summary.textContent = row.querySelector('.device-name').textContent + ' · ' + row.querySelector('.system').textContent;
      details.hidden = isRisk;
      riskMark.hidden = !isRisk;
      detailDismiss.textContent = isRisk ? '取消' : '关闭';
      detailConfirm.hidden = !isRisk;
      detailConfirm.disabled = false;
      detailConfirm.textContent = action === 'disable' ? '确认停用' : '确认取消票据';
      showField('registration', row.querySelector('.state').textContent);
      for (const field of ['tunnel', 'mcp', 'browser', 'release', 'revocation', 'server']) showField(field);
      detailFeedback.textContent = {
        disable: '停用将撤销该设备的安装票据、Tunnel 凭据和 Portal 路由。',
        cancel: '取消后，这台设备未使用的安装票据将失效。',
      }[action] || '正在检查设备状态…';
      detail.showModal();

      if (isRisk) return;
      try {
        const data = await post('/admin/device', { deviceId: current.deviceId, action: 'status' });
        if (selected !== current) return;
        showField('registration', stateLabels[data.registration] ?? data.registration);
        showField('tunnel', data.tunnel);
        const development = data.mcpProfiles?.development ?? data.mcp;
        const browser = data.mcpProfiles?.browser;
        showField('mcp', mcpLabels[development] ?? development);
        showField('browser', mcpLabels[browser] ?? browser);
        showField('release', data.release);
        showField('revocation', data.revocation && (data.revocation === 'complete' ? '已完成' : '尚未完成'));
        showField('server', data.serverIds?.join(' · '));
        detailFeedback.textContent = '';
        if (action === 'review' && data.revocation !== 'complete') {
          current.action = 'disable';
          detailConfirm.hidden = false;
          detailConfirm.textContent = '重试停用';
          detailFeedback.textContent = '重试会继续撤销该设备尚未停用的远程接入。';
        }
      } catch (error) {
        if (selected === current) detailFeedback.textContent = error.message;
      }
    });
  }

  detail.addEventListener('cancel', event => { if (saving) event.preventDefault(); });
  detail.addEventListener('close', () => {
    selected = undefined;
    if (refreshOnClose) location.reload();
  });
  detailConfirm.addEventListener('click', async () => {
    if (saving || !selected || !['disable', 'cancel'].includes(selected.action)) return;
    saving = true;
    detailConfirm.disabled = true;
    for (const button of detailClose) button.disabled = true;
    detailFeedback.textContent = '正在提交请求…';
    try {
      await post('/admin/device', selected);
      refreshOnClose = true;
      detailConfirm.hidden = true;
      detailDismiss.textContent = '关闭';
      detailFeedback.textContent = selected.action === 'disable' ? '远程接入已停用。' : '安装票据已取消。';
    } catch (error) {
      detailFeedback.textContent = error.message;
    } finally {
      saving = false;
      detailConfirm.disabled = false;
      for (const button of detailClose) button.disabled = false;
    }
  });
`;

// ../cloud/management-view.mjs
var consoleStyles = String.raw`
  :root {
    color-scheme: dark;
    --bg: #0a0a0a; --bar: #111; --surface: #121212; --inset: #171717;
    --hover: #1d1d1d; --selected: #191919; --line: #333; --rule: #272727;
    --text: #f1f1f1; --secondary: #adadad; --blue: #2165dc; --blue-hover: #2b71ed;
    --active: #38d5a0; --pending: #e6ae57; --disabled: #969696; --focus: #78aaff;
    --risk: #ff9599; --risk-bg: #412426;
    font: 14px/1.5 -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif;
  }
  :root[data-theme="light"] {
    color-scheme: light;
    --bg: #fcfcfc; --bar: #fff; --surface: #f7f7f7; --inset: #f1f1f1;
    --hover: #e9e9e9; --selected: #e9e9e9; --line: #d2d2d2; --rule: #dedede;
    --text: #171717; --secondary: #4d4d4d; --active: #008a5e; --pending: #ad6a00;
    --disabled: #747474; --focus: #165dcc; --risk: #a41e27; --risk-bg: #f9dfe0;
  }
  *, *::before, *::after { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--text); }
  [hidden] { display: none !important; }
  .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
  :focus-visible { outline: 2px solid var(--focus); outline-offset: 2px; }
  button, input, select { font: inherit; color: inherit; }
  button { cursor: pointer; }
  button, input, select { border: 1px solid var(--line); border-radius: 8px; background: var(--inset); }
  button:hover { background: var(--hover); }
  .icon { width: 16px; height: 16px; flex: none; fill: none; stroke: currentColor; stroke-width: 1.65; stroke-linecap: round; stroke-linejoin: round; }
  .button { display: inline-flex; align-items: center; justify-content: center; gap: 7px; padding: 0 12px; min-height: 34px; white-space: nowrap; }
  .primary { background: var(--blue); border-color: var(--blue); color: #fff; font-weight: 590; min-height: 36px; padding-inline: 12px 14px; }
  .primary:hover { background: var(--blue-hover); border-color: var(--blue-hover); }
  button:disabled { cursor: default; opacity: .58; }

  .topbar { min-height: 54px; padding: 7px 22px; display: flex; align-items: center; justify-content: space-between; gap: 16px; background: var(--bar); border-bottom: 1px solid var(--rule); }
  .brand { display: inline-flex; align-items: center; gap: 9px; font-size: 16px; font-weight: 650; }
  .brand img { display: block; width: 28px; height: 28px; border-radius: 5px; }
  .theme { position: relative; display: inline-flex; align-items: center; }
  .theme .icon { position: absolute; left: 9px; pointer-events: none; }
  .theme .chevron { left: auto; right: 8px; width: 12px; height: 12px; }
  .theme select { appearance: none; background: var(--bg); min-height: 34px; width: 88px; padding: 0 23px 0 29px; border-radius: 7px; font-size: 13px; cursor: pointer; }
  .theme select[data-preference="system"] { width: 115px; }

  main { width: min(1000px, calc(100% - 48px)); margin: 34px auto 0; padding-bottom: 64px; }
  .page-intro { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); align-items: center; gap: 28px; }
  .heading h1 { margin: 0 0 6px; font-size: 30px; font-weight: 680; line-height: 1.25; letter-spacing: .01em; }
  .heading p { margin: 0; color: var(--secondary); font-size: 14px; }
  .portal { display: flex; align-items: center; gap: 10px; min-height: 48px; padding: 6px 7px 6px 12px; background: var(--inset); border: 1px solid var(--line); border-radius: 8px; }
  .portal strong { flex: none; font-size: 14px; font-weight: 550; color: var(--secondary); }
  .portal-value { display: flex; align-items: center; justify-content: space-between; gap: 8px; flex: 1; min-width: 0; }
  .portal code { min-width: 0; color: var(--text); font: 13px/1.55 ui-monospace, SFMono-Regular, Consolas, monospace; overflow-wrap: anywhere; }
  .portal .button { flex: none; min-width: 92px; padding-inline: 8px; font-size: 13px; }
  .portal-tools { display: flex; justify-content: flex-end; margin-top: 5px; }
  .portal-tools .button { min-height: 32px; padding-inline: 8px; border-color: transparent; background: transparent; color: var(--secondary); }
  .portal-tools .button:hover { background: var(--hover); color: var(--text); }

  .devices { margin-top: 25px; }
  h2 { margin: 0; font-size: 16px; font-weight: 650; line-height: 1.4; }
  .registry-heading { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 11px; }
  .toolbar { display: grid; grid-template-columns: minmax(0, 2.9fr) minmax(0, 1fr); align-items: stretch; gap: 10px; margin-bottom: 9px; }
  .filters { display: flex; align-items: center; gap: 1px; padding: 2px; min-height: 38px; border: 1px solid var(--rule); border-radius: 7px; background: var(--bg); }
  .filters button { display: inline-flex; align-items: center; gap: 8px; padding: 2px 10px; background: transparent; border-color: transparent; border-radius: 5px; white-space: nowrap; color: var(--secondary); min-height: 32px; }
  .filters button:hover { color: var(--text); background: var(--hover); }
  .filters button[aria-pressed="true"] { border-color: var(--line); background: var(--selected); color: var(--text); }
  :root[data-theme="light"] .filters button[aria-pressed="true"] { border-color: #bbb; }
  .count { display: inline-grid; place-items: center; width: 19px; height: 19px; border: 1px solid var(--line); border-radius: 50%; font-size: 12px; font-variant-numeric: tabular-nums; background: var(--bg); }
  .search { display: flex; align-items: center; gap: 8px; padding: 0 11px; border: 1px solid var(--line); background: var(--inset); border-radius: 7px; }
  .search .icon { color: var(--secondary); }
  .search:focus-within { outline: 2px solid var(--focus); outline-offset: 2px; }
  .search input { border: 0; outline: none; width: 100%; min-width: 0; min-height: 36px; padding: 0; background: transparent; }
  .search input::placeholder { color: var(--secondary); opacity: 1; }

  .table-wrap { border: 1px solid var(--line); border-radius: 8px; background: var(--surface); }
  table { width: 100%; border-collapse: collapse; text-align: left; }
  .identity-col { width: 35%; }
  .state-col { width: 24%; }
  th, td { padding-inline: 16px; border-bottom: 1px solid var(--rule); }
  thead th { height: 37px; color: var(--secondary); font-weight: 540; font-size: 13px; }
  tbody th, tbody td { height: 58px; }
  tbody tr:last-child > * { border-bottom: 0; }
  .identity { display: flex; align-items: center; gap: 11px; }
  .initial { display: grid; place-items: center; flex: none; width: 33px; height: 33px; background: var(--inset); border: 1px solid var(--line); border-radius: 7px; font-size: 14px; font-weight: 590; }
  .device-name { display: block; font-size: 14px; font-weight: 640; line-height: 1.25; overflow-wrap: anywhere; }
  .system { display: block; margin-top: 2px; color: var(--secondary); font-size: 12px; font-weight: 400; }
  .state { display: inline-flex; align-items: center; gap: 7px; padding: 2px 7px; border: 1px solid var(--rule); border-radius: 999px; white-space: nowrap; font-size: 12px; }
  .state::before { width: 6px; height: 6px; border-radius: 50%; content: ""; background: var(--disabled); }
  tr[data-state="active"] .state::before { background: var(--active); }
  tr[data-state="pending"] .state::before { background: var(--pending); }
  .row-actions { display: flex; align-items: center; gap: 6px; }
  .row-actions .button { min-height: 30px; padding-inline: 9px; font-size: 13px; }
  .row-actions .quiet { background: transparent; border-color: transparent; color: var(--secondary); }
  .row-actions .quiet:hover { background: var(--hover); color: var(--text); }
  .note { margin: 10px 0 0; color: var(--secondary); font-size: 12px; }
  .empty { display: grid; justify-items: center; gap: 6px; text-align: center; padding: 24px 16px; }
  .empty .icon { color: var(--secondary); width: 25px; height: 25px; }
  .empty p { margin: 0 0 3px; color: var(--secondary); font-size: 13px; }

  dialog { max-width: min(426px, calc(100% - 32px)); width: 100%; color: var(--text); background: var(--surface); border: 1px solid var(--line); border-radius: 11px; padding: 0; }
  dialog::backdrop { background: #0009; }
  .dialog-head { display: flex; align-items: center; justify-content: space-between; padding: 15px 17px 4px; gap: 12px; }
  .dialog-close { display: grid; place-items: center; min-width: 28px; min-height: 28px; padding: 0; border-color: transparent; background: transparent; }
  .dialog-body { padding: 8px 17px 16px; }
  dialog p { margin: 0; color: var(--secondary); }
  dialog label { display: grid; gap: 5px; margin-top: 12px; }
  dialog input { padding: 6px 9px; min-width: 0; }
  .platform-tabs { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); min-width: 0; margin: 0; padding: 0; border: 0; border-radius: 7px; background: var(--inset); }
  .platform-tabs label { display: block; position: relative; min-width: 0; margin: 0; cursor: pointer; }
  .platform-tabs label + label::before { position: absolute; inset: 5px auto 5px 0; width: 1px; background: var(--line); content: ""; }
  .platform-tabs span:not(.sr-only) { position: relative; display: grid; place-items: center; min-height: 38px; padding: 4px 6px; border: 1px solid transparent; border-radius: 7px; color: var(--secondary); }
  .platform-tabs label:hover span { color: var(--text); }
  .platform-tabs input:checked + span { z-index: 1; background: var(--surface); border-color: var(--line); color: var(--text); font-weight: 600; }
  .platform-tabs input:focus-visible + span { z-index: 2; outline: 2px solid var(--focus); outline-offset: -2px; }
  .field-hint { margin-top: 5px; color: var(--secondary); font-size: 12px; }
  .dialog-actions { display: flex; justify-content: flex-end; flex-wrap: wrap; gap: 7px; padding: 11px 17px; border-top: 1px solid var(--rule); background: var(--inset); }
  .dialog-actions .primary { min-height: 34px; }
  .feedback { margin-top: 12px; font-size: 13px; }
  .device-command { padding-top: 7px; }
  .device-command > p { margin-bottom: 12px; font-size: 13px; }
  .device-command h3 { margin: 0; font-size: 14px; font-weight: 650; }
  .device-command pre { margin: 7px 0 12px; padding: 10px 11px; border: 1px solid var(--line); border-radius: 7px; background: var(--inset); color: var(--text); font: 13px/1.65 ui-monospace, SFMono-Regular, Consolas, monospace; white-space: pre-wrap; overflow-wrap: anywhere; }
  .device-command .primary { width: 100%; min-height: 40px; }
  #device-command-feedback { margin: 7px 0 0; font-size: 12px; }
  .detail { display: grid; grid-template-columns: max-content minmax(0,1fr); gap: 7px 18px; margin: 10px 0 0; }
  .detail dt { color: var(--secondary); }
  .detail dd { margin: 0; overflow-wrap: anywhere; }
  #device-dialog[data-risk="true"] { max-width: min(360px, calc(100% - 32px)); }
  #device-dialog[data-risk="true"] .dialog-head { justify-content: center; padding-block: 2px 5px; }
  #device-dialog[data-risk="true"] .dialog-close { display: none; }
  #device-dialog[data-risk="true"] .dialog-body { text-align: center; }
  #device-dialog[data-risk="true"] .dialog-actions .button { flex: 1; }
  .risk-mark { display: grid; place-items: center; margin: 16px auto 7px; width: 33px; height: 33px; border-radius: 7px; color: var(--risk); background: var(--risk-bg); }
  .danger { background: var(--risk-bg); color: var(--risk); border-color: transparent; }

  #callback-dialog { max-width: min(652px, calc(100% - 32px)); max-height: calc(100% - 32px); overflow: hidden; }
  #callback-dialog[open], #callback-overview, #callback-form { display: flex; flex-direction: column; min-height: 0; }
  #callback-dialog > .dialog-head, #callback-dialog .dialog-actions { flex: none; }
  .callback-body { overflow: auto; }
  .callback-current { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 11px; margin-bottom: 16px; border: 1px solid var(--rule); border-radius: 7px; background: var(--inset); }
  .callback-current p { font-size: 12px; margin-top: 2px; }
  .callback-current > div { min-width: 0; }
  .callback-tag { display: inline-block; flex: none; border: 1px solid var(--line); padding: 1px 7px; border-radius: 999px; font-size: 12px; color: var(--secondary); }
  .callback-tag[data-tone="pending"] { color: var(--pending); }
  .callback-section + .callback-section { margin-top: 16px; }
  .callback-section h3 { margin: 0; font-size: 14px; font-weight: 620; }
  .callback-section > p { font-size: 12px; }
  .callback-clients { list-style: none; margin: 7px 0 0; padding: 0; border: 1px solid var(--line); border-radius: 8px; }
  .callback-client { display: grid; grid-template-columns: minmax(118px, .32fr) minmax(0, 1fr); gap: 6px 12px; padding: 9px 11px; }
  .callback-client + .callback-client { border-top: 1px solid var(--rule); }
  .callback-identity { display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap; align-content: start; min-width: 0; overflow-wrap: anywhere; }
  .callback-uris { display: grid; gap: 3px; }
  .callback-uri { display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap; min-width: 0; }
  .callback-uri span { font-size: 12px; color: var(--secondary); }
  .callback-uri code { max-width: 100%; font: 12px/1.55 ui-monospace, SFMono-Regular, Consolas, monospace; overflow-wrap: anywhere; }
  .callback-unset { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-size: 12px; }
  .callback-unset .button { min-height: 28px; padding-inline: 9px; font-size: 12px; }
  #callback-feedback { padding: 7px 10px; margin-bottom: 12px; border: 1px solid var(--line); border-radius: 7px; color: var(--text); font-size: 13px; background: var(--inset); }
  #callback-form input { width: 100%; }
  #callback-form [aria-invalid="true"] { border-color: var(--risk); }
  #callback-form .field-error { margin-top: 3px; font-size: 12px; color: var(--risk); }
  @media (max-width: 540px) {
    .callback-client { grid-template-columns: 1fr; }
  }
  @media (max-width: 860px) {
    .page-intro { grid-template-columns: 1fr; gap: 14px; }
  }
  @media (max-width: 760px) {
    .topbar { padding-inline: 16px; }
    main { width: calc(100% - 32px); margin-top: 24px; }
    .heading h1 { font-size: 26px; }
    .toolbar { grid-template-columns: 1fr; }
    .filters { flex-wrap: wrap; }
    .filters button { font-size: 13px; padding-inline: 6px; gap: 5px; }
    .portal { flex-direction: column; align-items: flex-start; gap: 7px; padding: 11px 12px; }
    .portal-value { width: 100%; justify-content: space-between; gap: 8px; }
    .portal .button { min-width: 88px; padding-inline: 8px; }
    table, tbody { display: block; }
    colgroup { display: none; }
    thead { position: absolute; width: 1px; height: 1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
    tbody tr { display: grid; align-items: center; grid-template-columns: minmax(0,1fr) auto; gap: 8px; padding: 9px 11px; border-bottom: 1px solid var(--rule); }
    tbody tr:last-child { border-bottom: 0; }
    tbody th, tbody td { height: auto; padding: 0; border: 0; }
    tbody td:last-child { grid-column: 1 / -1; }
    .row-actions { justify-content: flex-end; flex-wrap: wrap; gap: 4px; }
    .row-actions .button { font-size: 12px; padding-inline: 6px; }
  }
  @media (max-width: 365px) {
    .portal-value { flex-wrap: wrap; }
    .portal code { flex-basis: 100%; }
    .portal .button { margin-left: auto; }
  }
`;
var logoBase64 = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAYKADAAQAAAABAAAAYAAAAACpM19OAAAeM0lEQVR4Aa1ca8xlV1k++5zzfd9c2g6dmXZK7wVK7W3kWiyImmh/kBiNYmKimBgMCS0xRG6FaPSfSmKiERWlBEFKKfw0sTFGKBfDXSiUAAqxDtgCpZ3ptHP7zm37XN537bXPOd/QC7vnrL3W+z7P877rXWvvc/nOtDnnwusHbTto1FTtYABj0wyaFt6lo9G4mDF0PzoYGLFE22FY6Dv4KVb0gSlxE1/8NiwNz2IMARCUccm7zLgZNmPMnwCVSC36qIuyYCMvFSIvqizwlCrtxaOOtRuDnapbaheOi87613SuUZRW/MRbLJGtMsHKkRsHkmTIYiod+MVmY0SdhpwxVwJCreq07ThA9BXAUp8+h9f0G6ZD27qDjs4Z5VIOxUqpJkq4JHEW4YJ0LcqwdIp+sbgju4qDi6FaJHl3IoUGUh2qywLnUffTVk96/dQ6pHoWYaurlgXGwFYlxZH3QjLpNAB2sADzMAWrkbiA5SM11p1FI5AXSXXUcpV5uesCwep0weqpJJxq9qE+Th0xPYXSMUZD8UjSJLlwuF44bdlgjigdmFcArylYSgbAS4Itng5kCpfJDyIKg8BKkz5ZtDVxM6FSHgTW47T3z7jE4qiDpI1naHSu7OnMBkFiz3t+wCIqq6F7mxLIe4k9uZQhkYrUynzTBiFm0DUcMSEcispuxI08bclKgEmDCq0akQkT10BLBi8eCiDXctPqEsu8lr0aUwsAxpEYwRXBYRVP1micNXMo1QG99KVGp1SjCXBl8w6ygRQnwWCkcJR9d9VK1QHodxRsHZMBqQ4mhEe41mLiEktBkzHyI4bMRxs/LgON5SuLjpH2jhlsQYjAsqFPmm3o9b12ENBpB51EMUNAXCFZ/+5QxoxYFqVYbCzQpYUJXRELJjqNdpCLrNwRkTHyQD/ywctOZNP52SspsvxOTaZEFX9Ihn3ZXJTkSK8uMQxAYi3E5RpJq2tlR4MMbSQcPaxBZ+nNy8mQIm7kplPf4Eus+HOPaXX7SJVC4SIHJqCSgA0e0bGPTZQtBR0BjlAQJCcT4WGjuZp/AUAYB4foFCttOEwKaQFtZ33cq43hkwyVKjXAjCwdgsurmOZIAChIsiISJmPw7aKKrCpC9BTP/kKizaa6pWj/sBea3araBBg6iFdtBwwB40PbH/6C5RzioM1qnaaU7K+QnhrnlNw8dwWCRWUBRMEiYkequPIxQdk8J6QfFM6E/VAyL30ZuH8GhrAK6m43b+mFsUinCOwVNa2YSClMhjfMeNvYx46wA/GiwzN3c1egnJ4yUYyAcqPw6MfgGBQahXPXsgpXbqHJSxGM8UBxVV/m4UA8uSfk2qbTEok6icN65ajY6IsLP2EKXmSig7Kw5xJoZwrOanUFoonKVkdbKiZGNHaXDKLgqaw7uYIy3bidFLCCssm04qx6pTOqxSGIPW6sAV3dchjXmShmXSjxArR6CmXIwDBHhvHsXHRoB6q/gxyXLY8i1CVJk/WEUEMJF98c0xASHeektuqSpiGheJoRE6Fz+TB32dqrUCiWKB3F5Ya6LqHOXuScQZdEONIcO6gQ0Sn9SoO22Cu0MmogqWx1OngwGeVDM4kmyyWqbFHoUBGIU2adzODZB0w1LM2MS7hvHhmspqgvQfYsrWwM6rUMvhyYgLgHdSqFxWmUw2S07OQ00PF1pKBlDiZxyJRChieCpYD6amZG2tZBqV94BVLVobMphiNUcYIdQRyVkjjc9gS6gS+FSkgpt9U9yD6KWCi0MR++9sLmR0hoEoLAQEwvPCogdFJIEpG7r3cA4YOvOMVZrOntqRdjiursJEPDq8Ms+lIeIQ6jZc5daK0q5A1jqwIRr6AlQacAQLFEBwFNTk+MsMRAFDT4HMJJv6uFnvxmVF0HC+Elr17qbAtY7wSVdFJQogUgT6VXHOYEAacoi6C1BPpN7iA4YwUYhyQjvQLus02rgokU82dQbgHw9ALOvuG+S2Cg4jqQ1y5iSIvNmq/RAM+g7OUBbUah1xlVndwXxMqpkBz5KAS6uwF6GnQN4I0vMWcB4YTTIKMlughU1LS8k4QRWBBsLiq4qFArHYd2fmxjF4reWenoRlFhalRW+REED1hziwaLFpYnpyF/p1ih0EUOfBSj9kepACMoTPV9EOUVQCQ2ygIcZ8PI4sjRmwwsSIyZIaQKiNTBcwLYwZkHE8LCY6tACYfsIR+yOjHR5BQdMYJFPrUWg8WsJsJtZVwczXAjR9YKTs6H6WYCJLHP/IufsVQgEwPS1Yj+iKaz+syKky/5J8pTtitWxmkRAFFXixoyU0cONiUM+0o6lzKxBkXFA7SYDbf2j8+/cTje40k5ngo6mJ/6wezY/VRuRtKHYq6TcUykmkeRiOQd0QVyglx+bwP6cBQ27NGXdOob1UE5YT5VYnbLzY8xOxH6OeyO3lgSFiGo44mS3vlkfOAl+170zsGeKzod9Uxq5/PtB+859fU/WcxONbzVlhiSCQ6MFOSzqks4FXu0ufcCMGpSBCgoeQNQ4wogK8s480W7PR3M5nSiDtPFYHvG2KN8Nch1hBIegFAyZSGQ3bLcxd05uR3He8598d8Mz3leO28HC6yFH6BHB6uzsf+axfTE7JHPNcMxF6tIMzkenWIO6ktbkAZMJgmyrz1ZSaVcUUylPBcUIbHvkeX2bHjp/l2/cO3mTVc2l+xHUdpjJyZfOTL52Den33hoMB4OXCaJIyoORFEnZDhy6IiwdBKHRZiN9l4xPlfV4TRLpqiOBzS282bz4CtOf/s9CoE0od4rU5kf50tCzqULi7+LMUdlSYHwRJTkgG2tTlHAMmyn8+HerXPe9Ko9v/vK0cX7kSOWVXrN7t94xeD2kyc+8pkT7/yX+Y+eaDbHyr2kwJXh2igLDLgwzENsoqpO3MiU5XCDIIIrDLEscrEOms3yVmaH0hd9C4kesrTwJs2h7RZnOQzhatLmhImP3NXNZjIfXrTv/Pe8duvnrmtn08X2xALYUugw2d0b577ulq2XXX309+6YfeuhZtdmMBXEmCqllI0cMCzJ1NucO0IHzlERJZebSOfU4AS0E9LQcdHTqkT1MxqBlF25NTBshi4dFEmKXAR0YsBzO1805+3e/4+v2/q569vtCe4Iqg7rkipts2jh2jh8xYG73rBxw2XtmYnEipRErWlHocYwQjJcJxtZEJK7jn3rpFrmQIS46SA0DlXSW8Fwt4GMApXlqBIwnzgwOO1iSB2WYTo/7+2/vHXzNe32NkbysHGZgqLxYHu6cfVF53/o1o3Dl7enVSMStD21epobTHjgcKtuGcu27CBSezWxKwDmo3XD2aknVGdNjVd5FRSwQEaBkpfnyG8pVuxSO7Gb2tl847pL9rzm5e102gVnLD0yjVDBNkSNnnMINRq/4PL2zJT2XgRHR2sr2uLWJsFUIkHa2cWzLJ36GVN2gdVUSh2i7rmAxCokQ/PGEpdYaPgORJ+oaj1i10YG5nbztTadbb3qBaPzzm1xERVAAlkm7jEe4QVxezq+8oIDd902fmHWCJIxSYCdCtrysABao7BIxghCecZQ6WQv9YrICaZM3Yc7EPTQVROINDrvQRiqYi5bgGsFCuY0i3002nzhFXjBgg+JFbNCsgk1B/MA89uejS47eOBDt2286Apca5ivtcv2KPQdOoBzPhkOWfGTi8bSAg1+QpiCT5JKBo1G1BFg6R8yqECcOLdEESAdwm6rCDBGGaw2HA32nDtggTzuAtR5hbPTbwaT2ejS/ftxP3rpVYtTeNVDcdB08TuhNT2sxXAwPT6cnyHP+5ncKFKEg2GIDxwPtQte/v1jOVt56+joB2YYKyF9GGlOJPuw6JE2EeHQuJk3zff3srhU6SD9bFhTr7CKSxjjTOajS/af/8HXb9703MWpaQpYZEcpKzfNaH7iuyf/96N4hzwYorZDlkyPZoixHuNhOzl15sjdMdWY71Jq9dCIEjo6o429ByHhfa7UdbV0xBB2TbjMeVCgbbcufPXGLfjQPFcZw+di1ZYkaQE4UNnni+H55+y65YbJF74zO/LoYHOEIitEFaYw+x0AF0e/uNh+rGm2FttH2+0fLU7/cHHm4fbMw2p/ND325ZPf+NPpo58f8DO9ZXnWWjqNmJNW2xGVODPwgyGbvRf8FN/KGiyPzGx0VEyMPXIQuhf7brpz1x+dN7r5gcH2qCq+r04JiJM8WgzjJmLQtt0cLx46+ujvvHv6hQea3ZtVgQCseVbTutAh8nyb32lwI0lKEF2teIO2zTcPQ7yT1hYmXGXyVENYVrKkhlPEDDc4+rCqaBJ3BMLzcJctuX0H7ipbl/568+B1w2uPDg+cGczLLZ/sxPKcfdrLIWPT4K3ms/bsvuWG7c9/Z459NB4FAcsZiZnt3MMpSZRi3M70eXg65ydkP/wWHt9y8IsOHkgbtGD2eix3yS6leY4DFzM/zfuSSCPOAalPXheUROsAD0ltu+vyXxsuLpvff2B0zfGGNTIHbSGXjgIsLwZ0G3wH0Dxr765fun7y2W/Pv3t0sMEaOXfIiG+R0rLTTma442xef8nGK67GG6uNw5fhbfr42oubvZvtoyfb01N+PFYesbRmR2IYRIRMNdzKsjQNLrFrgeTWUJmIKv0+haUpRMPbxb6Xf3C8/6bF9mB4wZnNN94/fO6xdnvIyhEZYiblQDUWXXlzdeHC5YBrbfZ/jxx9zbtn/3kE11oJRbeuEitGsmemWy+56tw//JXNm5832EMw7tIQ5GN7Mr//weN/9s9n/u3rza4NsnHoNTSvII1lXtcodxI44fg+iMNqbQ2hTMh3On0DL7HhnksGw0X7xMbivoPDq59oDp3Ma22ZXbiZAg2eP2fAe/berV+8bvLZ78y/d7TZiAskYiM90Jhkg3fkm698/v4Pv2F8/WUo7GDGj3sDfDGET4K44vAydtmB3b/64tmRR6ZfPdKMca1RQ8Eshq60QnqHk1h51/DugEkPJO1HUon1dCHM6THR/rGxWBzd2v6rw4tvHhhs8UrTmhlDBg5zTVckmwNIwclsfNnB/Xe+nu8h8zNtRNIGhwQ+Hg/3733WX/zW6MA52CyxWS1NPb4zarbxVdB435//5vjqi/B5KAJbiOH5zFbdbghXb2ZZoAJjR7Nzx1Jh7FHzgusQg41Fe3xz+teH268fzBqRicOKbHUvU8ceXVyeAX1Ng/dHl1+A90fjw/jcPyVTEbg8fkymu171gs1rL21RBa8j7DxYwu7lczofX3D+rle/FN9V0UkMhQSwEM2h7i7b0CqGKBCovm3IUeacRShwZ1SG7HhjqYfBeNE+vjl51+HF1y4cbGG3e1K+OzAIH5FDSSWNcePiZ5Hx5QcP3nXbxuFL21Px3QgjMQiPrZc9VyPnqbuDHXkXQhSkhWtv6yXP4SVWzS5FwEXXLf0WyA5cAex2ECdaYIQHIo2VD7HLJWmSnIFAjU5sTN514+IrFw438V6bQtLSGSDjYkFiyXmThoMuSmMfDa/APsJ3I933R0wKgOFw8Kw9+nwjXUpbUZWyBo2sUHPuLryW0aYMBHQPrVkVHV0exc5BFIhwS1PJZI0DjJPtwGWHdB3GqI1ExovBqfHk726cf/nQgDWKXQbFEBWYM+gfHPOJEPjcPxs/58Lz77x1fP2lvNZgN5yl5JGiKiidZiqafyhNBKV8MksqSkQiZKVDBjcwhZUFYlcaETJ9IQwXEUHwi2nYSEQ3UyCK2VMMb25Pj7f/9obFly4abOJve1wKQS0Uap0OVeAi3S2FWaNDuGePr332wvcjwbDDxM8KgyBpEv0nSW1bYalqUULiCTd6HrBVX5E1qJveh1VGhZqCC2SVTg5CxZvZUTxx0RG3HYzwHnc0efcN088farZ0p2ReTCgjkGe2s7M3SmgQvj963kW4Z4+ef4g1wsG52ee9o7mmojwxYCSMi4tDHBgXkyBqOA045CEiIPgELE5hlI4J8goRTfp1gcMGVQr7FNMnlCYYR4PFmeHsH26cfubZ7dYiitGVCWmkoIyca3fQRcP2bOOaiw/cedvoORfyj27cLnHn4mdIIvxEX8PYRZCmvgOUMJ189OQJFO8FGGN/Rib8AVWVEx2OtiJT75fOSfGyjKBWaThnzGTcLraHk/dcv7j3vMGmPhWLLyhBHYejzIxpKEmfcK1de/H+O28dXnmwPTPTX0pFdExiFA+56C9fMT2py0Hl6lCkGKOvslIvcwkOT7jEiOgU0YMhkZVorAVJ8BuQNI24mvJSUIsHIG8WqNGwHT3+x1878f57R5tbdHbZWE93qLKdKKA07NSy8Tv/Gy7FtTa8/MBU7yEhXe4HTIAsQz1gG4XrJhjh4Fs5yCeFrQ8mhD/jaZvGhOFQr2ASq2B04RlpAMMUZUKmpIjbUYi1UouveqaTx99y93Bj7+7ffkUzmehWZ3wwmQmfpECWPiQriFLUJ4yfvnLfB17HL1YW+HDBw/rqxkiWWEFJJASE7Apfj4vDxm6ob1KkXGwi16OSCYxOPPTt0CCLEwWxjbOTEK0j/E11Ojv2xg9i9nte87PtZLuqJ5UiZERgwV0mkMOF8/Z0z888H9+QLKb46EU74S5q5LHzKVUSsTS2niQjIAHxPgi9UnPxmfG6Q+sLom9mOA8j/ZxiITISI+TRLhb8/qFtj/3Bnac++OnhJr7Ksr9QDJWSQsQYFYCtoFAa7Z5KvPgyWJzD3nevBu37ozqSwE26mx+IQHoBSVmildiRmODOPV1iqHQSklk2T5AM/sxjsXjsTR86+U+uUXLjDEyWrR+/jCStpsqQey2r2PcVXoVmN2ahsO7XlswKv5N2QYDv/GFK0PK5CwmPMqtim8t0TePJ6UgfDWuE3XT8TR869YFPYR+VK0iMoIEFqEsVicXJstD03SmGClKCMmYNZ7/cvsmws8QqHfqqA3b9RrGDo6dKxSJyaiYbAm5vCGwiyzSlLx1HErOiUxJfZOpaezNq9OmG11pkZXW2eKa0jRE5gCpfv0bWELescGcjL3Rx8iO1SvhiiA7p/KOJh3HCoNfDAI8QZQgeyKBsOQpQg4/OSIhTMt59Z+61zxqd/MCnBqqRNUI/WTBWh+NnFnJ4AFhsEYz1jRBC6QEQ//5PWE+rilYFSMkuRHeT5oRCQ0p6GelzXYCMIxE2fqL1az05qh8t2vYE0Ng7IRg+l7ft8Tffder9n/L7oxrGGTCHUnQ548Liic48JG191ULdzt/1TChjylQapV8A5VXMaxtoDSKVWkJSvrtIgTgPqZzPyKHOn07HjE2WmaBGeEk6/tYPn3jfJ3CtldfI8GtvIpHMFy8AgHC/RpCuS4Ps+jO0RuAZTJnCMZPZOsiSA8bOAhp+gkcGV9x48wOjEyn21Yi6HzEl1PVrBPoxjJUgzEk3+L5mvjj2lrsQbM9rf34w0TcbeCfI+YmkLNBgkF10Qg86aXfosEdVdXGJxYAVNm0msbW3G7uHS4yKhK9SuDv4BUKPxGmtQpNv54pfZgplsJ4kvgOD6rG33nXyvffq/VF4fetAFn6ArI5kHCIvape9TlRcTgAc8tTrRy1wdPyAv5c6aNU9iFpSKESB2dQKMeCtwf+JA5Rp4qiLngbaKVhx5kgH7dzyPBcO70eDwWNvu/uJOz6Oa61cnzkxc9mqSjzFYSFKZQBl6NBEsbd0iVkNdqmYKenQrE5RoC4e1Sp/Skmpskc5gA10AJh/wopOsQjcjRiqoqNGzeD47Xc/8Z6PDTc3fAFqDhWG7/2LrlJV6hm10zbI1VMfjW0dRonyWmQsXtEwLHn5iwjCwqW+aGoAzmsdHlKX6IZyBfpOoC2ltpAqWxeEUO0nklSjJ97x0RN3fHzAGslBLJ2ic8phhS6lrUqQAqEhOMeyceCjAy/PhZ7KSzi4vMRkRbPkNb6vX0YsSA7irBOboiMLJ+MIVZtkIAQiKWh8D4lr7fa7T95xb32twW0M92iQACwH6Y5gkyFFVoEUbg23iKzxxSVGyBqvklJq1kDXpSnp0G4AfUrROt70qUm8j7TIbzNMssbG8LvX5vG3f8TXWhQG9FAh2By3/EV2BI/VgCGw6Hh9CPGRHp8tkb7q7AmU90HwBBGnlKjg0fWK1H78nL1apoD1qkNBptHO0BZtacBAb2eVm3dovD8atKjRyfd+AvcjmKUAvikcORZD8QpPP7SYkDTRTmZ4DxFZ+RQvDGkDsHdgnOJy5Q6KcMvwjuuggBGSdcJfLU8dCUwoFPmYNeDMFj+xOvV9pJ4owOgp86w6csCj+9Fjb7vr1B2f1P0IVLPRmotxebmLLHgqwMFw8j8P40uo9IGFI7jZz/w0zhAdRgWKofkBXH/yynS+ZvKDf1dCLoIcvtCUCJOhu2mnp+aP3YcvX3O3FTwQnrajd5PHGPdsfP187Pa7Tv79x1AjqTk2KYaqhZofsOZuwlrgH/zc81W+WafZRPO6QVoZLfvGxCh/3cFhjaj7giqRCiNAM1qc+t543w3j867EJwaavNEKLlDN7Pv3nD5yt/6FG0yySlWNhw5QXKokRqgR/q7xsW8MztnavPlqTlSXk9lwZcVtiDrwJXtr1+l7vnzyL/91MBrxtTpWRAwmgAeO0onppcVeIkqBbFotrVUsCEwRIpnHYjY79pWNgy8f7TkYW8F2tUhrOB7OH/uvJ+57x2B+Gluicq7tOgRc6DglnPlxfPLxb+Kb1o2br262NvAxpHIbXKmhFltbky8/cPzW97VPnMY/McrqLCVv/TLlvmTqlQKlYfmcWYZ9ZYhNNDk2efje0a5Dw71XDcdj/8aU7YirNv3hJ07c97bF6Qe1fZbVdx6DWlJHYTnH7U9+a/LFB0aH9o0vPr/ZvatBrPEGfptQPWAZL05Pznz0c8d//wPtD47jRzDaOnXadb/EL8YSNCz8hVlxBrxX6HRi87Kbw6LsafCftbXjfYc3D9w02n2x/xXkYvLI9OiXJo98Cf9kAT811QsR6M5gnU4Xt/aWjBmy3Z7hh1Xj6y4dvfiKzasODfHbMmN1beH3itMjj07/47+n93+X76f4lqoTVcq1WkkGnh0jlgIlekmQqoVc1IsF3kJoW/z7WtSCDC0bbxi4/jdYW5YnjBIsrKKgW0sIOxkPjCyhdbvFT37w4m1dxqsOADeG+pVjTa8A0S2CjgWr8QUZgPyzjxa2RISzD68NViz+rsNaDMrrFCPZ5xf3xOWZ/p4svjao7rgFFhoJxhdCA/yium3zx7DUca0KhfOQGQ06dZQ0x9mwAq69JvqNIhR45L0sJ2ajAqDrMLVi0ASLppph39xlXOwlb2v6Hc0azSSU0Ox4N9qFeujwia2gtRT69TAhNC7ZLeWWMksvKyWJggMfRtthrOVgrIeFstpZhdWaq3hbzFrlJj6S4rrySSCeRdnurF6SqnPwxQKxClQ8KwUC3c4KEpJLdiuuwqoEuu6ThJlQEl2K2MllFQCoMNxUeBS68fVWg2XJC0ulUCJUlyh2EOtfXNkpQqsuQIo34U//vCrliKv2JxljNWFY/IACOrWywXUbUQRCw3duNQFuD83ZOafeO7UlhZ1ZPQ9YHXHlSnACHaBHfVIDc3dSKPbSWSvqr1yZ3VJFlmhLwxV4NdW1cdYZ64h6bYogOK2EW8eX7SxI69dRapViL53a6z5dukkHpmSGDky22hiISqPOrIArf69bg2vHeiLRXDM8+nH7IwmtMdUB1vVB2SmfNXC/ijlMCebOkko9BKCA14iumH48GOrYRXGhYbDmtrg6rzqllZhnq0LJ5+wK1MQbxYLGcKf+kovMp3U4oTqKZWDhXS3c9KO7CluKuRNgNcpOajspZCD92M9yaTrb+SxIuOw9C8bSdU4dWFZ+GsEmSq08ny2lnXx1lJ0wT8K+/D+a3JFS59rNqoIjIed09szgrekxLN/woDx9lbOrVfF73VWWLXXoHuEsA92D4tJfC3NpGEDyaFbDryXuZFyic9iZ0Os+rdj8VGf1VPE75Sl7/f9y3RnY5b8z5hl6+EHBF1ddrsjxqWmfJduzuHaIgQ/f9Dwp4trXlR10n4a52zjeAks5PcOd+3TpT2IHOdGf6L5dXz4HQuvHEsjeJeOTHz59ut8H/dhITz/AOumdyv2TjbIu8lO0ISHfpJ8i75nCfwKF2KnGzzS1Ph+3RRWICT/9iE+J+ZTA/WyXRlB6hmJPgt7oJp2v8iToVry0whKy2ro7Nd/bmQEMOmyXFDQ3edc5Vmduy85YZ7yT32nUqqsWesFf76ip+KsIJlj+eu0/DYPWP4ohamFpYRyiB1jxWmyn+cBrEcOyj1f+okpP2oXSe+6wylA3q4FKRquu1RlF4ag4HAz/H23NUFlexZuaAAAAAElFTkSuQmCC";
var consoleLogo = Uint8Array.from(atob(logoBase64), (char) => char.charCodeAt(0));
var _a;
var consoleTemplate = String.raw(_a || (_a = __template(['<!doctype html>\n<html lang="zh-CN" data-theme="dark">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>\u8BBE\u5907\u7BA1\u7406 \xB7 Nodrelay</title>\n<link rel="stylesheet" href="/admin/console.css">\n<link rel="icon" type="image/png" href="/admin/console-logo.png">\n</head>\n<body>\n<svg class="sr-only" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">\n  <symbol id="moon" viewBox="0 0 24 24"><path d="M21 13.1A9.1 9.1 0 0 1 10.9 3a9.2 9.2 0 1 0 10.1 10.1Z"></path></symbol>\n  <symbol id="sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M19 5l-1.5 1.5m-11 11L5 19"></path></symbol>\n  <symbol id="monitor" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="13" rx="2"></rect><path d="M12 17v4m-4 0h8"></path></symbol>\n  <symbol id="chevron" viewBox="0 0 24 24"><path d="m4 8 8 8 8-8"></path></symbol>\n  <symbol id="plus" viewBox="0 0 24 24"><path d="M3 12h18M12 3v18"></path></symbol>\n  <symbol id="copy" viewBox="0 0 24 24"><path d="M7 16H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v2"></path><rect x="8" y="8" width="13" height="13" rx="2"></rect></symbol>\n  <symbol id="link" viewBox="0 0 24 24"><path d="M10 13.6a4 4 0 0 0 5.7 0l3.4-3.4a4 4 0 0 0-5.7-5.7l-1.7 1.7m2.3 4.2a4 4 0 0 0-5.7 0l-3.4 3.4a4 4 0 0 0 5.7 5.7l1.7-1.7"></path></symbol>\n  <symbol id="search" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="7.5"></circle><path d="m16 16 5 5"></path></symbol>\n  <symbol id="close" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"></path></symbol>\n  <symbol id="risk" viewBox="0 0 24 24"><path d="M12 8v5m0 3h.01M10.3 4.5l-8 14A1.7 1.7 0 0 0 3.8 21h16.4a1.7 1.7 0 0 0 1.5-2.5l-8-14a1.9 1.9 0 0 0-3.4 0Z"></path></symbol>\n</svg>\n<header class="topbar">\n  <div class="brand"><img src="/admin/console-logo.png" width="35" height="35" alt="">Nodrelay</div>\n  <label class="theme">\n    <span class="sr-only">\u5916\u89C2\u4E3B\u9898</span>\n    <svg class="icon" aria-hidden="true"><use id="theme-icon" href="#moon"></use></svg>\n    <select id="theme">\n      <option value="dark">\u6DF1\u8272</option>\n      <option value="light">\u6D45\u8272</option>\n      <option value="system">\u8DDF\u968F\u7CFB\u7EDF</option>\n    </select>\n    <svg class="icon chevron" aria-hidden="true"><use href="#chevron"></use></svg>\n  </label>\n</header>\n<main>\n  <div class="page-intro">\n    <div class="heading">\n      <h1>\u8BBE\u5907\u7BA1\u7406</h1>\n      <p>\u67E5\u770B\u8BBE\u5907\u63A5\u5165\u72B6\u6001\uFF0C\u7BA1\u7406 MCP Portal \u7684\u8FDC\u7A0B\u8BBF\u95EE\u3002</p>\n    </div>\n    <section class="portal" aria-label="MCP Portal">\n      <strong>MCP Portal</strong>\n      <div class="portal-value">\n        <code id="address" tabindex="-1">@@PORTAL@@</code>\n        <button class="button" type="button" id="copy-address"><svg class="icon" aria-hidden="true"><use href="#copy"></use></svg><span>\u590D\u5236\u5730\u5740</span></button>\n      </div>\n      <span class="sr-only" id="copy-feedback" role="status"></span>\n    </section>\n  </div>\n\n  <div class="portal-tools">\n    <button class="button" type="button" id="open-callbacks" aria-haspopup="dialog"><svg class="icon" aria-hidden="true"><use href="#link"></use></svg>\u5BA2\u6237\u7AEF\u56DE\u8C03\u914D\u7F6E</button>\n  </div>\n\n  <section class="devices" aria-labelledby="devices-title">\n    <div class="registry-heading">\n      <h2 id="devices-title">\u8BBE\u5907\u5217\u8868</h2>\n      <button class="button primary" type="button" id="add"@@ADD_DISABLED@@><svg class="icon" aria-hidden="true"><use href="#plus"></use></svg>\u6DFB\u52A0\u8BBE\u5907</button>\n    </div>\n    <div class="toolbar">\n      <div class="filters" role="group" aria-label="\u6309\u63A5\u5165\u72B6\u6001\u7B5B\u9009">\n        <button type="button" data-filter="all" aria-pressed="true">\u5168\u90E8 <span class="count">@@COUNT_ALL@@</span></button>\n        <button type="button" data-filter="active" aria-pressed="false">\u5DF2\u6CE8\u518C <span class="count">@@COUNT_ACTIVE@@</span></button>\n        <button type="button" data-filter="pending" aria-pressed="false">\u5F85\u63A5\u5165 <span class="count">@@COUNT_PENDING@@</span></button>\n        <button type="button" data-filter="disabled" aria-pressed="false">\u5DF2\u505C\u7528 <span class="count">@@COUNT_DISABLED@@</span></button>\n      </div>\n      <label class="search">\n        <svg class="icon" aria-hidden="true"><use href="#search"></use></svg>\n        <span class="sr-only">\u641C\u7D22\u8BBE\u5907 ID</span>\n        <input type="search" id="device-search" placeholder="\u641C\u7D22\u8BBE\u5907 ID" autocomplete="off">\n      </label>\n    </div>\n    <div class="table-wrap">\n      <table role="table" aria-labelledby="devices-title">\n        <colgroup><col class="identity-col"><col class="state-col"><col></colgroup>\n        <thead role="rowgroup"><tr role="row"><th scope="col">\u8BBE\u5907\u4E0E\u7CFB\u7EDF</th><th scope="col">\u63A5\u5165\u72B6\u6001</th><th scope="col">\u64CD\u4F5C</th></tr></thead>\n        <tbody role="rowgroup">@@ROWS@@</tbody>\n      </table>\n      <div class="empty" id="empty" hidden>\n        <svg class="icon" aria-hidden="true"><use href="#search"></use></svg>\n        <strong role="status">\u672A\u627E\u5230\u5339\u914D\u7684\u8BBE\u5907</strong>\n        <p>\u8BD5\u8BD5\u5176\u4ED6\u8BBE\u5907 ID\uFF0C\u6216\u6E05\u9664\u7B5B\u9009\u3002</p>\n        <button class="button" type="button" id="clear-filters">\u6E05\u9664\u7B5B\u9009</button>\n      </div>\n    </div>\n    <p class="note">\u6CE8\u518C\u72B6\u6001\u4E0D\u4EE3\u8868\u8BBE\u5907\u5B9E\u65F6\u5728\u7EBF\u3002\u8BF7\u901A\u8FC7\u300C\u67E5\u770B\u72B6\u6001\u300D\u68C0\u67E5 Tunnel \u4E0E MCP \u5DE5\u5177\u76EE\u5F55\u3002</p>\n  </section>\n</main>\n\n<dialog id="add-dialog" aria-labelledby="add-title">\n  <header class="dialog-head">\n    <h2 id="add-title">\u6DFB\u52A0\u8BBE\u5907</h2>\n    <button type="submit" form="close-add" class="dialog-close" aria-label="\u5173\u95ED\u5F39\u5C42"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <form id="add-device-form" method="post" action="/admin/devices">\n    <div class="dialog-body">\n      <fieldset class="platform-tabs">\n        <legend class="sr-only">\u76EE\u6807\u7CFB\u7EDF</legend>@@PLATFORMS@@</fieldset>\n      <label>\u8BBE\u5907 ID <input name="deviceId" required pattern="[a-z][a-z0-9-]{0,23}" maxlength="24" placeholder="\u4F8B\u5982 mac-mini" autocomplete="off" aria-describedby="id-hint"></label>\n      <p class="field-hint" id="id-hint">\u5C0F\u5199\u5B57\u6BCD\u5F00\u5934\uFF0C\u6700\u591A 24 \u4E2A\u5B57\u7B26\uFF0C\u53EF\u542B\u6570\u5B57\u548C\u8FDE\u5B57\u7B26\u3002</p>\n      <label id="browser-consent" hidden><span><input id="confirm-browser" name="browserConsent" type="checkbox" value="1" aria-describedby="browser-consent-hint" disabled> \u4E3A\u6B64\u8BBE\u5907\u542F\u7528\u6D4F\u89C8\u5668\u5DE5\u5177</span>\n        <span class="field-hint" id="browser-consent-hint">\u5B89\u88C5\u524D\u9700\u5728\u76EE\u6807\u8BBE\u5907\u914D\u7F6E\u6D4F\u89C8\u5668\u4E13\u7528\u540E\u7AEF\u3002</span></label>\n      <p class="feedback" id="add-feedback" role="status" hidden></p>\n    </div>\n    <div class="dialog-actions"><button class="button" type="submit" form="close-add">\u53D6\u6D88</button><button class="button primary" type="submit" id="issue-command">\u751F\u6210\u8FDE\u63A5\u547D\u4EE4</button></div>\n  </form>\n  <section class="dialog-body device-command" id="device-command-result" aria-labelledby="device-command-label" hidden>\n    <p><strong id="device-command-target"></strong> \xB7 <span id="command-instructions"></span></p>\n    <h3 id="device-command-label">\u6307\u4EE4</h3>\n    <pre id="device-command" tabindex="0" aria-labelledby="device-command-label"></pre>\n    <button class="button primary" type="button" id="copy-device-command"><svg class="icon" aria-hidden="true"><use href="#copy"></use></svg><span>\u590D\u5236</span></button>\n    <p id="device-command-feedback" role="status" hidden></p>\n  </section>\n  <form id="close-add" method="dialog"></form>\n</dialog>\n\n<dialog id="device-dialog" aria-labelledby="device-dialog-title">\n  <span class="risk-mark" id="risk-mark" hidden><svg class="icon" aria-hidden="true"><use href="#risk"></use></svg></span>\n  <header class="dialog-head">\n    <h2 id="device-dialog-title"></h2>\n    <button type="submit" form="close-detail" class="dialog-close" aria-label="\u5173\u95ED\u5F39\u5C42"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <div class="dialog-body">\n    <p id="device-summary"></p>\n    <dl class="detail" id="device-details">\n      <dt>\u6CE8\u518C</dt><dd id="registration-detail"></dd>\n      <dt>Cloudflare Tunnel</dt><dd id="tunnel-detail">\u672A\u67E5\u8BE2</dd>\n      <dt>\u5F00\u53D1\u5DE5\u5177\u76EE\u5F55</dt><dd id="mcp-detail">\u672A\u67E5\u8BE2</dd>\n      <dt id="browser-label" hidden>\u6D4F\u89C8\u5668\u5DE5\u5177\u76EE\u5F55</dt><dd id="browser-detail" hidden></dd>\n      <dt id="release-label" hidden>\u5B89\u88C5\u5305\u7248\u672C</dt><dd id="release-detail" hidden></dd>\n      <dt id="revocation-label" hidden>\u64A4\u9500</dt><dd id="revocation-detail" hidden></dd>\n      <dt id="server-label" hidden>Portal \u670D\u52A1 ID</dt><dd id="server-detail" hidden></dd>\n    </dl>\n    <p class="feedback" id="device-feedback"></p>\n  </div>\n  <form class="dialog-actions" id="close-detail" method="dialog">\n    <button class="button" id="detail-dismiss">\u5173\u95ED</button>\n    <button class="button danger" id="detail-confirm" type="button" disabled hidden></button>\n  </form>\n</dialog>\n\n<dialog id="callback-dialog" aria-labelledby="callback-title">\n  <header class="dialog-head">\n    <h2 id="callback-title">\u5BA2\u6237\u7AEF\u56DE\u8C03\u914D\u7F6E</h2>\n    <button type="submit" form="close-callbacks" class="dialog-close" aria-label="\u5173\u95ED\u56DE\u8C03\u914D\u7F6E"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <div id="callback-overview">\n    <div class="dialog-body callback-body">\n      <div class="callback-current">\n        <div><strong>\u5B9E\u9645\u914D\u7F6E</strong><p id="callback-summary">\u6B63\u5728\u8BFB\u53D6 Portal \u4E2D\u7684\u914D\u7F6E\u2026</p></div>\n        <span class="callback-tag" id="callback-state">\u8BFB\u53D6\u4E2D</span>\n      </div>\n      <p id="callback-feedback" role="status" tabindex="-1" hidden></p>\n      <section class="callback-section" id="callback-configured" aria-labelledby="callback-configured-title" hidden>\n        <h3 id="callback-configured-title">\u5DF2\u8BBE\u56DE\u8C03\u5730\u5740</h3>\n        <p>\u7531 Portal \u8FD4\u56DE\uFF0C\u53EF\u4F9B OAuth \u5BA2\u6237\u7AEF\u6CE8\u518C\u4F7F\u7528\u3002</p>\n        <ul id="callback-configured-list" class="callback-clients"></ul>\n      </section>\n      <section class="callback-section" id="callback-presets" aria-labelledby="callback-presets-title">\n        <h3 id="callback-presets-title">\u9884\u7F6E\u56DE\u8C03\u89C4\u5219</h3>\n        <p>\u6309\u5BA2\u6237\u7AEF\u6838\u5BF9\u9884\u7F6E\u89C4\u5219\u548C Portal \u7684\u914D\u7F6E\u72B6\u6001\u3002</p>\n        <ul class="callback-clients">\n          <li class="callback-client" data-preset-name="ChatGPT">\n            <strong class="callback-identity">ChatGPT</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u56FA\u5B9A\u56DE\u8C03\uFF08\u9002\u7528\u65F6\uFF09</span><code data-callback-address>https://chatgpt.com/connector_platform_oauth_redirect</code></div>\n              <div class="callback-uri"><span>\u6309\u8FDE\u63A5\u5206\u914D \xB7 \u6A21\u677F</span><code data-callback-address="https://chatgpt.com/connector/oauth/*">https://chatgpt.com/connector/oauth/{callback_id}</code></div>\n            </div>\n          </li>\n          <li class="callback-client" data-preset-name="Claude">\n            <strong class="callback-identity">Claude</strong>\n            <div class="callback-uri"><span>\u81EA\u5B9A\u4E49\u8FDE\u63A5\u5668</span><code data-callback-address>https://claude.ai/api/mcp/auth_callback</code></div>\n          </li>\n          <li class="callback-client" data-preset-name="Cursor">\n            <strong class="callback-identity">Cursor</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u7F51\u9875\u4E0E Agents</span><code data-callback-address>https://www.cursor.com/agents/mcp/oauth/callback</code></div>\n              <div class="callback-uri"><span>\u684C\u9762</span><code data-callback-address>http://localhost:8787/callback</code></div>\n              <div class="callback-uri"><span>\u539F\u751F\u534F\u8BAE</span><code data-callback-address>cursor://anysphere.cursor-mcp/oauth/callback</code></div>\n            </div>\n          </li>\n          <li class="callback-client" data-preset-name="VS Code">\n            <strong class="callback-identity">VS Code</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u7F51\u9875</span><code data-callback-address>https://vscode.dev/redirect</code></div>\n              <div class="callback-uri"><span>\u684C\u9762</span><code data-callback-address>http://127.0.0.1:33418/</code></div>\n            </div>\n          </li>\n          <li class="callback-client">\n            <div class="callback-identity"><strong>WorkBuddy</strong><span class="callback-tag" id="workbuddy-state" data-tone="pending">\u5F85\u914D\u7F6E</span></div>\n            <div class="callback-unset"><p>\u6CA1\u6709\u5DF2\u9A8C\u8BC1\u7684\u901A\u7528\u5730\u5740\uFF0C\u8BF7\u586B\u5199\u5BA2\u6237\u7AEF\u63D0\u4F9B\u7684\u51C6\u786E\u56DE\u8C03\u3002</p><button class="button" type="button" id="add-workbuddy" data-client="WorkBuddy" disabled>\u586B\u5199 WorkBuddy \u56DE\u8C03</button></div>\n          </li>\n        </ul>\n      </section>\n    </div>\n    <div class="dialog-actions">\n      <button class="button" type="submit" form="close-callbacks">\u5173\u95ED</button>\n      <button class="button primary" type="button" id="add-client" disabled><svg class="icon" aria-hidden="true"><use href="#plus"></use></svg>\u6DFB\u52A0\u5176\u4ED6\u5BA2\u6237\u7AEF</button>\n    </div>\n  </div>\n  <form id="callback-form" novalidate hidden>\n    <div class="dialog-body callback-body">\n      <p>\u8F93\u5165\u5BA2\u6237\u7AEF\u63D0\u4F9B\u7684\u51C6\u786E\u5730\u5740\u3002\u4FDD\u5B58\u540E\uFF0C\u6B64 Portal \u53EF\u63A5\u53D7\u4F7F\u7528\u8BE5\u56DE\u8C03\u5730\u5740\u7684 OAuth \u5BA2\u6237\u7AEF\u6CE8\u518C\u3002</p>\n      <label for="callback-name">\u5BA2\u6237\u7AEF\u540D\u79F0</label>\n      <input id="callback-name" name="clientName" type="text" autocomplete="off" maxlength="64" required aria-describedby="callback-name-error">\n      <p id="callback-name-error" class="field-error" role="alert" hidden></p>\n      <label for="callback-url">\u56DE\u8C03\u5730\u5740</label>\n      <input id="callback-url" name="redirectUri" type="text" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="2048" placeholder="https://client.example/oauth/callback" required aria-describedby="callback-url-hint callback-url-error">\n      <p id="callback-url-hint" class="field-hint">\u586B\u5199\u5B8C\u6574\u56DE\u8C03 URL\uFF0C\u4E0D\u8981\u7C98\u8D34\u6388\u6743\u7801\u6216\u5BC6\u94A5\u3002</p>\n      <p id="callback-url-error" class="field-error" role="alert" hidden></p>\n      <p id="callback-save-error" class="field-error" role="alert" hidden></p>\n    </div>\n    <div class="dialog-actions">\n      <button class="button" type="button" id="cancel-callback">\u53D6\u6D88</button>\n      <button class="button primary" id="save-callback" type="submit">\u4FDD\u5B58</button>\n    </div>\n  </form>\n  <form id="close-callbacks" method="dialog"></form>\n</dialog>\n\n<script src="/admin/devices.js" defer><\/script>\n</body>\n</html>\n'], ['<!doctype html>\n<html lang="zh-CN" data-theme="dark">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>\u8BBE\u5907\u7BA1\u7406 \xB7 Nodrelay</title>\n<link rel="stylesheet" href="/admin/console.css">\n<link rel="icon" type="image/png" href="/admin/console-logo.png">\n</head>\n<body>\n<svg class="sr-only" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">\n  <symbol id="moon" viewBox="0 0 24 24"><path d="M21 13.1A9.1 9.1 0 0 1 10.9 3a9.2 9.2 0 1 0 10.1 10.1Z"></path></symbol>\n  <symbol id="sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M19 5l-1.5 1.5m-11 11L5 19"></path></symbol>\n  <symbol id="monitor" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="13" rx="2"></rect><path d="M12 17v4m-4 0h8"></path></symbol>\n  <symbol id="chevron" viewBox="0 0 24 24"><path d="m4 8 8 8 8-8"></path></symbol>\n  <symbol id="plus" viewBox="0 0 24 24"><path d="M3 12h18M12 3v18"></path></symbol>\n  <symbol id="copy" viewBox="0 0 24 24"><path d="M7 16H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v2"></path><rect x="8" y="8" width="13" height="13" rx="2"></rect></symbol>\n  <symbol id="link" viewBox="0 0 24 24"><path d="M10 13.6a4 4 0 0 0 5.7 0l3.4-3.4a4 4 0 0 0-5.7-5.7l-1.7 1.7m2.3 4.2a4 4 0 0 0-5.7 0l-3.4 3.4a4 4 0 0 0 5.7 5.7l1.7-1.7"></path></symbol>\n  <symbol id="search" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="7.5"></circle><path d="m16 16 5 5"></path></symbol>\n  <symbol id="close" viewBox="0 0 24 24"><path d="m6 6 12 12M18 6 6 18"></path></symbol>\n  <symbol id="risk" viewBox="0 0 24 24"><path d="M12 8v5m0 3h.01M10.3 4.5l-8 14A1.7 1.7 0 0 0 3.8 21h16.4a1.7 1.7 0 0 0 1.5-2.5l-8-14a1.9 1.9 0 0 0-3.4 0Z"></path></symbol>\n</svg>\n<header class="topbar">\n  <div class="brand"><img src="/admin/console-logo.png" width="35" height="35" alt="">Nodrelay</div>\n  <label class="theme">\n    <span class="sr-only">\u5916\u89C2\u4E3B\u9898</span>\n    <svg class="icon" aria-hidden="true"><use id="theme-icon" href="#moon"></use></svg>\n    <select id="theme">\n      <option value="dark">\u6DF1\u8272</option>\n      <option value="light">\u6D45\u8272</option>\n      <option value="system">\u8DDF\u968F\u7CFB\u7EDF</option>\n    </select>\n    <svg class="icon chevron" aria-hidden="true"><use href="#chevron"></use></svg>\n  </label>\n</header>\n<main>\n  <div class="page-intro">\n    <div class="heading">\n      <h1>\u8BBE\u5907\u7BA1\u7406</h1>\n      <p>\u67E5\u770B\u8BBE\u5907\u63A5\u5165\u72B6\u6001\uFF0C\u7BA1\u7406 MCP Portal \u7684\u8FDC\u7A0B\u8BBF\u95EE\u3002</p>\n    </div>\n    <section class="portal" aria-label="MCP Portal">\n      <strong>MCP Portal</strong>\n      <div class="portal-value">\n        <code id="address" tabindex="-1">@@PORTAL@@</code>\n        <button class="button" type="button" id="copy-address"><svg class="icon" aria-hidden="true"><use href="#copy"></use></svg><span>\u590D\u5236\u5730\u5740</span></button>\n      </div>\n      <span class="sr-only" id="copy-feedback" role="status"></span>\n    </section>\n  </div>\n\n  <div class="portal-tools">\n    <button class="button" type="button" id="open-callbacks" aria-haspopup="dialog"><svg class="icon" aria-hidden="true"><use href="#link"></use></svg>\u5BA2\u6237\u7AEF\u56DE\u8C03\u914D\u7F6E</button>\n  </div>\n\n  <section class="devices" aria-labelledby="devices-title">\n    <div class="registry-heading">\n      <h2 id="devices-title">\u8BBE\u5907\u5217\u8868</h2>\n      <button class="button primary" type="button" id="add"@@ADD_DISABLED@@><svg class="icon" aria-hidden="true"><use href="#plus"></use></svg>\u6DFB\u52A0\u8BBE\u5907</button>\n    </div>\n    <div class="toolbar">\n      <div class="filters" role="group" aria-label="\u6309\u63A5\u5165\u72B6\u6001\u7B5B\u9009">\n        <button type="button" data-filter="all" aria-pressed="true">\u5168\u90E8 <span class="count">@@COUNT_ALL@@</span></button>\n        <button type="button" data-filter="active" aria-pressed="false">\u5DF2\u6CE8\u518C <span class="count">@@COUNT_ACTIVE@@</span></button>\n        <button type="button" data-filter="pending" aria-pressed="false">\u5F85\u63A5\u5165 <span class="count">@@COUNT_PENDING@@</span></button>\n        <button type="button" data-filter="disabled" aria-pressed="false">\u5DF2\u505C\u7528 <span class="count">@@COUNT_DISABLED@@</span></button>\n      </div>\n      <label class="search">\n        <svg class="icon" aria-hidden="true"><use href="#search"></use></svg>\n        <span class="sr-only">\u641C\u7D22\u8BBE\u5907 ID</span>\n        <input type="search" id="device-search" placeholder="\u641C\u7D22\u8BBE\u5907 ID" autocomplete="off">\n      </label>\n    </div>\n    <div class="table-wrap">\n      <table role="table" aria-labelledby="devices-title">\n        <colgroup><col class="identity-col"><col class="state-col"><col></colgroup>\n        <thead role="rowgroup"><tr role="row"><th scope="col">\u8BBE\u5907\u4E0E\u7CFB\u7EDF</th><th scope="col">\u63A5\u5165\u72B6\u6001</th><th scope="col">\u64CD\u4F5C</th></tr></thead>\n        <tbody role="rowgroup">@@ROWS@@</tbody>\n      </table>\n      <div class="empty" id="empty" hidden>\n        <svg class="icon" aria-hidden="true"><use href="#search"></use></svg>\n        <strong role="status">\u672A\u627E\u5230\u5339\u914D\u7684\u8BBE\u5907</strong>\n        <p>\u8BD5\u8BD5\u5176\u4ED6\u8BBE\u5907 ID\uFF0C\u6216\u6E05\u9664\u7B5B\u9009\u3002</p>\n        <button class="button" type="button" id="clear-filters">\u6E05\u9664\u7B5B\u9009</button>\n      </div>\n    </div>\n    <p class="note">\u6CE8\u518C\u72B6\u6001\u4E0D\u4EE3\u8868\u8BBE\u5907\u5B9E\u65F6\u5728\u7EBF\u3002\u8BF7\u901A\u8FC7\u300C\u67E5\u770B\u72B6\u6001\u300D\u68C0\u67E5 Tunnel \u4E0E MCP \u5DE5\u5177\u76EE\u5F55\u3002</p>\n  </section>\n</main>\n\n<dialog id="add-dialog" aria-labelledby="add-title">\n  <header class="dialog-head">\n    <h2 id="add-title">\u6DFB\u52A0\u8BBE\u5907</h2>\n    <button type="submit" form="close-add" class="dialog-close" aria-label="\u5173\u95ED\u5F39\u5C42"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <form id="add-device-form" method="post" action="/admin/devices">\n    <div class="dialog-body">\n      <fieldset class="platform-tabs">\n        <legend class="sr-only">\u76EE\u6807\u7CFB\u7EDF</legend>@@PLATFORMS@@</fieldset>\n      <label>\u8BBE\u5907 ID <input name="deviceId" required pattern="[a-z][a-z0-9\\-]{0,23}" maxlength="24" placeholder="\u4F8B\u5982 mac-mini" autocomplete="off" aria-describedby="id-hint"></label>\n      <p class="field-hint" id="id-hint">\u5C0F\u5199\u5B57\u6BCD\u5F00\u5934\uFF0C\u6700\u591A 24 \u4E2A\u5B57\u7B26\uFF0C\u53EF\u542B\u6570\u5B57\u548C\u8FDE\u5B57\u7B26\u3002</p>\n      <label id="browser-consent" hidden><span><input id="confirm-browser" name="browserConsent" type="checkbox" value="1" aria-describedby="browser-consent-hint" disabled> \u4E3A\u6B64\u8BBE\u5907\u542F\u7528\u6D4F\u89C8\u5668\u5DE5\u5177</span>\n        <span class="field-hint" id="browser-consent-hint">\u5B89\u88C5\u524D\u9700\u5728\u76EE\u6807\u8BBE\u5907\u914D\u7F6E\u6D4F\u89C8\u5668\u4E13\u7528\u540E\u7AEF\u3002</span></label>\n      <p class="feedback" id="add-feedback" role="status" hidden></p>\n    </div>\n    <div class="dialog-actions"><button class="button" type="submit" form="close-add">\u53D6\u6D88</button><button class="button primary" type="submit" id="issue-command">\u751F\u6210\u8FDE\u63A5\u547D\u4EE4</button></div>\n  </form>\n  <section class="dialog-body device-command" id="device-command-result" aria-labelledby="device-command-label" hidden>\n    <p><strong id="device-command-target"></strong> \xB7 <span id="command-instructions"></span></p>\n    <h3 id="device-command-label">\u6307\u4EE4</h3>\n    <pre id="device-command" tabindex="0" aria-labelledby="device-command-label"></pre>\n    <button class="button primary" type="button" id="copy-device-command"><svg class="icon" aria-hidden="true"><use href="#copy"></use></svg><span>\u590D\u5236</span></button>\n    <p id="device-command-feedback" role="status" hidden></p>\n  </section>\n  <form id="close-add" method="dialog"></form>\n</dialog>\n\n<dialog id="device-dialog" aria-labelledby="device-dialog-title">\n  <span class="risk-mark" id="risk-mark" hidden><svg class="icon" aria-hidden="true"><use href="#risk"></use></svg></span>\n  <header class="dialog-head">\n    <h2 id="device-dialog-title"></h2>\n    <button type="submit" form="close-detail" class="dialog-close" aria-label="\u5173\u95ED\u5F39\u5C42"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <div class="dialog-body">\n    <p id="device-summary"></p>\n    <dl class="detail" id="device-details">\n      <dt>\u6CE8\u518C</dt><dd id="registration-detail"></dd>\n      <dt>Cloudflare Tunnel</dt><dd id="tunnel-detail">\u672A\u67E5\u8BE2</dd>\n      <dt>\u5F00\u53D1\u5DE5\u5177\u76EE\u5F55</dt><dd id="mcp-detail">\u672A\u67E5\u8BE2</dd>\n      <dt id="browser-label" hidden>\u6D4F\u89C8\u5668\u5DE5\u5177\u76EE\u5F55</dt><dd id="browser-detail" hidden></dd>\n      <dt id="release-label" hidden>\u5B89\u88C5\u5305\u7248\u672C</dt><dd id="release-detail" hidden></dd>\n      <dt id="revocation-label" hidden>\u64A4\u9500</dt><dd id="revocation-detail" hidden></dd>\n      <dt id="server-label" hidden>Portal \u670D\u52A1 ID</dt><dd id="server-detail" hidden></dd>\n    </dl>\n    <p class="feedback" id="device-feedback"></p>\n  </div>\n  <form class="dialog-actions" id="close-detail" method="dialog">\n    <button class="button" id="detail-dismiss">\u5173\u95ED</button>\n    <button class="button danger" id="detail-confirm" type="button" disabled hidden></button>\n  </form>\n</dialog>\n\n<dialog id="callback-dialog" aria-labelledby="callback-title">\n  <header class="dialog-head">\n    <h2 id="callback-title">\u5BA2\u6237\u7AEF\u56DE\u8C03\u914D\u7F6E</h2>\n    <button type="submit" form="close-callbacks" class="dialog-close" aria-label="\u5173\u95ED\u56DE\u8C03\u914D\u7F6E"><svg class="icon" aria-hidden="true"><use href="#close"></use></svg></button>\n  </header>\n  <div id="callback-overview">\n    <div class="dialog-body callback-body">\n      <div class="callback-current">\n        <div><strong>\u5B9E\u9645\u914D\u7F6E</strong><p id="callback-summary">\u6B63\u5728\u8BFB\u53D6 Portal \u4E2D\u7684\u914D\u7F6E\u2026</p></div>\n        <span class="callback-tag" id="callback-state">\u8BFB\u53D6\u4E2D</span>\n      </div>\n      <p id="callback-feedback" role="status" tabindex="-1" hidden></p>\n      <section class="callback-section" id="callback-configured" aria-labelledby="callback-configured-title" hidden>\n        <h3 id="callback-configured-title">\u5DF2\u8BBE\u56DE\u8C03\u5730\u5740</h3>\n        <p>\u7531 Portal \u8FD4\u56DE\uFF0C\u53EF\u4F9B OAuth \u5BA2\u6237\u7AEF\u6CE8\u518C\u4F7F\u7528\u3002</p>\n        <ul id="callback-configured-list" class="callback-clients"></ul>\n      </section>\n      <section class="callback-section" id="callback-presets" aria-labelledby="callback-presets-title">\n        <h3 id="callback-presets-title">\u9884\u7F6E\u56DE\u8C03\u89C4\u5219</h3>\n        <p>\u6309\u5BA2\u6237\u7AEF\u6838\u5BF9\u9884\u7F6E\u89C4\u5219\u548C Portal \u7684\u914D\u7F6E\u72B6\u6001\u3002</p>\n        <ul class="callback-clients">\n          <li class="callback-client" data-preset-name="ChatGPT">\n            <strong class="callback-identity">ChatGPT</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u56FA\u5B9A\u56DE\u8C03\uFF08\u9002\u7528\u65F6\uFF09</span><code data-callback-address>https://chatgpt.com/connector_platform_oauth_redirect</code></div>\n              <div class="callback-uri"><span>\u6309\u8FDE\u63A5\u5206\u914D \xB7 \u6A21\u677F</span><code data-callback-address="https://chatgpt.com/connector/oauth/*">https://chatgpt.com/connector/oauth/{callback_id}</code></div>\n            </div>\n          </li>\n          <li class="callback-client" data-preset-name="Claude">\n            <strong class="callback-identity">Claude</strong>\n            <div class="callback-uri"><span>\u81EA\u5B9A\u4E49\u8FDE\u63A5\u5668</span><code data-callback-address>https://claude.ai/api/mcp/auth_callback</code></div>\n          </li>\n          <li class="callback-client" data-preset-name="Cursor">\n            <strong class="callback-identity">Cursor</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u7F51\u9875\u4E0E Agents</span><code data-callback-address>https://www.cursor.com/agents/mcp/oauth/callback</code></div>\n              <div class="callback-uri"><span>\u684C\u9762</span><code data-callback-address>http://localhost:8787/callback</code></div>\n              <div class="callback-uri"><span>\u539F\u751F\u534F\u8BAE</span><code data-callback-address>cursor://anysphere.cursor-mcp/oauth/callback</code></div>\n            </div>\n          </li>\n          <li class="callback-client" data-preset-name="VS Code">\n            <strong class="callback-identity">VS Code</strong>\n            <div class="callback-uris">\n              <div class="callback-uri"><span>\u7F51\u9875</span><code data-callback-address>https://vscode.dev/redirect</code></div>\n              <div class="callback-uri"><span>\u684C\u9762</span><code data-callback-address>http://127.0.0.1:33418/</code></div>\n            </div>\n          </li>\n          <li class="callback-client">\n            <div class="callback-identity"><strong>WorkBuddy</strong><span class="callback-tag" id="workbuddy-state" data-tone="pending">\u5F85\u914D\u7F6E</span></div>\n            <div class="callback-unset"><p>\u6CA1\u6709\u5DF2\u9A8C\u8BC1\u7684\u901A\u7528\u5730\u5740\uFF0C\u8BF7\u586B\u5199\u5BA2\u6237\u7AEF\u63D0\u4F9B\u7684\u51C6\u786E\u56DE\u8C03\u3002</p><button class="button" type="button" id="add-workbuddy" data-client="WorkBuddy" disabled>\u586B\u5199 WorkBuddy \u56DE\u8C03</button></div>\n          </li>\n        </ul>\n      </section>\n    </div>\n    <div class="dialog-actions">\n      <button class="button" type="submit" form="close-callbacks">\u5173\u95ED</button>\n      <button class="button primary" type="button" id="add-client" disabled><svg class="icon" aria-hidden="true"><use href="#plus"></use></svg>\u6DFB\u52A0\u5176\u4ED6\u5BA2\u6237\u7AEF</button>\n    </div>\n  </div>\n  <form id="callback-form" novalidate hidden>\n    <div class="dialog-body callback-body">\n      <p>\u8F93\u5165\u5BA2\u6237\u7AEF\u63D0\u4F9B\u7684\u51C6\u786E\u5730\u5740\u3002\u4FDD\u5B58\u540E\uFF0C\u6B64 Portal \u53EF\u63A5\u53D7\u4F7F\u7528\u8BE5\u56DE\u8C03\u5730\u5740\u7684 OAuth \u5BA2\u6237\u7AEF\u6CE8\u518C\u3002</p>\n      <label for="callback-name">\u5BA2\u6237\u7AEF\u540D\u79F0</label>\n      <input id="callback-name" name="clientName" type="text" autocomplete="off" maxlength="64" required aria-describedby="callback-name-error">\n      <p id="callback-name-error" class="field-error" role="alert" hidden></p>\n      <label for="callback-url">\u56DE\u8C03\u5730\u5740</label>\n      <input id="callback-url" name="redirectUri" type="text" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" maxlength="2048" placeholder="https://client.example/oauth/callback" required aria-describedby="callback-url-hint callback-url-error">\n      <p id="callback-url-hint" class="field-hint">\u586B\u5199\u5B8C\u6574\u56DE\u8C03 URL\uFF0C\u4E0D\u8981\u7C98\u8D34\u6388\u6743\u7801\u6216\u5BC6\u94A5\u3002</p>\n      <p id="callback-url-error" class="field-error" role="alert" hidden></p>\n      <p id="callback-save-error" class="field-error" role="alert" hidden></p>\n    </div>\n    <div class="dialog-actions">\n      <button class="button" type="button" id="cancel-callback">\u53D6\u6D88</button>\n      <button class="button primary" id="save-callback" type="submit">\u4FDD\u5B58</button>\n    </div>\n  </form>\n  <form id="close-callbacks" method="dialog"></form>\n</dialog>\n\n<script src="/admin/devices.js" defer><\/script>\n</body>\n</html>\n'])));

// ../cloud/management.mjs
var document = /* @__PURE__ */ __name((title, body) => `<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${title}</title>
<link rel="stylesheet" href="/admin/fleet.css"><main><h1>${title}</h1>${body}</main></html>`, "document");
var assets = {
  "/admin/console.css": ["text/css", consoleStyles],
  "/admin/console-logo.png": ["image/png", consoleLogo],
  "/admin/devices.js": ["text/javascript", consoleScript],
  "/admin/fleet.css": ["text/css", `
:root { color-scheme: light dark; font: 16px/1.6 system-ui, sans-serif; }
body { margin: 0; background: Canvas; color: CanvasText; }
main { width: min(52rem, calc(100% - 2.5rem)); margin: 3rem auto; }
h1 { margin: 0 0 1.5rem; font-size: clamp(1.8rem, 6vw, 2.65rem); letter-spacing: -.025em; }
h2 { margin: 0 0 .75rem; font-size: 1.2rem; }
[hidden] { display: none !important; }
.toolbar { display: flex; align-items: end; justify-content: space-between; gap: .65rem; flex-wrap: wrap; margin-bottom: .75rem; }
dialog { width: min(35rem, calc(100% - 3.5rem)); border: 1px solid GrayText; border-radius: .7rem; padding: 1.25rem; }
dialog::backdrop { background: rgb(0 0 0 / .45); }
.dialog-actions { display: flex; flex-wrap: wrap; gap: .6rem; margin-top: .8rem; }
section { border: 1px solid color-mix(in srgb, CanvasText 21%, Canvas); border-radius: .7rem; padding: 1.15rem; margin: 1rem 0; }
form { display: flex; align-items: end; gap: .6rem; flex-wrap: wrap; }
label { display: grid; gap: .2rem; }
input, select, button, textarea { font: inherit; padding: .35rem .55rem; border-radius: .35rem; }
input, select, textarea { border: 1px solid GrayText; }
button { cursor: pointer; border: 1px solid currentColor; }
.strong { background: Highlight; color: HighlightText; }
.table { overflow-x: auto; }
table { border-collapse: collapse; width: 100%; text-align: left; }
th, td { border-bottom: 1px solid color-mix(in srgb, CanvasText 18%, Canvas); padding: .65rem .5rem; }
textarea { display: block; box-sizing: border-box; width: 100%; font-family: ui-monospace, monospace; margin-bottom: .7rem; resize: vertical; }
code { overflow-wrap: anywhere; }
dd { margin: 0 0 .65rem; }
`],
  "/admin/copy.js": ["text/javascript", `
const field = document.querySelector('#command');
const button = document.querySelector('#copy');
if (field && button && navigator.clipboard) {
  button.hidden = false;
  button.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(field.value);
      document.querySelector('#copy-status').textContent = '\u547D\u4EE4\u5DF2\u590D\u5236';
    } catch {
      field.focus();
      field.select();
      document.querySelector('#copy-status').textContent = '\u8BF7\u624B\u52A8\u590D\u5236\u5DF2\u9009\u4E2D\u7684\u547D\u4EE4';
    }
  });
}
`]
};
var label = {
  ...Object.fromEntries(Object.entries(operatingSystems).map(([platform, entry]) => [platform, entry.label])),
  "windows-x64": "Windows x64",
  "macos-arm64": "macOS Apple Silicon",
  "macos-x64": "macOS Intel",
  "linux-x64": "Linux x64",
  "linux-arm64": "Linux ARM64"
};
var state = { pending: "\u7B49\u5F85\u8BBE\u5907\u63A5\u5165", active: "\u5DF2\u6CE8\u518C\u5230 Portal", disabled: "\u5DF2\u505C\u7528" };
var mcpState = {
  catalog_verified: "\u76EE\u5F55\u5DF2\u9A8C\u8BC1",
  unavailable: "\u76EE\u5F55\u65E0\u6CD5\u8BBF\u95EE",
  unverified: "\u7B49\u5F85\u9A8C\u8BC1",
  not_enabled: "\u672A\u542F\u7528",
  disabled: "\u5DF2\u505C\u7528"
};
function devicePage(devices, releases, portalHostname) {
  const portal = /^[a-z0-9.-]+$/.test(portalHostname ?? "") ? "https://" + portalHostname : "";
  const hosted = hostedInstallers(releases);
  const options = Object.entries(operatingSystems).flatMap(([platform, { architectures, label: text2 }]) => {
    if (hosted[platform]) return [{ value: platform, text: text2, enabled: true, browser: hosted[platform].browser }];
    const local = architectures.map((arch) => platform + "-" + arch).filter((value) => releases[value]?.localFile);
    return local.length ? local.map((value) => ({ value, text: label[value], enabled: true, browser: releases[value].browser })) : [{ value: platform, text: text2, enabled: false }];
  });
  const selected = options.findIndex((option) => option.enabled);
  const platforms = options.map(({ value, text: text2, enabled, browser }, index) => `<label${enabled ? "" : ' title="\u5F53\u524D\u65E0\u53EF\u7528\u5B89\u88C5\u5305"'}><input class="sr-only" type="radio" name="platform" value="${escapeHtml(value)}"${browser === true ? ' data-browser="true"' : ""}${enabled ? "" : " disabled"}${index === selected ? " checked" : ""}><span>${escapeHtml(text2)}</span></label>`).join("\n");
  const button = /* @__PURE__ */ __name((action, text2, quiet = false) => `<button class="button${quiet ? " quiet" : ""}" type="button" data-action="${action}">${text2}</button>`, "button");
  const rows = devices.map((device) => `
    <tr data-state="${escapeHtml(device.status)}" data-device="${escapeHtml(device.id)}">
      <th scope="row"><div class="identity"><span class="initial" aria-hidden="true">${escapeHtml(device.id[0].toUpperCase())}</span><div><span class="device-name">${escapeHtml(device.id)}</span><span class="system">${escapeHtml(label[device.platform] ?? device.platform)}</span></div></div></th>
      <td><span class="state">${escapeHtml(state[device.status] ?? device.status)}</span></td>
      <td><div class="row-actions">${button("status", "\u67E5\u770B\u72B6\u6001")}${device.status === "pending" ? button("cancel", "\u53D6\u6D88\u7968\u636E", true) : ""}${device.status === "disabled" ? button("review", "\u590D\u6838\u505C\u7528", true) : button("disable", "\u505C\u7528\u8FDC\u7A0B\u63A5\u5165", true)}</div></td>
    </tr>`).join("");
  const total = /* @__PURE__ */ __name((status) => devices.filter((device) => device.status === status).length, "total");
  const values = {
    PORTAL: portal ? escapeHtml(portal) + "<wbr>/mcp" : "\u5C1A\u672A\u914D\u7F6E",
    ROWS: rows,
    PLATFORMS: platforms,
    ADD_DISABLED: selected < 0 ? " disabled" : "",
    COUNT_ALL: devices.length,
    COUNT_ACTIVE: total("active"),
    COUNT_PENDING: total("pending"),
    COUNT_DISABLED: total("disabled")
  };
  return consoleTemplate.replace(/@@([A-Z_]+)@@/g, (_, name) => values[name]);
}
__name(devicePage, "devicePage");
var back = '<p><a href="/">\u8FD4\u56DE\u8BBE\u5907\u5217\u8868</a></p>';
async function manage(request, env, url, { limitedBody: limitedBody2, html: html2, json: json2, assetResponse: assetResponse2, provider = createDevices }) {
  const devices = provider(env);
  const wantsJson = request.headers.get("Accept")?.split(",").some((value) => value.split(";", 1)[0].trim() === "application/json");
  try {
    if (request.method === "GET") {
      if (Object.hasOwn(assets, url.pathname)) return assetResponse2(...assets[url.pathname]);
      if (url.pathname === "/admin/client-callbacks") return json2(await devices.clientCallbacks());
      if (url.pathname === "/") {
        return html2(devicePage(await devices.list(), devices.releases, JSON.parse(env.FLEET_SPEC).portalHostname));
      }
    }
    if (request.method !== "POST") return json2({ error: "Unknown route" }, 404);
    if (url.pathname === activatePath) {
      if (request.headers.get("Content-Type")?.split(";", 1)[0] !== "application/json") return json2({ error: "Expected JSON" }, 415);
      let input2;
      try {
        input2 = JSON.parse(await limitedBody2(request));
      } catch {
        return json2({ error: "Invalid request" }, 400);
      }
      const token = /^Bearer (.+)$/.exec(request.headers.get("Authorization") ?? "")?.[1];
      const result = await devices.activate(input2?.deviceId, token);
      return json2(result, result.status === "revoked" ? 410 : 200);
    }
    if (request.headers.get("Origin") !== url.origin) return json2({ error: "Invalid origin" }, 403);
    if (request.headers.get("Content-Type")?.split(";", 1)[0] !== "application/x-www-form-urlencoded") return json2({ error: "Expected form" }, 415);
    const input = Object.fromEntries(new URLSearchParams(await limitedBody2(request)));
    if (url.pathname === "/admin/client-callbacks") {
      return json2(await devices.registerClientCallback(input.clientName, input.redirectUri));
    }
    if (url.pathname === "/admin/devices") {
      const { asset, ticket, expiresAt } = await devices.launch(input.deviceId, input.platform, { confirmBrowser: input.browserConsent === "1" });
      const command = asset.assets ? shortInstallCommand(url.origin, input.platform, asset.version, ticket, input.deviceId) : installCommand(url.origin, input.platform, asset, ticket, input.deviceId);
      const shell = input.platform === "windows" || input.platform.startsWith("windows-") ? " PowerShell" : "\u7EC8\u7AEF";
      const instructions = `${asset.localFile ? "\u8BF7\u5728\u9884\u7F6E\u5B89\u88C5\u5305\u6240\u5728\u76EE\u5F55\u8FD0\u884C\u547D\u4EE4\u3002" : ""}${asset.browser ? "\u8BF7\u5148\u5728\u76EE\u6807\u8BBE\u5907\u914D\u7F6E\u6D4F\u89C8\u5668\u4E13\u7528\u540E\u7AEF\u3002" : ""}\u5728\u76EE\u6807\u8BBE\u5907\u7684${shell}\u8FD0\u884C\u8FD9\u6761\u547D\u4EE4\u3002\u7968\u636E\u6709\u6548\u671F\u5341\u5206\u949F\uFF0C\u4EC5\u53EF\u4F7F\u7528\u4E00\u6B21\uFF0C\u8BF7\u52FF\u8F6C\u53D1\u3002`;
      if (wantsJson) return json2({ command, instructions, expiresAt, deviceId: input.deviceId, platform: label[input.platform] });
      return html2(document("\u8FDE\u63A5\u547D\u4EE4", `${asset.localFile ? `<p>\u672C\u6B21\u8BD5\u70B9\u4F7F\u7528\u76EE\u6807\u8BBE\u5907\u4E0A\u5DF2\u51C6\u5907\u7684\u5B89\u88C5\u5305 <code>${escapeHtml(asset.localFile)}</code>\u3002\u8BF7\u5728\u5B89\u88C5\u5305\u6240\u5728\u76EE\u5F55\u8FD0\u884C\u547D\u4EE4\u3002</p>` : ""}
        <p id="install-instructions">${escapeHtml(instructions)}\u83B7\u51C6\u7684\u7BA1\u7406\u5458\u53EF\u8C03\u7528\u6B64\u8BBE\u5907\u5F00\u653E\u7684\u6587\u4EF6\u548C\u547D\u4EE4\u5DE5\u5177\u3002</p>
        <p>${escapeHtml(label[input.platform])} \xB7 <strong>${escapeHtml(input.deviceId)}</strong> \xB7 \u7248\u672C ${escapeHtml(asset.version)} \xB7 ${escapeHtml(new Date(expiresAt * 1e3).toISOString().replace("T", " ").slice(0, 16))} UTC \u5230\u671F</p>
        <textarea id="command" rows="${asset.assets ? 3 : 8}" readonly aria-label="\u8BBE\u5907\u8FDE\u63A5\u547D\u4EE4">${escapeHtml(command)}</textarea>
        <button class="strong" type="button" id="copy" hidden>\u590D\u5236\u547D\u4EE4</button> <span role="status" id="copy-status"></span>
        <script src="/admin/copy.js" defer><\/script>${back}`));
    }
    if (url.pathname === "/admin/device") {
      if (input.action === "status") {
        const result = await devices.status(input.deviceId);
        if (wantsJson) return json2(result);
        const development = result.mcpProfiles?.development ?? result.mcp;
        const browser = result.mcpProfiles?.browser;
        return html2(document("\u8BBE\u5907\u72B6\u6001", `<p><strong>${escapeHtml(result.deviceId)}</strong></p><dl>
          <dt>\u6CE8\u518C</dt><dd>${escapeHtml(state[result.registration] ?? result.registration)}</dd>
          <dt>Cloudflare Tunnel</dt><dd>${escapeHtml(result.tunnel)}</dd>
          <dt>\u5F00\u53D1\u5DE5\u5177\u76EE\u5F55</dt><dd>${escapeHtml(mcpState[development] ?? development)}</dd>
          ${browser ? `<dt>\u6D4F\u89C8\u5668\u5DE5\u5177\u76EE\u5F55</dt><dd>${escapeHtml(mcpState[browser] ?? browser)}</dd>` : ""}
          ${result.release ? `<dt>\u5B89\u88C5\u5305\u7248\u672C</dt><dd>${escapeHtml(result.release)}</dd>` : ""}
          ${result.serverIds ? `<dt>Portal \u670D\u52A1 ID</dt><dd>${result.serverIds.map((id) => `<code>${escapeHtml(id)}</code>`).join(" \xB7 ")}</dd>` : ""}
          ${result.revocation ? `<dt>\u64A4\u9500</dt><dd>${result.revocation === "complete" ? "\u5DF2\u5B8C\u6210" : "\u5C1A\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5\u505C\u7528"}</dd>` : ""}
          </dl>${back}`));
      }
      if (input.action === "cancel") {
        await cancelTicket(env.TICKETS, input.deviceId);
        if (wantsJson) return json2({ status: "cancelled" });
        return html2(document("\u5DF2\u53D6\u6D88\u5B89\u88C5\u7968\u636E", back));
      }
      if (input.action === "confirm-disable") {
        const result = await devices.status(input.deviceId);
        if (result.revocation === "complete") return html2(document("\u8FDC\u7A0B\u63A5\u5165\u5DF2\u505C\u7528", back));
        return html2(document("\u505C\u7528\u8FDC\u7A0B\u63A5\u5165", `<p>\u8BBE\u5907 <strong>${escapeHtml(result.deviceId)}</strong> \u7684\u5B89\u88C5\u7968\u636E\u3001Tunnel \u51ED\u636E\u548C Portal \u8DEF\u7531\u5C06\u88AB\u64A4\u9500\u3002</p>
          <form method="post" action="/admin/device"><input type="hidden" name="deviceId" value="${escapeHtml(result.deviceId)}">
          <button class="strong" name="action" value="disable">\u786E\u8BA4\u505C\u7528</button></form>${back}`));
      }
      if (input.action === "disable") {
        await devices.disable(input.deviceId);
        if (wantsJson) return json2({ status: "disabled" });
        return html2(document("\u8FDC\u7A0B\u63A5\u5165\u5DF2\u505C\u7528", back));
      }
    }
    return json2({ error: "Unknown route" }, 404);
  } catch (error) {
    if (url.pathname === activatePath) {
      return error instanceof DeviceError ? json2({ error: error.message }, error.status) : json2({ error: "Device activation failed" }, 503);
    }
    const expected = error instanceof DeviceError || error instanceof PortalCallbackError;
    const message2 = expected ? error.message : "\u8BF7\u68C0\u67E5 Cloudflare \u6743\u9650\u548C\u8BBE\u5907\u8FDE\u63A5\u540E\u91CD\u8BD5\u3002";
    const status = expected ? error.status : 503;
    if (wantsJson || url.pathname === "/admin/client-callbacks") return json2({ error: message2 }, status);
    return html2(document("\u8BBE\u5907\u64CD\u4F5C\u5931\u8D25", `<p>${escapeHtml(message2)}</p>${back}`), status);
  }
}
__name(manage, "manage");

// ../cloud/worker.mjs
var responseHeaders = {
  "Cache-Control": "no-store",
  // Browser form POSTs need a same-origin Origin header for CSRF protection.
  "Referrer-Policy": "same-origin",
  "X-Content-Type-Options": "nosniff",
  "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"
};
var json = /* @__PURE__ */ __name((value, status = 200) => Response.json(value, { status, headers: responseHeaders }), "json");
var issuers = /* @__PURE__ */ new Map();
async function accessAdmin(request, env) {
  if (!/^https:\/\/[a-z0-9-]+\.cloudflareaccess\.com$/.test(env.ACCESS_ISSUER ?? "") || !env.ACCESS_AUD || !env.OWNER_EMAIL) return false;
  const token = request.headers.get("Cf-Access-Jwt-Assertion");
  if (!token) return false;
  const issuer = env.ACCESS_ISSUER;
  if (!issuers.has(issuer)) {
    issuers.set(issuer, createRemoteJWKSet(new URL("/cdn-cgi/access/certs", issuer), { timeoutDuration: 4e3 }));
  }
  try {
    const { payload } = await jwtVerify(token, issuers.get(issuer), {
      issuer,
      audience: env.ACCESS_AUD,
      algorithms: ["RS256"],
      requiredClaims: ["exp", "sub", "email"]
    });
    return payload.email === env.OWNER_EMAIL;
  } catch {
    return false;
  }
}
__name(accessAdmin, "accessAdmin");
async function limitedBody(request) {
  if (!request.body) throw new Error("Expected request body");
  const reader = request.body.getReader();
  const decoder2 = new TextDecoder("utf-8", { fatal: true });
  let value = "", bytes = 0;
  try {
    while (true) {
      const { done, value: chunk } = await reader.read();
      if (done) return value + decoder2.decode();
      bytes += chunk.length;
      if (bytes > 1e4) throw new Error("Request body too large");
      value += decoder2.decode(chunk, { stream: true });
    }
  } finally {
    await reader.cancel().catch(() => {
    });
  }
}
__name(limitedBody, "limitedBody");
var page = `<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width"><title>DevSpace Fleet \u8BBE\u5907\u63A5\u5165</title>
<main><h1>DevSpace Fleet \u8BBE\u5907\u63A5\u5165</h1>
<p>\u4F7F\u7528\u5DF2\u4E3A\u6B64\u8BBE\u5907\u521B\u5EFA\u7684 Tunnel \u4E0E Portal \u6E90\u7AD9\u51ED\u636E\u751F\u6210\u5341\u5206\u949F\u5B89\u88C5\u7968\u636E\u3002</p>
<form method="post" action="/admin/tickets" autocomplete="off">
<p><label>\u8BBE\u5907 ID <input name="deviceId" required pattern="[a-z][a-z0-9\\-]{0,23}"></label></p>
<p><label>Tunnel \u4EE4\u724C <input name="tunnelToken" required type="password" maxlength="4096"></label></p>
<p><label>Portal \u6E90\u7AD9\u4EE4\u724C <input name="portalToken" required type="password" minlength="43" maxlength="43"></label></p>
<button>\u751F\u6210\u7968\u636E</button></form>
<h2>\u53D6\u6D88\u672A\u4F7F\u7528\u7684\u7968\u636E</h2>
<form method="post" action="/admin/cancel">
<label>\u8BBE\u5907 ID <input name="deviceId" required pattern="[a-z][a-z0-9\\-]{0,23}"></label>
<button>\u53D6\u6D88\u7968\u636E</button></form></main></html>`;
var assetResponse = /* @__PURE__ */ __name((contentType, body, status = 200) => new Response(body, {
  status,
  headers: { ...responseHeaders, "Content-Type": typeof body === "string" ? contentType + "; charset=utf-8" : contentType }
}), "assetResponse");
var html = /* @__PURE__ */ __name((body, status) => assetResponse("text/html", body, status), "html");
function createWorker({ verifyAdmin = accessAdmin, deviceProvider } = {}) {
  return {
    async fetch(request, env) {
      const url = new URL(request.url);
      if (url.origin !== env.APP_ORIGIN || url.protocol !== "https:") return json({ error: "Unknown origin" }, 404);
      const { pathname } = url;
      const provisioner = Boolean(env.PROVISIONER_TOKEN) !== Boolean(env.PROVISIONER_OAUTH);
      const managed = Boolean(env.FLEET_SPEC && provisioner && env.RELEASE_CATALOG);
      if (env.FLEET_SPEC && !managed) return json({ error: "Managed deployment bindings missing" }, 503);
      const installPlatform = managed && Object.keys(operatingSystems).find((platform) => pathname === installPath(platform));
      if (installPlatform) {
        const group = hostedInstallers(JSON.parse(env.RELEASE_CATALOG))[installPlatform];
        if (request.method !== "GET" || !group || url.searchParams.get("version") !== group.version) {
          return json({ error: "Installer version unavailable. Generate a new connection command." }, 404);
        }
        return assetResponse("text/plain", bootstrapInstaller(url.origin, installPlatform, group));
      }
      const redeem = pathname === (managed ? enrollPath : "/enroll");
      const activate = managed && pathname === activatePath;
      const mediaType = request.headers.get("Content-Type")?.split(";", 1)[0].trim().toLowerCase();
      if (!redeem && !activate && !await verifyAdmin(request, env)) return json({ error: "Administrator login required" }, 403);
      if (managed && !redeem) return manage(request, env, url, { limitedBody, html, json, assetResponse, provider: deviceProvider });
      if (request.method === "GET" && pathname === "/") return html(page);
      if (request.method !== "POST") return json({ error: "Unknown route" }, 404);
      if (!redeem && request.headers.get("Origin") !== url.origin) return json({ error: "Invalid origin" }, 403);
      try {
        if (redeem) {
          if (mediaType !== "application/json") return json({ error: "Expected JSON" }, 415);
          let ticket;
          try {
            ({ ticket } = JSON.parse(await limitedBody(request)));
          } catch {
            return json({ error: "Invalid request" }, 400);
          }
          const credentials2 = await redeemTicket(env.TICKETS, env.TICKET_KEY, ticket);
          return credentials2 ? json(credentials2) : json({ error: "Ticket unavailable" }, 404);
        }
        if (!["/admin/tickets", "/admin/cancel"].includes(pathname)) return json({ error: "Unknown route" }, 404);
        if (mediaType !== "application/x-www-form-urlencoded") return json({ error: "Expected form" }, 415);
        let input;
        try {
          input = Object.fromEntries(new URLSearchParams(await limitedBody(request)));
        } catch {
          return json({ error: "Invalid form" }, 400);
        }
        if (pathname === "/admin/cancel") {
          if (!devicePattern.test(input.deviceId ?? "")) return json({ error: "Invalid device id" }, 400);
          await cancelTicket(env.TICKETS, input.deviceId);
          return html('<!doctype html><p>\u5F85\u9886\u53D6\u7968\u636E\u5DF2\u53D6\u6D88\u3002</p><p><a href="/">\u8FD4\u56DE\u8BBE\u5907\u63A5\u5165</a></p>');
        }
        let credentials;
        try {
          credentials = validateCredentials(input);
        } catch {
          return json({ error: "Invalid device credentials" }, 400);
        }
        const issued = await issueTicket(env.TICKETS, env.TICKET_KEY, credentials);
        if (!issued) return json({ error: "This device already has an unclaimed ticket" }, 409);
        const command = `npm run enroll -- ${url.origin} .fleet-${credentials.deviceId}`;
        return html(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>\u8BBE\u5907\u5B89\u88C5\u7968\u636E</title>
          <h1>\u51ED\u636E\u9886\u53D6</h1><p>\u5728\u76EE\u6807\u8BBE\u5907\u5DF2\u9A8C\u8BC1\u7684\u9879\u76EE\u76EE\u5F55\u8FD0\u884C\u4E0B\u65B9\u547D\u4EE4\uFF0C\u5E76\u7C98\u8D34\u6B64\u7968\u636E\u3002</p>
          <pre>${command}</pre><p>\u7968\u636E\uFF08\u6709\u6548\u671F\u5341\u5206\u949F\uFF0C\u6210\u529F\u9886\u53D6\u540E\u7ACB\u5373\u5931\u6548\uFF09</p>
          <pre>${issued.ticket}</pre><p><a href="/">\u8FD4\u56DE\u8BBE\u5907\u63A5\u5165</a></p></html>`);
      } catch {
        return json({ error: "Enrollment temporarily unavailable" }, 503);
      }
    }
  };
}
__name(createWorker, "createWorker");
var worker_default = createWorker();
export {
  OAuthProvisioner,
  createWorker,
  worker_default as default
};
